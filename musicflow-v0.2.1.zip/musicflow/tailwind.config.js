const rgb = (v) => `rgb(var(${v}) / <alpha-value>)`;

/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        bg: rgb('--c-bg'),
        surface: rgb('--c-surface'),
        raised: rgb('--c-raised'),
        fg: rgb('--c-fg'),
        muted: rgb('--c-muted'),
        line: rgb('--c-line'),
        accent: rgb('--c-accent'),
        'on-accent': rgb('--c-on-accent'),
      },
      fontFamily: {
        display: ['"Sora Variable"', 'Sora', 'system-ui', 'sans-serif'],
        sans: ['"Instrument Sans Variable"', '"Instrument Sans"', 'system-ui', 'sans-serif'],
      },
      borderRadius: {
        ui: 'var(--r)',
        'ui-lg': 'calc(var(--r) * 1.6)',
        'ui-sm': 'calc(var(--r) * 0.6)',
      },
      keyframes: {
        eq: { '0%,100%': { transform: 'scaleY(.25)' }, '50%': { transform: 'scaleY(1)' } },
        shimmer: { '100%': { transform: 'translateX(100%)' } },
      },
      animation: { eq: 'eq 900ms ease-in-out infinite', shimmer: 'shimmer 1.4s infinite' },
    },
  },
  plugins: [],
};
