# MusicFlow

Lecteur de musique premium pour Windows 10 et 11, construit avec **Tauri 2, React, TypeScript, Tailwind, Framer Motion, Zustand et SQLite**.
Version actuelle : **0.2.0, étapes 1 à 3** (architecture, interface principale, lecteur local réel, fournisseur YouTube).

> ## ⚠️ À lire d'abord : ce code n'a pas encore été compilé
> Il a été écrit dans un environnement sans Windows, sans Rust et sans accès réseau.
> **Vérifié ici** : la logique pure (file d'attente, recherche, raccourcis, formats, chemins : 55 tests qui passent) et le typecheck TypeScript de l'ensemble des fichiers, avec des déclarations de substitution pour les bibliothèques externes.
> **Non vérifié** : `npm install`, `cargo build`, le rendu de l'interface, la lecture audio, le scan de dossiers, la base SQLite, les touches multimédias.
> Attends-toi à quelques erreurs de compilation ou d'exécution au premier lancement : renvoie-les telles quelles, elles seront corrigées une par une.

## Prérequis (Windows)
1. **Node.js 20 ou plus récent**
2. **Rust** (via [rustup](https://rustup.rs)) et les **Build Tools Visual Studio** avec la charge de travail « Développement Desktop en C++ »
3. **WebView2** (déjà présent sur Windows 11 ; installable sinon)

## Lancer
```powershell
npm install
npm run tauri dev        # développement
npm run test             # tests unitaires
npm run typecheck        # vérification TypeScript
npm run tauri build      # installateur NSIS dans src-tauri/target/release/bundle/nsis
```
Pour YouTube : **Paramètres › Sources en ligne**, colle une clé API gratuite (YouTube Data API v3), puis cherche dans **Recherche** et lance avec Ctrl + Entrée.
Au premier lancement : **Accueil › Choisir un dossier** (ou Bibliothèque › icône dossier). MusicFlow lit les tags et pochettes, et conserve l'index dans SQLite. Tes fichiers ne sont jamais modifiés.

## Ce qui est réel, et ce qui ne l'est pas
Aucune fonction simulée : chacune est classée **fonctionnelle / partielle / en attente / non disponible** dans `docs/STATUS.md` et dans *Paramètres › État des fonctionnalités*.
L'interface grise ce qu'une source ne sait pas faire et explique pourquoi (infobulle).

Points d'attention connus, à surveiller au premier lancement :
- `music-metadata` (ESM) dans le navigateur via Vite : devrait fonctionner, premier suspect si le scan échoue.
- Accès aux dossiers : le plugin `persisted-scope` doit conserver l'autorisation après redémarrage.
- Touches multimédias et panneau Windows : via l'API Media Session de WebView2, support à confirmer.
- Choix de la sortie audio : dépend de la version de WebView2.
- Un fichier est chargé en mémoire pour être lu (nécessaire à l'égaliseur) : très gros WAV déconseillés.
- La CSP est volontairement désactivée pour l'instant ; elle sera durcie à l'étape 7.
- **YouTube** (étape 3) : jamais testé avec une vraie clé. Risque d'erreur 153 du lecteur intégré ; limites de quota (100 recherches/jour). Voir `docs/PROVIDERS.md`.

## Architecture
```
src/
├─ core/
│  ├─ types.ts               Track, Album, Artist, Capabilities
│  ├─ features.ts            registre honnête des fonctionnalités
│  ├─ providers/             contrat MusicProvider + Local (réel) + YouTube (API officielles, quotas, lecteur IFrame)
│  └─ playback/
│     ├─ Queue.ts            file d'attente pure et testée (aléatoire, doublons, déplacement)
│     ├─ AudioGraph.ts       Web Audio : ReplayGain → préampli → 10 filtres → balance → analyseur → volume
│     ├─ LocalBackend.ts     lecture des fichiers locaux
│     ├─ engine.ts           orchestration : file, backend, statistiques, reprise de session
│     └─ mediaSession.ts     touches multimédias / SMTC
├─ services/                 SQLite (repository), scanner de tags, pochettes
├─ stores/                   Zustand : settings (persistés), player, library, ui
├─ features/                 home, library (titres/albums/artistes/album/artiste), search, settings
├─ ui/                       Sidebar, PlayerBar, SidePanels (file + fiche titre), composants de base
└─ utils/                    recherche, groupes, formats, couleurs, raccourcis
src-tauri/                   Rust : plugins SQL, fichiers, dialogues ; migrations SQLite ; icônes
```
Le moteur ne connaît que le contrat `PlaybackBackend` : ajouter un fournisseur (YouTube, Subsonic, Jellyfin…) ne touche pas à l'interface.

## Décision sur YouTube Music et ytmdesktop
Voir `docs/PROVIDERS.md`. En bref : pas d'API officielle pour le catalogue complet, donc l'étape 3 s'appuie sur YouTube Data API v3 et IFrame Player API, avec des limites assumées (lecteur visible, pas d'égaliseur, 100 recherches par jour).
ytmdesktop (GPL-3.0) sert de référence ; son Companion Server pourra devenir un fournisseur optionnel de contrôle à distance.

## Raccourcis par défaut
Espace : lecture/pause · Ctrl+→ / Ctrl+← : suivant / précédent · Ctrl+K : recherche · Ctrl+L : like · Ctrl+Q : file d'attente · Ctrl+, : paramètres · Ctrl+↑/↓ : volume · Ctrl+M : muet

## Suite
Voir `TASKS.md`. Prochaine action : premier build sur Windows et correction des erreurs.
