# Obtenir l'application sans rien installer (≈ 15 minutes)

GitHub compile MusicFlow pour toi sur un ordinateur Windows en ligne, gratuitement. Tu récupères ensuite l'installateur.

## 1. Créer un compte et un dépôt
1. Va sur **github.com** et crée un compte gratuit (ou connecte-toi).
2. Clique sur **+** (en haut à droite) › **New repository**.
3. Nom : `musicflow`. Laisse **Private** (privé) coché. Clique **Create repository**.

## 2. Envoyer le projet
1. Dézippe `musicflow-v0.2.1.zip` sur ton ordinateur.
2. Sur la page du dépôt, clique **uploading an existing file**.
3. Ouvre le dossier `musicflow` dézippé, sélectionne **tout son contenu** (Ctrl + A) et **glisse-le** dans la page web.
   Important : glisse le contenu, pas le dossier lui-même, et vérifie que le dossier **`.github`** apparaît bien dans la liste (il est caché sur certains systèmes).
4. Attends la fin du chargement, puis clique **Commit changes**.

> Si `.github` n'apparaît pas : clique **Add file › Create new file**, écris comme nom `.github/workflows/build-windows.yml`, colle le contenu du fichier du même nom (ouvre-le avec le Bloc-notes), puis **Commit changes**.

## 3. Lancer la compilation
1. Onglet **Actions**. Si GitHub demande d'activer les workflows, accepte.
2. Clique **Compiler MusicFlow pour Windows** (à gauche) › **Run workflow** › **Run workflow**.
3. Attends 10 à 20 minutes. Un rond jaune tourne ; il devient ✅ vert (réussi) ou ❌ rouge (erreur).

## 4. Récupérer l'application
1. Clique sur l'exécution terminée.
2. En bas de page, section **Artifacts** : télécharge **MusicFlow-Windows**.
3. Dézippe : tu y trouves l'installateur `MusicFlow_0.2.1_x64-setup.exe`. Double-clique pour installer.
   Windows peut afficher « Windows a protégé votre ordinateur » (l'application n'est pas signée) : **Informations complémentaires › Exécuter quand même**.

## Si c'est rouge ❌
C'est probable à la première fois : le code n'a jamais été compilé.
1. Ouvre l'exécution ❌, clique sur l'étape rouge (« Compiler l'application » ou « Installer les dépendances »).
2. Copie les dernières lignes rouges du journal et envoie-les moi : je corrige, tu renvoies les fichiers modifiés, et on relance.
