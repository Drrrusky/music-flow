# Fournisseurs de musique

MusicFlow sépare l'interface de la source de musique grâce au contrat `MusicProvider` (`src/core/providers/`).
L'interface lit `capabilities` et `limitations` pour griser ce qui n'existe pas, avec une explication.

## Local — fonctionnel
Fichiers audio de l'ordinateur, lus via Web Audio. Seule source où égaliseur, balance, normalisation et spectre sont **réels**.
Les métadonnées viennent des tags (ID3, Vorbis, MP4) lus par `music-metadata`.

## YouTube — étape 3, écrite et non testée
YouTube Music n'a **pas d'API officielle publique**. MusicFlow utilise les deux interfaces autorisées :

- **YouTube Data API v3** (recherche) : `search.list` filtré sur la catégorie Musique et les vidéos intégrables, puis `videos.list` pour les durées.
- **YouTube IFrame Player API** (lecture) : lecture, pause, position, volume. Aucun accès au flux audio.

### Quotas (documentation Google consultée le 21/11/2026, page mise à jour le 12/11/2026)
- `search.list` a son **propre compartiment : 100 appels par jour**, 1 point par appel.
- Tous les autres appels partagent **10 000 unités par jour** (`videos.list` = 1).
- Remise à zéro à **minuit, heure du Pacifique** (9 h en France).
- MusicFlow compte localement (indicatif) et ne lance une recherche YouTube que sur demande (bouton ou Ctrl + Entrée), jamais à chaque frappe.

> Correction : au début du projet j'avais annoncé « 10 000 unités par jour, recherche à 100 unités ». Ce n'est plus le cas : c'est 100 recherches par jour.

### Contraintes assumées
- **Le lecteur vidéo reste visible** tant qu'un titre YouTube est en cours : les conditions d'utilisation interdisent de masquer le lecteur ou d'isoler l'audio. Il apparaît en bas à droite.
- **Pas d'égaliseur, visualiseur, fondu enchaîné ni infos techniques** sur ces titres (flux inaccessible).
- **Pas d'albums, artistes, recommandations ni bibliothèque de compte** : aucune API officielle.
- **Titre et artiste sont déduits** du titre de la vidéo (heuristique) : approximatifs, signalés comme tels.
- **Seules les vidéos « intégrables »** sont proposées.

### Risque connu : erreur 153
Depuis juillet 2025, le lecteur renvoie l'erreur 153 quand la requête n'a pas d'en-tête **Referer** (ou identité de client API). Elle touche surtout les pages `file://`, les extensions et les schémas personnalisés.
Sur Windows, Tauri sert l'application en `http://tauri.localhost`, un vrai site HTTP : le Referer devrait être envoyé (la balise `referrer` est aussi posée dans `index.html`). **Non vérifié.**
Si l'erreur 153 apparaît : le bouton « Ouvrir sur YouTube » sert de repli, et la solution de fond est un petit serveur local (`http://127.0.0.1:port`) qui héberge la page du lecteur (voir TASKS.md).

### À vérifier avant toute distribution
Conditions d'utilisation de l'API YouTube, règles de conservation des données (les titres YouTube « likés » sont gardés en base : l'actualisation périodique des métadonnées est à prévoir), mentions de marque et politique de confidentialité.
La clé API est stockée en clair dans les réglages (stockage sécurisé prévu à l'étape 7).

## ytmdesktop (Companion Server) — optionnel, à confirmer avant l'étape 3
[ytmdesktop](https://github.com/ytmdesktop/ytmdesktop) est une application Electron (licence **GPL-3.0**) qui affiche le site officiel de YouTube Music et expose un serveur local pour applications tierces.
D'après la documentation de ses clients tiers : API REST et Socket.IO sur `127.0.0.1:9863`, avec autorisation explicite de l'utilisateur dans ytmdesktop.
Cela permettrait un fournisseur `ytmd-companion` qui **pilote** ytmdesktop (état de lecture, play/pause, suivant) sans catalogue.
Ne pas copier son code : la GPL imposerait de publier MusicFlow sous GPL-3.0. S'en inspirer pour l'architecture est possible.

## Métadonnées complémentaires (étape 4)
- **MusicBrainz** : crédits, ISRC, label, dates (API publique, limite de débit à respecter, `User-Agent` identifié).
- **LRCLIB** et fichiers `.lrc` : paroles synchronisées.
