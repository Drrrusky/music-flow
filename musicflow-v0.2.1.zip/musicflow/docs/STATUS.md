# État des fonctionnalités

> Généré depuis `src/core/features.ts` (affiché aussi dans Paramètres › État des fonctionnalités).
> « Fonctionnelle » signifie **implémentée dans le code**. Cette version n'a **pas encore été compilée ni exécutée sur Windows** : voir le README.

**12** fonctionnelles · **9** partielles · **9** en attente · **3** non disponibles

## Lecture

| Fonctionnalité | Statut | Remarque |
|---|---|---|
| Fichiers locaux (MP3, FLAC, OGG, Opus, M4A, AAC, WAV) | Fonctionnelle |  |
| Lecture, pause, suivant, précédent, barre de progression, volume | Fonctionnelle |  |
| Aléatoire et répétition (file, titre) | Fonctionnelle |  |
| Reprise de la dernière session | Fonctionnelle |  |
| Fondu enchaîné et lecture sans coupure | En attente | Demande deux lecteurs en parallèle (étape 4). |

## File d’attente

| Fonctionnalité | Statut | Remarque |
|---|---|---|
| Lire ensuite, ajouter, réordonner par glisser-déposer, retirer, vider, doublons évités | Fonctionnelle |  |
| Recommandations en fin de file, sauvegarde en playlist | En attente | Dépend des playlists et d’un catalogue en ligne. |

## Bibliothèque

| Fonctionnalité | Statut | Remarque |
|---|---|---|
| Dossiers, tags, pochettes, durées, base SQLite | Fonctionnelle |  |
| Likes, compteur d’écoutes, tri et filtres | Fonctionnelle |  |
| Historique d’écoute (page dédiée), sélection multiple | Partielle | Les données sont enregistrées ; la page et la sélection multiple arrivent à l’étape 4. |
| Playlists, dossiers, playlists intelligentes, import/export | En attente | Schéma SQLite prêt, interface à faire (étape 4). |

## Recherche

| Fonctionnalité | Statut | Remarque |
|---|---|---|
| Recherche locale instantanée (accents, surbrillance, clavier, Ctrl + K) | Fonctionnelle |  |

## Pages

| Fonctionnalité | Statut | Remarque |
|---|---|---|
| Pages album et artiste (données des fichiers) | Partielle | Pas de photo, biographie ni artistes similaires sans source en ligne. |
| Fiche détaillée d’un titre (tags et infos techniques réels) | Partielle | Crédits et anecdotes en attente de MusicBrainz. |

## Audio

| Fonctionnalité | Statut | Remarque |
|---|---|---|
| Égaliseur 10 bandes, préampli, balance, préréglages | Fonctionnelle | Fichiers locaux uniquement. |
| Normalisation du volume (ReplayGain) | Fonctionnelle | Appliquée aux fichiers qui contiennent ce tag. |
| Choix de la sortie audio | Partielle | Dépend de la version de WebView2 ; repli sur la sortie par défaut. |
| Spectre en direct | Partielle | Affiché dans l’égaliseur ; modes visualiseur plein écran à l’étape 4. |

## Windows

| Fonctionnalité | Statut | Remarque |
|---|---|---|
| Touches multimédias et panneau de contrôle Windows | Partielle | Via l’API Media Session de WebView2 : à vérifier sur Windows 10 et 11. |
| Zone de notification, démarrage automatique, notifications | En attente | Étape 6. |
| Installateur NSIS, mises à jour automatiques | Partielle | Installateur configuré ; mises à jour à l’étape 7. |

## Interface

| Fonctionnalité | Statut | Remarque |
|---|---|---|
| Thèmes, accent, flou, arrondis, densité, animations, barre latérale redimensionnable | Fonctionnelle |  |
| Réorganisation de la barre latérale, fonds personnalisés | En attente | Étape 6. |
| Raccourcis clavier par défaut | Fonctionnelle |  |
| Raccourcis personnalisables | En attente | Étape 6 (la table est déjà dans les réglages). |

## Paroles

| Fonctionnalité | Statut | Remarque |
|---|---|---|
| Paroles synchronisées et mode karaoké | En attente | Fichiers .lrc puis LRCLIB (étape 4). |

## Discord

| Fonctionnalité | Statut | Remarque |
|---|---|---|
| Rich Presence | En attente | Étape 5, via l’API officielle de Discord. |

## YouTube

| Fonctionnalité | Statut | Remarque |
|---|---|---|
| Recherche (Data API v3) et lecture (IFrame Player API) | Partielle | Écrite, jamais testée avec une vraie clé. 100 recherches par jour. Le lecteur vidéo reste visible (obligation des conditions d’utilisation). Erreur 153 possible : voir docs/PROVIDERS.md. |
| Enregistrer un titre YouTube dans la bibliothèque (cœur) | Partielle | Titres enregistrés avec leur miniature ; pas de page album ni artiste pour eux. |
| Albums, artistes, recommandations, bibliothèque du compte | Non disponible | YouTube Music n’a pas d’API officielle pour cela. |
| Égaliseur, balance, visualiseur, infos techniques | Non disponible | Le flux audio YouTube n’est pas accessible. |

## Fournisseurs

| Fonctionnalité | Statut | Remarque |
|---|---|---|
| Piloter ytmdesktop via son Companion Server | En attente | Optionnel. Contrôle de la lecture uniquement, pas de catalogue. |

## Social

| Fonctionnalité | Statut | Remarque |
|---|---|---|
| Profils, partage, activité des amis | Non disponible | Nécessite un service en ligne, hors périmètre pour l’instant. |


