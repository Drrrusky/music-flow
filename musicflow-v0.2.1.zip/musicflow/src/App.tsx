import { AnimatePresence, MotionConfig, motion } from 'framer-motion';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { useEffect } from 'react';
import { engine } from '@/core/playback/engine';
import { initMediaSession } from '@/core/playback/mediaSession';
import { useShortcuts } from '@/hooks/useShortcuts';
import { AlbumPage } from '@/features/library/AlbumPage';
import { ArtistPage } from '@/features/library/ArtistPage';
import { LibraryPage } from '@/features/library/LibraryPage';
import { HomePage } from '@/features/home/HomePage';
import { SearchPage } from '@/features/search/SearchPage';
import { SettingsPage } from '@/features/settings/SettingsPage';
import { useLibrary } from '@/stores/libraryStore';
import { useSettings } from '@/stores/settingsStore';
import { useUi, type Route } from '@/stores/uiStore';
import { onColor, rgbTriplet } from '@/utils/color';
import { Ambient } from '@/ui/Ambient';
import { ErrorBoundary } from '@/ui/ErrorBoundary';
import { IconButton } from '@/ui/IconButton';
import { ContextMenuHost, Toasts } from '@/ui/Overlays';
import { PlayerBar } from '@/ui/PlayerBar';
import { Sidebar } from '@/ui/Sidebar';
import { YouTubeSurface } from '@/ui/YouTubeSurface';
import { SidePanels } from '@/ui/SidePanels';

function useAppearance() {
  const { theme, accent, radius, blur, animations } = useSettings();
  useEffect(() => {
    const root = document.documentElement;
    const mq = window.matchMedia('(prefers-color-scheme: dark)');
    const apply = () => {
      const t = theme === 'auto' ? (mq.matches ? 'dark' : 'light') : theme;
      root.dataset.theme = t;
    };
    apply();
    mq.addEventListener('change', apply);
    return () => mq.removeEventListener('change', apply);
  }, [theme]);
  useEffect(() => {
    const root = document.documentElement;
    root.style.setProperty('--c-accent', rgbTriplet(accent));
    root.style.setProperty('--c-on-accent', onColor(accent));
  }, [accent]);
  useEffect(() => {
    const root = document.documentElement;
    root.style.setProperty('--r', `${radius}px`);
    root.style.setProperty('--blur', `${blur}px`);
  }, [radius, blur]);
  useEffect(() => { document.documentElement.dataset.motion = animations ? 'on' : 'off'; }, [animations]);
}

function Page({ route }: { route: Route }) {
  switch (route.name) {
    case 'home': return <HomePage />;
    case 'search': return <SearchPage />;
    case 'library': return <LibraryPage tab={route.tab} liked={route.liked} />;
    case 'album': return <AlbumPage albumKey={route.key} />;
    case 'artist': return <ArtistPage artistKey={route.key} />;
    case 'settings': return <SettingsPage initial={route.section} />;
  }
}

/** Les changements d'onglet ou de filtre dans une même page ne rejouent pas la transition. */
const pageKey = (r: Route) => (r.name === 'album' || r.name === 'artist' ? `${r.name}:${r.key}` : r.name === 'library' ? `library:${r.liked ? 'liked' : 'all'}` : r.name);

function TopBar() {
  const { past, future, back, forward } = useUi();
  return (
    <div className="flex h-14 shrink-0 items-center gap-1 px-5">
      <IconButton label="Précédent" size={34} disabled={!past.length} onClick={back} tipSide="bottom" className="bg-fg/[0.07]"><ChevronLeft size={19} /></IconButton>
      <IconButton label="Suivant" size={34} disabled={!future.length} onClick={forward} tipSide="bottom" className="bg-fg/[0.07]"><ChevronRight size={19} /></IconButton>
    </div>
  );
}

export default function App() {
  useAppearance();
  useShortcuts();
  const route = useUi((s) => s.route);

  useEffect(() => {
    // Page de démarrage choisie par l'utilisateur (sans l'ajouter à l'historique de navigation).
    const start = useSettings.getState().startPage;
    useUi.setState({ route: { name: start } });

    engine.init();
    initMediaSession();
    void useLibrary.getState().init().then(() => engine.restoreSession());

    const onError = (e: ErrorEvent) => useUi.getState().toast(`Erreur inattendue : ${e.message}`, 'error');
    const onRejection = (e: PromiseRejectionEvent) => useUi.getState().toast(`Erreur inattendue : ${e.reason instanceof Error ? e.reason.message : String(e.reason)}`, 'error');
    const noMenu = (e: MouseEvent) => { if (import.meta.env.PROD && !(e.target as HTMLElement).closest('input, textarea')) e.preventDefault(); };
    window.addEventListener('error', onError);
    window.addEventListener('unhandledrejection', onRejection);
    window.addEventListener('contextmenu', noMenu);
    return () => {
      window.removeEventListener('error', onError);
      window.removeEventListener('unhandledrejection', onRejection);
      window.removeEventListener('contextmenu', noMenu);
    };
  }, []);

  const animations = useSettings((s) => s.animations);

  return (
    <MotionConfig reducedMotion={animations ? 'user' : 'always'}>
      <div className="relative flex h-full flex-col gap-3 p-3">
        <Ambient />
        <div className="relative flex min-h-0 flex-1 gap-3">
          <Sidebar />
          <main className="glass hairline relative flex min-w-0 flex-1 flex-col overflow-hidden rounded-ui-lg">
            <TopBar />
            <div className="relative min-h-0 flex-1">
              <AnimatePresence mode="wait" initial={false}>
                <motion.div key={pageKey(route)} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} transition={{ duration: 0.16, ease: 'easeOut' }} className="absolute inset-0">
                  <ErrorBoundary key={pageKey(route)}><Page route={route} /></ErrorBoundary>
                </motion.div>
              </AnimatePresence>
            </div>
          </main>
          <SidePanels />
        </div>
        <div className="relative"><PlayerBar /></div>
        <YouTubeSurface />
        <Toasts />
        <ContextMenuHost />
      </div>
    </MotionConfig>
  );
}
