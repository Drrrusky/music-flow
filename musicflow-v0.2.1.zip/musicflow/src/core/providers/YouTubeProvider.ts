import type { MusicProvider } from './MusicProvider';

/**
 * Emplacement réservé (étape 3). Aucune fonction simulée : tout est déclaré indisponible
 * tant que l'intégration officielle (YouTube Data API v3 + IFrame Player API) n'est pas écrite.
 */
export const youtubeProvider: MusicProvider = {
  id: 'youtube',
  label: 'YouTube',
  capabilities: {
    search: false,
    albums: false,
    artists: false,
    recommendations: false,
    audioGraph: false,
    technicalInfo: false,
    library: false,
  },
  limitations: {
    audioGraph: 'Indisponible avec YouTube : le flux audio n’est pas accessible (lecture dans le lecteur intégré).',
    technicalInfo: 'Indisponible avec YouTube : codec, débit et ISRC ne sont pas exposés.',
    albums: 'YouTube Music n’a pas d’API officielle pour les albums et artistes.',
    artists: 'YouTube Music n’a pas d’API officielle pour les albums et artistes.',
    recommendations: 'YouTube Music n’a pas d’API officielle pour les recommandations.',
  },
  createBackend() {
    throw new Error('Le fournisseur YouTube n’est pas encore implémenté (étape 3).');
  },
};
