import { UNKNOWN_ARTIST } from '@/core/types';

/** Durée ISO 8601 de l'API YouTube (« PT4M13S », « PT1H2M3S », « P0D » pour un direct) → secondes. */
export function parseIsoDuration(iso: string): number {
  const m = /^P(?:(\d+)D)?(?:T(?:(\d+)H)?(?:(\d+)M)?(?:(\d+(?:\.\d+)?)S)?)?$/.exec(iso ?? '');
  if (!m) return 0;
  const [, d, h, mi, s] = m;
  return Math.round(Number(d ?? 0) * 86400 + Number(h ?? 0) * 3600 + Number(mi ?? 0) * 60 + Number(s ?? 0));
}

const NAMED: Record<string, string> = { amp: '&', lt: '<', gt: '>', quot: '"', apos: "'", nbsp: ' ' };

/** search.list renvoie des titres encodés en HTML (« &amp; », « &#39; »). */
export function decodeEntities(s: string): string {
  return s.replace(/&(#x[0-9a-f]+|#\d+|[a-z]+);/gi, (m, e: string) => {
    if (e[0] === '#') {
      const code = e[1].toLowerCase() === 'x' ? parseInt(e.slice(2), 16) : parseInt(e.slice(1), 10);
      try { return String.fromCodePoint(code); } catch { return m; }
    }
    return NAMED[e.toLowerCase()] ?? m;
  });
}

// Mentions de marketing entre parenthèses ou crochets ; « (feat. X) », « (Live) », « (Remix) » sont conservés.
const NOISE = /^(?:official\s*(?:music\s*)?(?:video|audio|lyric\s*video|visuali[sz]er)|(?:official\s*)?lyrics?(?:\s*video)?|(?:music\s*)?video|audio|clip\s*officiel|hd|hq|4k|remaster(?:ed)?(?:\s*\d{4})?|visuali[sz]er|mv|m\/v)$/i;

export function stripNoise(title: string): string {
  return title
    .replace(/\s*[([]([^)\]]*)[)\]]/g, (m, inner: string) => (NOISE.test(inner.trim()) ? '' : m))
    .replace(/\s{2,}/g, ' ')
    .trim();
}

/**
 * Déduit titre et artiste d'une vidéo. Heuristique prudente :
 * - chaîne « X - Topic » (contenu musical généré par YouTube) → artiste X ;
 * - titre « Artiste - Titre » → séparé sur le premier tiret entouré d'espaces ;
 * - sinon, la chaîne (sans « VEVO ») sert d'artiste.
 * Ce n'est pas une métadonnée certifiée : l'interface ne l'affiche que comme telle.
 */
export function parseTitle(rawTitle: string, rawChannel: string): { title: string; artists: string[] } {
  const title = stripNoise(decodeEntities(rawTitle));
  const channel = decodeEntities(rawChannel).trim();

  const topic = /^(.*?)\s*-\s*Topic$/i.exec(channel);
  if (topic && topic[1]) return { title, artists: [topic[1].trim()] };

  const sep = /\s[-–—]\s/.exec(title);
  if (sep && sep.index > 0) {
    const artist = title.slice(0, sep.index).trim();
    const rest = title.slice(sep.index + sep[0].length).trim();
    if (artist && rest) return { title: rest, artists: [artist] };
  }
  return { title, artists: [channel.replace(/VEVO$/i, '').trim() || UNKNOWN_ARTIST] };
}
