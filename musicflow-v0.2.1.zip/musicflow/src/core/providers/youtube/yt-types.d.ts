/** Déclarations minimales de l'IFrame Player API (https://www.youtube.com/iframe_api). */
declare namespace YT {
  interface PlayerVars {
    autoplay?: 0 | 1; controls?: 0 | 1; rel?: 0 | 1; playsinline?: 0 | 1; modestbranding?: 0 | 1;
    origin?: string; enablejsapi?: 0 | 1; hl?: string; iv_load_policy?: 1 | 3;
  }
  interface OnStateChangeEvent { data: number }
  interface OnErrorEvent { data: number }
  interface PlayerOptions {
    width?: string | number; height?: string | number; videoId?: string; playerVars?: PlayerVars;
    events?: { onReady?: () => void; onStateChange?: (e: OnStateChangeEvent) => void; onError?: (e: OnErrorEvent) => void };
  }
  class Player {
    constructor(el: HTMLElement | string, opts: PlayerOptions);
    cueVideoById(id: string): void;
    playVideo(): void; pauseVideo(): void; stopVideo(): void;
    seekTo(sec: number, allowSeekAhead: boolean): void;
    setVolume(v: number): void;
    getVideoData(): { video_id: string; title: string };
    getCurrentTime(): number; getDuration(): number; getPlayerState(): number;
    destroy(): void;
  }
}
interface Window {
  YT?: { Player: typeof YT.Player };
  onYouTubeIframeAPIReady?: () => void;
}
