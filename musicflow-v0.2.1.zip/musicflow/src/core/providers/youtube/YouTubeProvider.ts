import type { MusicProvider } from '../MusicProvider';
import { YouTubeBackend } from './YouTubeBackend';

/**
 * Catalogue : YouTube Data API v3 (recherche). Lecture : IFrame Player API.
 * Tout ce que ces deux interfaces officielles ne fournissent pas est déclaré indisponible.
 */
export const youtubeProvider: MusicProvider = {
  id: 'youtube',
  label: 'YouTube',
  capabilities: {
    search: true,
    albums: false,
    artists: false,
    recommendations: false,
    audioGraph: false,
    technicalInfo: false,
    library: true,
  },
  limitations: {
    audioGraph: 'Indisponible avec YouTube : le flux audio n’est pas accessible (lecture dans le lecteur intégré).',
    technicalInfo: 'Indisponible avec YouTube : codec, débit et ISRC ne sont pas exposés.',
    albums: 'YouTube Music n’a pas d’API officielle pour les albums et artistes.',
    artists: 'YouTube Music n’a pas d’API officielle pour les albums et artistes.',
    recommendations: 'YouTube Music n’a pas d’API officielle pour les recommandations.',
  },
  createBackend: () => new YouTubeBackend(),
};
