import type { Track } from '@/core/types';
import { Emitter, type BackendEvent, type PlaybackBackend } from '@/core/playback/backend';

export const YT_HOST_ID = 'mf-yt-host';

/** États renvoyés par l'IFrame Player API. */
const ENDED = 0, PLAYING = 1, PAUSED = 2, CUED = 5; // 3 (mise en mémoire tampon) et -1 ne changent rien pour nous

const ERRORS: Record<number, string> = {
  2: 'Identifiant de vidéo invalide.',
  5: 'Cette vidéo ne peut pas être lue par le lecteur HTML5.',
  100: 'Vidéo introuvable, supprimée ou privée.',
  101: 'Le propriétaire de la vidéo interdit sa lecture en dehors de YouTube.',
  150: 'Le propriétaire de la vidéo interdit sa lecture en dehors de YouTube.',
  153: 'YouTube refuse le lecteur intégré (en-tête Referer absent). Utilise « Ouvrir sur YouTube » en attendant un correctif.',
};

let apiReady: Promise<void> | null = null;
function loadIframeApi(): Promise<void> {
  if (window.YT?.Player) return Promise.resolve();
  apiReady ??= new Promise<void>((resolve, reject) => {
    const previous = window.onYouTubeIframeAPIReady;
    window.onYouTubeIframeAPIReady = () => { previous?.(); resolve(); };
    const s = document.createElement('script');
    s.src = 'https://www.youtube.com/iframe_api';
    s.onerror = () => { apiReady = null; reject(new Error('Impossible de charger le lecteur YouTube : vérifie ta connexion.')); };
    document.head.appendChild(s);
  });
  return apiReady;
}

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

/**
 * Lecture via l'IFrame Player API officielle.
 * Règle des conditions d'utilisation : le lecteur doit rester visible pendant la lecture
 * (il est affiché par `YouTubeSurface`). Aucun accès au flux audio : ni égaliseur ni visualiseur.
 */
export class YouTubeBackend implements PlaybackBackend {
  readonly id = 'youtube';
  private player?: YT.Player;
  private readonly bus = new Emitter();
  private timer?: number;
  private loading = false;
  private loadSeq = 0;
  private volume = 100;
  private onLoadError?: (e: Error) => void;

  get currentTime() { return this.player?.getCurrentTime?.() ?? 0; }
  get duration() { const d = this.player?.getDuration?.() ?? 0; return Number.isFinite(d) ? d : 0; }

  private async ensurePlayer(videoId: string): Promise<YT.Player> {
    if (this.player) return this.player;
    await loadIframeApi();
    const host = document.getElementById(YT_HOST_ID);
    if (!host) throw new Error('Zone du lecteur YouTube introuvable.');
    const holder = document.createElement('div');
    host.appendChild(holder);
    return new Promise<YT.Player>((resolve, reject) => {
      this.onLoadError = reject;
      const timeout = window.setTimeout(() => reject(new Error('Le lecteur YouTube ne répond pas.')), 15000);
      const p = new window.YT!.Player(holder, {
        width: '100%', height: '100%', videoId,
        playerVars: { autoplay: 0, controls: 1, rel: 0, playsinline: 1, modestbranding: 1, enablejsapi: 1, origin: window.location.origin, hl: 'fr' },
        events: {
          onReady: () => { window.clearTimeout(timeout); this.player = p; p.setVolume(this.volume); resolve(p); },
          onStateChange: (e) => this.onState(e.data),
          onError: (e) => this.onError(e.data),
        },
      });
    });
  }

  private onState(state: number) {
    if (state === PLAYING) { this.startClock(); this.bus.emit('playing'); }
    else if (state === PAUSED) { this.stopClock(); if (!this.loading) this.bus.emit('paused'); }
    else if (state === ENDED) { this.stopClock(); this.bus.emit('ended'); }
  }

  private onError(code: number) {
    const err = new Error(ERRORS[code] ?? `Erreur du lecteur YouTube (${code}).`);
    if (this.loading && this.onLoadError) this.onLoadError(err);
    else this.bus.emit('error', err.message);
  }

  async load(track: Track): Promise<void> {
    const seq = ++this.loadSeq;
    this.loading = true;
    this.stopClock();
    try {
      const player = await this.ensurePlayer(track.ref);
      if (seq !== this.loadSeq) return;
      // Pour une vidéo suivante, on la « met en file » sans la lancer ; la lecture est démarrée par play().
      if (!this.firstLoadDone) this.firstLoadDone = true;
      else player.cueVideoById(track.ref);
      // On attend que la durée soit connue (état « prêt ») : 10 s au plus.
      const failed = new Promise<never>((_, reject) => { this.onLoadError = reject; });
      const ready = (async () => {
        for (let i = 0; i < 100; i++) {
          if (seq !== this.loadSeq) return;
          // On vérifie qu'il s'agit bien de la nouvelle vidéo : la durée de la précédente ne compte pas.
          const sameVideo = player.getVideoData?.().video_id === track.ref;
          if (sameVideo && (player.getPlayerState() === CUED || player.getDuration() > 0)) return;
          await sleep(100);
        }
      })();
      await Promise.race([ready, failed]);
      if (seq === this.loadSeq) this.bus.emit('ready');
    } finally {
      this.onLoadError = undefined;
      if (seq === this.loadSeq) this.loading = false;
    }
  }
  private firstLoadDone = false;

  async play() { this.player?.playVideo(); }
  pause() { this.player?.pauseVideo(); }
  stop() { this.stopClock(); try { this.player?.stopVideo(); } catch { /* lecteur détruit */ } }
  seek(sec: number) { this.player?.seekTo(Math.max(0, sec), true); this.bus.emit('time', sec); }
  setVolume(v: number) { this.volume = Math.round(Math.max(0, Math.min(1, v)) * 100); this.player?.setVolume(this.volume); }
  on(ev: BackendEvent, cb: (arg?: unknown) => void) { return this.bus.on(ev, cb); }

  private startClock() {
    this.stopClock();
    this.timer = window.setInterval(() => this.bus.emit('time', this.currentTime), 250);
  }
  private stopClock() {
    if (this.timer !== undefined) window.clearInterval(this.timer);
    this.timer = undefined;
  }

  dispose() {
    this.stopClock();
    try { this.player?.destroy(); } catch { /* déjà détruit */ }
    this.player = undefined;
    this.firstLoadDone = false;
  }
}
