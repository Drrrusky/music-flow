/** Quotas par défaut de l'API YouTube Data v3 (documentation consultée le 21/11/2026). */
export const SEARCH_DAILY_LIMIT = 100; // search.list : compartiment propre, 1 point par appel
export const UNITS_DAILY_LIMIT = 10_000; // tous les autres appels (videos.list = 1)

export interface QuotaState { day: string; searches: number; units: number }
export interface KeyValueStore { getItem(k: string): string | null; setItem(k: string, v: string): void }

/** Les quotas se réinitialisent à minuit, heure du Pacifique. */
export const pacificDay = (d: Date): string =>
  new Intl.DateTimeFormat('en-CA', { timeZone: 'America/Los_Angeles', year: 'numeric', month: '2-digit', day: '2-digit' }).format(d);

/**
 * Compteur local, à titre indicatif : seule la console Google Cloud fait foi
 * (d'autres usages de la même clé ne sont pas vus ici).
 */
export class QuotaTracker {
  constructor(
    private readonly store: KeyValueStore,
    private readonly now: () => Date = () => new Date(),
    private readonly key = 'musicflow.yt.quota',
  ) {}

  state(): QuotaState {
    const today = pacificDay(this.now());
    try {
      const raw = this.store.getItem(this.key);
      if (raw) {
        const s = JSON.parse(raw) as QuotaState;
        if (s.day === today && Number.isFinite(s.searches) && Number.isFinite(s.units)) return s;
      }
    } catch { /* valeur corrompue : on repart de zéro */ }
    return { day: today, searches: 0, units: 0 };
  }

  private save(s: QuotaState) {
    try { this.store.setItem(this.key, JSON.stringify(s)); } catch { /* stockage indisponible */ }
  }

  recordSearch() { const s = this.state(); this.save({ ...s, searches: s.searches + 1 }); }
  recordUnits(n: number) { const s = this.state(); this.save({ ...s, units: s.units + n }); }
  searchesLeft() { return Math.max(0, SEARCH_DAILY_LIMIT - this.state().searches); }
  unitsLeft() { return Math.max(0, UNITS_DAILY_LIMIT - this.state().units); }
}
