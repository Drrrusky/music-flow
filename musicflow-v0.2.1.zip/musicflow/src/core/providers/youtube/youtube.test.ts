import { describe, expect, it } from 'vitest';
import { searchVideos, testApiKey, YouTubeApiError } from './api';
import { decodeEntities, parseIsoDuration, parseTitle, stripNoise } from './parse';
import { pacificDay, QuotaTracker, SEARCH_DAILY_LIMIT, type KeyValueStore } from './quota';

describe('durées ISO 8601', () => {
  it('formats courants', () => {
    expect(parseIsoDuration('PT4M13S')).toBe(253);
    expect(parseIsoDuration('PT1H2M3S')).toBe(3723);
    expect(parseIsoDuration('PT45S')).toBe(45);
    expect(parseIsoDuration('PT10M')).toBe(600);
    expect(parseIsoDuration('P1DT1H')).toBe(90000);
  });
  it('direct, vide ou invalide', () => {
    expect(parseIsoDuration('P0D')).toBe(0);
    expect(parseIsoDuration('')).toBe(0);
    expect(parseIsoDuration('abc')).toBe(0);
  });
});

describe('entités HTML', () => {
  it('décode nommées et numériques', () => {
    expect(decodeEntities('Beyoncé &amp; Jay-Z &#39;Crazy&#39; &quot;in Love&quot;')).toBe('Beyoncé & Jay-Z \'Crazy\' "in Love"');
    expect(decodeEntities('&#x41;&#66;')).toBe('AB');
  });
  it('laisse intact ce qui est inconnu ou invalide', () => {
    expect(decodeEntities('&foo; &#99999999;')).toBe('&foo; &#99999999;');
  });
});

describe('titre et artiste', () => {
  it('retire le bruit marketing, garde feat. et live', () => {
    expect(stripNoise('Get Lucky (Official Audio) [HD]')).toBe('Get Lucky');
    expect(stripNoise('Song (feat. X) (Live)')).toBe('Song (feat. X) (Live)');
    expect(stripNoise('Song (Official Music Video)')).toBe('Song');
  });
  it('« Artiste - Titre »', () => {
    expect(parseTitle('M83 - Midnight City (Official Video) [HD]', 'M83VEVO')).toEqual({ title: 'Midnight City', artists: ['M83'] });
  });
  it('chaîne « Topic »', () => {
    expect(parseTitle('Midnight City', 'M83 - Topic')).toEqual({ title: 'Midnight City', artists: ['M83'] });
  });
  it('sans séparateur : la chaîne devient l’artiste', () => {
    expect(parseTitle('Billie Jean', 'MichaelJacksonVEVO')).toEqual({ title: 'Billie Jean', artists: ['MichaelJackson'] });
  });
  it('tiret sans espaces : pas de séparation', () => {
    expect(parseTitle('Jay-Z Crazy', 'Chaîne')).toEqual({ title: 'Jay-Z Crazy', artists: ['Chaîne'] });
  });
  it('entités dans le titre', () => {
    expect(parseTitle('Simon &amp; Garfunkel - The Sound of Silence', 'x').artists).toEqual(['Simon & Garfunkel']);
  });
});

const memory = (): KeyValueStore & { data: Map<string, string> } => {
  const data = new Map<string, string>();
  return { data, getItem: (k) => data.get(k) ?? null, setItem: (k, v) => void data.set(k, v) };
};

describe('quota', () => {
  it('jour du Pacifique (heure d’hiver)', () => {
    expect(pacificDay(new Date('2026-11-21T07:59:00Z'))).toBe('2026-11-20');
    expect(pacificDay(new Date('2026-11-21T08:01:00Z'))).toBe('2026-11-21');
  });
  it('compte puis remet à zéro au changement de jour', () => {
    let now = new Date('2026-11-21T20:00:00Z');
    const q = new QuotaTracker(memory(), () => now);
    q.recordSearch(); q.recordSearch(); q.recordUnits(2);
    expect(q.state().searches).toBe(2);
    expect(q.searchesLeft()).toBe(SEARCH_DAILY_LIMIT - 2);
    now = new Date('2026-11-22T20:00:00Z');
    expect(q.state().searches).toBe(0);
    expect(q.state().units).toBe(0);
  });
  it('valeur corrompue : repart de zéro', () => {
    const s = memory(); s.setItem('musicflow.yt.quota', '{pas du json');
    expect(new QuotaTracker(s).state().searches).toBe(0);
  });
});

const json = (body: unknown, status = 200) => new Response(JSON.stringify(body), { status, headers: { 'content-type': 'application/json' } });

describe('searchVideos', () => {
  const search = { items: [
    { id: { videoId: 'a1' }, snippet: { title: 'M83 - Midnight City (Official Video)', channelTitle: 'M83VEVO', thumbnails: { high: { url: 'https://i.ytimg.com/a1.jpg' } } } },
    { id: { videoId: 'b2' }, snippet: { title: 'Interdit hors YouTube', channelTitle: 'X', thumbnails: { medium: { url: 'https://i.ytimg.com/b2.jpg' } } } },
    { id: { videoId: 'c3' }, snippet: { title: 'Direct 24/7', channelTitle: 'Y' } },
    { id: { videoId: 'd4' }, snippet: { title: 'Wait', channelTitle: 'M83 - Topic', thumbnails: { medium: { url: 'https://i.ytimg.com/d4.jpg' } } } },
  ] };
  const videos = { items: [
    { id: 'a1', contentDetails: { duration: 'PT4M3S' }, status: { embeddable: true } },
    { id: 'b2', contentDetails: { duration: 'PT3M' }, status: { embeddable: false } },
    { id: 'c3', contentDetails: { duration: 'P0D' }, status: { embeddable: true } },
    { id: 'd4', contentDetails: { duration: 'PT5M43S' }, status: { embeddable: true } },
  ] };

  it('mappe, filtre non intégrables et directs, garde l’ordre, compte le quota', async () => {
    const calls: string[] = [];
    const f = (async (url: string) => { calls.push(url); return json(url.includes('/search?') ? search : videos); }) as unknown as typeof fetch;
    const quota = new QuotaTracker(memory());
    const out = await searchVideos('KEY', 'm83', { fetch: f, quota, now: () => 1000 });
    expect(out.map((t) => t.id)).toEqual(['youtube:a1', 'youtube:d4']);
    expect(out[0]).toEqual({
      id: 'youtube:a1', provider: 'youtube', ref: 'a1', title: 'Midnight City', artists: ['M83'], durationSec: 243,
      coverUrl: 'https://i.ytimg.com/a1.jpg', channel: 'M83VEVO', addedAt: 1000, playCount: 0, liked: false,
    });
    expect(calls).toHaveLength(2);
    expect(calls[0]).toContain('videoEmbeddable=true');
    expect(quota.state().searches).toBe(1);
    expect(quota.state().units).toBe(1);
  });

  it('requête vide : aucun appel', async () => {
    let n = 0;
    const f = (async () => { n++; return json({}); }) as unknown as typeof fetch;
    expect(await searchVideos('KEY', '   ', { fetch: f })).toEqual([]);
    expect(n).toBe(0);
  });

  it('sans clé : erreur explicite', async () => {
    let err: unknown;
    try { await searchVideos('', 'x'); } catch (e) { err = e; }
    expect(err).toBeInstanceOf(YouTubeApiError);
  });

  it('quota local atteint : refuse sans appeler l’API', async () => {
    let n = 0;
    const f = (async () => { n++; return json({}); }) as unknown as typeof fetch;
    const quota = new QuotaTracker(memory());
    for (let i = 0; i < SEARCH_DAILY_LIMIT; i++) quota.recordSearch();
    let err: YouTubeApiError | undefined;
    try { await searchVideos('KEY', 'x', { fetch: f, quota }); } catch (e) { err = e as YouTubeApiError; }
    expect(err?.reason).toBe('quotaExceeded');
    expect(n).toBe(0);
  });

  it('erreurs de l’API traduites', async () => {
    const quotaBody = { error: { code: 403, message: 'quota', errors: [{ reason: 'quotaExceeded' }] } };
    const keyBody = { error: { code: 400, message: 'API key not valid. Please pass a valid API key.', errors: [{ reason: 'badRequest' }] } };
    let e1: YouTubeApiError | undefined, e2: YouTubeApiError | undefined;
    try { await searchVideos('K', 'x', { fetch: (async () => json(quotaBody, 403)) as unknown as typeof fetch }); } catch (e) { e1 = e as YouTubeApiError; }
    try { await testApiKey('K', { fetch: (async () => json(keyBody, 400)) as unknown as typeof fetch }); } catch (e) { e2 = e as YouTubeApiError; }
    expect(e1?.message).toContain('Quota YouTube épuisé');
    expect(e2?.message).toBe('Clé API invalide.');
  });

  it('réseau coupé : message clair', async () => {
    let err: YouTubeApiError | undefined;
    try { await searchVideos('K', 'x', { fetch: (async () => { throw new TypeError('Failed to fetch'); }) as unknown as typeof fetch }); } catch (e) { err = e as YouTubeApiError; }
    expect(err?.message).toContain('connexion');
  });
});
