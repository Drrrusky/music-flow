import type { Track } from '@/core/types';
import { parseIsoDuration, parseTitle } from './parse';
import { QuotaTracker, SEARCH_DAILY_LIMIT } from './quota';

const BASE = 'https://www.googleapis.com/youtube/v3';

export class YouTubeApiError extends Error {
  constructor(message: string, readonly status = 0, readonly reason?: string) {
    super(message);
    this.name = 'YouTubeApiError';
  }
}

const FRIENDLY: Record<string, string> = {
  quotaExceeded: 'Quota YouTube épuisé pour aujourd’hui (remise à zéro à minuit, heure du Pacifique).',
  rateLimitExceeded: 'Trop de requêtes : réessaie dans un instant.',
  accessNotConfigured: 'L’API YouTube Data v3 n’est pas activée pour cette clé dans la console Google Cloud.',
  forbidden: 'Accès refusé par YouTube pour cette clé.',
  ipRefererBlocked: 'Cette clé est restreinte à certains sites. Retire la restriction par référent dans la console Google Cloud.',
  keyInvalid: 'Clé API invalide.',
};

interface ApiErrorBody { error?: { code?: number; message?: string; errors?: { reason?: string }[] } }

async function call<T>(f: typeof fetch, path: string, params: Record<string, string>, signal?: AbortSignal): Promise<T> {
  let res: Response;
  try {
    res = await f(`${BASE}/${path}?${new URLSearchParams(params)}`, { signal });
  } catch (e) {
    if (e instanceof DOMException && e.name === 'AbortError') throw e;
    throw new YouTubeApiError('Impossible de joindre YouTube : vérifie ta connexion.');
  }
  if (res.ok) return (await res.json()) as T;

  let body: ApiErrorBody = {};
  try { body = (await res.json()) as ApiErrorBody; } catch { /* corps non JSON */ }
  const reason = body.error?.errors?.[0]?.reason;
  const message = body.error?.message ?? '';
  const key = /api key not valid/i.test(message) ? 'keyInvalid' : reason;
  throw new YouTubeApiError(FRIENDLY[key ?? ''] ?? (message || `Erreur YouTube (${res.status}).`), res.status, key);
}

interface SearchResponse { items?: { id?: { videoId?: string }; snippet?: { title?: string; channelTitle?: string; thumbnails?: Record<string, { url?: string }> } }[] }
interface VideosResponse { items?: { id: string; contentDetails?: { duration?: string }; status?: { embeddable?: boolean } }[] }

export interface SearchDeps { fetch?: typeof fetch; quota?: QuotaTracker; now?: () => number; signal?: AbortSignal }

/**
 * Recherche de morceaux : search.list (1 appel du compartiment « recherche », 100/jour) puis
 * videos.list (1 unité) pour les durées et pour écarter les vidéos non intégrables.
 */
export async function searchVideos(apiKey: string, query: string, deps: SearchDeps = {}): Promise<Track[]> {
  const f = deps.fetch ?? fetch.bind(globalThis);
  const q = query.trim();
  if (!apiKey.trim()) throw new YouTubeApiError('Aucune clé API YouTube n’est configurée (Paramètres › Sources en ligne).');
  if (!q) return [];
  if (deps.quota && deps.quota.searchesLeft() <= 0) {
    throw new YouTubeApiError(`Les ${SEARCH_DAILY_LIMIT} recherches quotidiennes sont atteintes (estimation locale). Remise à zéro à minuit, heure du Pacifique.`, 0, 'quotaExceeded');
  }

  const search = await call<SearchResponse>(f, 'search', {
    part: 'snippet', type: 'video', videoCategoryId: '10', videoEmbeddable: 'true', videoSyndicated: 'true',
    maxResults: '15', q, key: apiKey,
    fields: 'items(id/videoId,snippet(title,channelTitle,thumbnails(medium/url,high/url)))',
  }, deps.signal);
  deps.quota?.recordSearch();

  const hits = (search.items ?? []).filter((i) => i.id?.videoId && i.snippet);
  if (!hits.length) return [];

  const details = await call<VideosResponse>(f, 'videos', {
    part: 'contentDetails,status', id: hits.map((h) => h.id!.videoId!).join(','), key: apiKey,
    fields: 'items(id,contentDetails/duration,status/embeddable)',
  }, deps.signal);
  deps.quota?.recordUnits(1);

  const byId = new Map((details.items ?? []).map((d) => [d.id, d]));
  const now = (deps.now ?? Date.now)();
  const out: Track[] = [];
  for (const h of hits) {
    const id = h.id!.videoId!;
    const d = byId.get(id);
    if (!d || d.status?.embeddable === false) continue;
    const durationSec = parseIsoDuration(d.contentDetails?.duration ?? '');
    if (durationSec <= 0) continue; // directs et vidéos sans durée : pas des morceaux
    const sn = h.snippet!;
    const { title, artists } = parseTitle(sn.title ?? '', sn.channelTitle ?? '');
    out.push({
      id: `youtube:${id}`, provider: 'youtube', ref: id, title, artists, durationSec,
      coverUrl: sn.thumbnails?.high?.url ?? sn.thumbnails?.medium?.url, channel: sn.channelTitle,
      addedAt: now, playCount: 0, liked: false,
    });
  }
  return out;
}

/** Vérifie une clé avec un appel à 1 unité (n'utilise pas le compartiment de recherche). */
export async function testApiKey(apiKey: string, deps: Pick<SearchDeps, 'fetch' | 'quota'> = {}): Promise<void> {
  const f = deps.fetch ?? fetch.bind(globalThis);
  await call(f, 'videos', { part: 'id', id: 'dQw4w9WgXcQ', key: apiKey, fields: 'items(id)' });
  deps.quota?.recordUnits(1);
}
