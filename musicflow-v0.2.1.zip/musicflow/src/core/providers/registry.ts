import type { ProviderId } from '../types';
import type { MusicProvider } from './MusicProvider';
import { localProvider } from './LocalProvider';
import { youtubeProvider } from './YouTubeProvider';

const providers = new Map<ProviderId, MusicProvider>([
  [localProvider.id, localProvider],
  [youtubeProvider.id, youtubeProvider],
]);

export const getProvider = (id: ProviderId): MusicProvider => {
  const p = providers.get(id);
  if (!p) throw new Error(`Fournisseur inconnu : ${id}`);
  return p;
};
export const listProviders = () => [...providers.values()];
