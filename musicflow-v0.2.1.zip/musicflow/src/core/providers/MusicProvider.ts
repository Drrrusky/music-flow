import type { Capabilities, ProviderId } from '../types';
import type { PlaybackBackend } from '../playback/backend';

/**
 * Contrat unique entre l'interface et une source de musique.
 * L'interface lit `capabilities` pour griser ou masquer ce qui n'existe pas
 * (aucune fonction simulée). Les méthodes de catalogue (search, getAlbum…) sont ajoutées
 * par fournisseur au fur et à mesure.
 */
export interface MusicProvider {
  readonly id: ProviderId;
  readonly label: string;
  readonly capabilities: Capabilities;
  /** Explication affichée quand une capacité est absente (tooltip). */
  readonly limitations: Partial<Record<keyof Capabilities, string>>;
  createBackend(): PlaybackBackend;
}
