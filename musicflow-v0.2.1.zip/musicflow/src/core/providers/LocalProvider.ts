import type { MusicProvider } from './MusicProvider';
import { LocalBackend } from '../playback/LocalBackend';

export const localProvider: MusicProvider = {
  id: 'local',
  label: 'Bibliothèque locale',
  capabilities: {
    search: true,
    albums: true,
    artists: true,
    recommendations: false,
    audioGraph: true,
    technicalInfo: true,
    library: true,
  },
  limitations: {
    recommendations: 'Les recommandations nécessitent un catalogue en ligne.',
  },
  createBackend: () => new LocalBackend(),
};
