export type ProviderId = 'local' | 'youtube' | 'ytmd-companion';

export type FeatureStatus = 'functional' | 'partial' | 'pending' | 'unavailable';

export interface TechInfo {
  container?: string;
  codec?: string;
  bitrateKbps?: number;
  sampleRateHz?: number;
  bitsPerSample?: number;
  channels?: number;
  lossless?: boolean;
  sizeBytes?: number;
}

export interface Track {
  /** Identifiant stable : `${provider}:${hash}` */
  id: string;
  provider: ProviderId;
  /** Chemin de fichier (local) ou identifiant fournisseur (ex. videoId). */
  ref: string;
  title: string;
  artists: string[];
  albumArtist?: string;
  album?: string;
  year?: number;
  genre?: string;
  trackNo?: number;
  discNo?: number;
  durationSec: number;
  coverKey?: string;
  /** Pochette distante (miniature YouTube) quand il n'y en a pas de locale. */
  coverUrl?: string;
  /** Chaîne ou source d'origine (YouTube). */
  channel?: string;
  isrc?: string;
  label?: string;
  replayGainDb?: number;
  tech?: TechInfo;
  addedAt: number;
  playCount: number;
  lastPlayedAt?: number;
  liked: boolean;
}

export interface Album {
  key: string;
  title: string;
  artist: string;
  year?: number;
  genre?: string;
  coverKey?: string;
  tracks: Track[];
  durationSec: number;
  addedAt: number;
}

export interface Artist {
  key: string;
  name: string;
  tracks: Track[];
  albumKeys: string[];
  coverKey?: string;
}

/** Ce qu'un fournisseur sait réellement faire. L'interface s'adapte à ces drapeaux. */
export interface Capabilities {
  search: boolean;
  albums: boolean;
  artists: boolean;
  recommendations: boolean;
  /** Accès au flux audio : égaliseur, balance, visualiseur, normalisation. */
  audioGraph: boolean;
  technicalInfo: boolean;
  library: boolean;
}

export const UNKNOWN_ARTIST = 'Artiste inconnu';
export const UNKNOWN_ALBUM = 'Album inconnu';
