import type { FeatureStatus } from './types';

export interface Feature { area: string; name: string; status: FeatureStatus; note?: string }

/**
 * Source unique de vérité sur l'état des fonctionnalités (affichée dans Paramètres, reprise dans docs/STATUS.md).
 * « Fonctionnelle » = implémentée dans le code. Voir le README : cette version n'a pas encore été compilée sur Windows.
 */
export const FEATURES: Feature[] = [
  { area: 'Lecture', name: 'Fichiers locaux (MP3, FLAC, OGG, Opus, M4A, AAC, WAV)', status: 'functional' },
  { area: 'Lecture', name: 'Lecture, pause, suivant, précédent, barre de progression, volume', status: 'functional' },
  { area: 'Lecture', name: 'Aléatoire et répétition (file, titre)', status: 'functional' },
  { area: 'Lecture', name: 'Reprise de la dernière session', status: 'functional' },
  { area: 'Lecture', name: 'Fondu enchaîné et lecture sans coupure', status: 'pending', note: 'Demande deux lecteurs en parallèle (étape 4).' },
  { area: 'File d’attente', name: 'Lire ensuite, ajouter, réordonner par glisser-déposer, retirer, vider, doublons évités', status: 'functional' },
  { area: 'File d’attente', name: 'Recommandations en fin de file, sauvegarde en playlist', status: 'pending', note: 'Dépend des playlists et d’un catalogue en ligne.' },
  { area: 'Bibliothèque', name: 'Dossiers, tags, pochettes, durées, base SQLite', status: 'functional' },
  { area: 'Bibliothèque', name: 'Likes, compteur d’écoutes, tri et filtres', status: 'functional' },
  { area: 'Bibliothèque', name: 'Historique d’écoute (page dédiée), sélection multiple', status: 'partial', note: 'Les données sont enregistrées ; la page et la sélection multiple arrivent à l’étape 4.' },
  { area: 'Bibliothèque', name: 'Playlists, dossiers, playlists intelligentes, import/export', status: 'pending', note: 'Schéma SQLite prêt, interface à faire (étape 4).' },
  { area: 'Recherche', name: 'Recherche locale instantanée (accents, surbrillance, clavier, Ctrl + K)', status: 'functional' },
  { area: 'Pages', name: 'Pages album et artiste (données des fichiers)', status: 'partial', note: 'Pas de photo, biographie ni artistes similaires sans source en ligne.' },
  { area: 'Pages', name: 'Fiche détaillée d’un titre (tags et infos techniques réels)', status: 'partial', note: 'Crédits et anecdotes en attente de MusicBrainz.' },
  { area: 'Audio', name: 'Égaliseur 10 bandes, préampli, balance, préréglages', status: 'functional', note: 'Fichiers locaux uniquement.' },
  { area: 'Audio', name: 'Normalisation du volume (ReplayGain)', status: 'functional', note: 'Appliquée aux fichiers qui contiennent ce tag.' },
  { area: 'Audio', name: 'Choix de la sortie audio', status: 'partial', note: 'Dépend de la version de WebView2 ; repli sur la sortie par défaut.' },
  { area: 'Audio', name: 'Spectre en direct', status: 'partial', note: 'Affiché dans l’égaliseur ; modes visualiseur plein écran à l’étape 4.' },
  { area: 'Windows', name: 'Touches multimédias et panneau de contrôle Windows', status: 'partial', note: 'Via l’API Media Session de WebView2 : à vérifier sur Windows 10 et 11.' },
  { area: 'Windows', name: 'Zone de notification, démarrage automatique, notifications', status: 'pending', note: 'Étape 6.' },
  { area: 'Windows', name: 'Installateur NSIS, mises à jour automatiques', status: 'partial', note: 'Installateur configuré ; mises à jour à l’étape 7.' },
  { area: 'Interface', name: 'Thèmes, accent, flou, arrondis, densité, animations, barre latérale redimensionnable', status: 'functional' },
  { area: 'Interface', name: 'Réorganisation de la barre latérale, fonds personnalisés', status: 'pending', note: 'Étape 6.' },
  { area: 'Interface', name: 'Raccourcis clavier par défaut', status: 'functional' },
  { area: 'Interface', name: 'Raccourcis personnalisables', status: 'pending', note: 'Étape 6 (la table est déjà dans les réglages).' },
  { area: 'Paroles', name: 'Paroles synchronisées et mode karaoké', status: 'pending', note: 'Fichiers .lrc puis LRCLIB (étape 4).' },
  { area: 'Discord', name: 'Rich Presence', status: 'pending', note: 'Étape 5, via l’API officielle de Discord.' },
  { area: 'YouTube', name: 'Recherche (Data API v3) et lecture (IFrame Player API)', status: 'partial', note: 'Écrite, jamais testée avec une vraie clé. 100 recherches par jour. Le lecteur vidéo reste visible (obligation des conditions d’utilisation). Erreur 153 possible : voir docs/PROVIDERS.md.' },
  { area: 'YouTube', name: 'Enregistrer un titre YouTube dans la bibliothèque (cœur)', status: 'partial', note: 'Titres enregistrés avec leur miniature ; pas de page album ni artiste pour eux.' },
  { area: 'YouTube', name: 'Albums, artistes, recommandations, bibliothèque du compte', status: 'unavailable', note: 'YouTube Music n’a pas d’API officielle pour cela.' },
  { area: 'YouTube', name: 'Égaliseur, balance, visualiseur, infos techniques', status: 'unavailable', note: 'Le flux audio YouTube n’est pas accessible.' },
  { area: 'Fournisseurs', name: 'Piloter ytmdesktop via son Companion Server', status: 'pending', note: 'Optionnel. Contrôle de la lecture uniquement, pas de catalogue.' },
  { area: 'Social', name: 'Profils, partage, activité des amis', status: 'unavailable', note: 'Nécessite un service en ligne, hors périmètre pour l’instant.' },
];
