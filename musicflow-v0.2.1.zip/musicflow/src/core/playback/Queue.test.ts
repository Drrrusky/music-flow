import { describe, expect, it } from 'vitest';
import type { Track } from '../types';
import {
  advance, clearUpcoming, createQueue, currentOf, enqueue, move, playNext,
  previousIndex, removeAt, setUpcoming, toggleShuffle, upcomingOf,
} from './Queue';

const mk = (n: number): Track => ({
  id: `local:${n}`, provider: 'local', ref: `/m/${n}.mp3`, title: `T${n}`, artists: ['A'],
  durationSec: 100, addedAt: 0, playCount: 0, liked: false,
});
const list = (n: number) => Array.from({ length: n }, (_, i) => mk(i));
const ids = (ts: Track[]) => ts.map((t) => t.id.split(':')[1]).join(',');
const seq = (vals: number[]) => { let i = 0; return () => vals[i++ % vals.length]; };

describe('createQueue', () => {
  it('démarre à l’index demandé sans modifier l’ordre', () => {
    const q = createQueue(list(5), 2);
    expect(q.index).toBe(2);
    expect(ids(q.items)).toBe('0,1,2,3,4');
    expect(q.original).toBeNull();
  });
  it('en mode aléatoire, le titre choisi passe en premier et rien ne se perd', () => {
    const q = createQueue(list(6), 3, true, seq([0.1, 0.9, 0.5]));
    expect(currentOf(q)?.id).toBe('local:3');
    expect(q.index).toBe(0);
    expect([...q.items].map((t) => t.id).sort()).toEqual(list(6).map((t) => t.id).sort());
    expect(ids(q.original!)).toBe('0,1,2,3,4,5');
  });
  it('ignore les doublons et borne l’index', () => {
    const q = createQueue([mk(1), mk(1), mk(2)], 99);
    expect(ids(q.items)).toBe('1,2');
    expect(q.index).toBe(1);
  });
  it('file vide', () => expect(createQueue([], 0).index).toBe(-1));
});

describe('toggleShuffle', () => {
  it('garde les titres déjà lus et le titre courant, mélange la suite', () => {
    const q = toggleShuffle(createQueue(list(8), 2), true, seq([0.3, 0.7, 0.1]));
    expect(ids(q.items.slice(0, 3))).toBe('0,1,2');
    expect(q.index).toBe(2);
    expect(q.items).toHaveLength(8);
  });
  it('restaure l’ordre d’origine et retrouve le titre courant', () => {
    const on = toggleShuffle(createQueue(list(6), 1), true, seq([0.2, 0.8]));
    const adv = { ...on, index: 3 };
    const cur = currentOf(adv)!;
    const off = toggleShuffle(adv, false);
    expect(ids(off.items)).toBe('0,1,2,3,4,5');
    expect(currentOf(off)?.id).toBe(cur.id);
    expect(off.original).toBeNull();
  });
  it('conserve les ajouts et retire les suppressions faits pendant l’aléatoire', () => {
    let q = toggleShuffle(createQueue(list(4), 0), true, seq([0.5]));
    q = enqueue(q, [mk(9)]);
    const victim = q.items[q.items.length - 2];
    q = removeAt(q, q.items.indexOf(victim));
    const off = toggleShuffle(q, false);
    expect(off.items.some((t) => t.id === 'local:9')).toBe(true);
    expect(off.items.some((t) => t.id === victim.id)).toBe(false);
  });
});

describe('playNext / enqueue', () => {
  it('« lire ensuite » insère juste après le titre courant', () => {
    const q = playNext(createQueue(list(4), 1), [mk(9)]);
    expect(ids(q.items)).toBe('0,1,9,2,3');
    expect(q.index).toBe(1);
  });
  it('« lire ensuite » déplace un titre déjà à suivre', () => {
    const q = playNext(createQueue(list(5), 0), [mk(4)]);
    expect(ids(q.items)).toBe('0,4,1,2,3');
  });
  it('« lire ensuite » avec un titre déjà lu garde un index correct', () => {
    const q = playNext(createQueue(list(5), 3), [mk(0)]);
    expect(ids(q.items)).toBe('1,2,3,0,4');
    expect(currentOf(q)?.id).toBe('local:3');
  });
  it('« lire ensuite » sur une file vide crée la file', () => {
    expect(currentOf(playNext(createQueue([], 0), [mk(7)]))?.id).toBe('local:7');
  });
  it('« ajouter à la suite » ignore les doublons', () => {
    const q = enqueue(createQueue(list(3), 0), [mk(1), mk(5)]);
    expect(ids(q.items)).toBe('0,1,2,5');
  });
});

describe('removeAt / move / setUpcoming / clearUpcoming', () => {
  it('ne retire jamais le titre courant', () => {
    const q = createQueue(list(3), 1);
    expect(removeAt(q, 1)).toBe(q);
  });
  it('retirer un titre déjà lu décale l’index', () => {
    const q = removeAt(createQueue(list(4), 2), 0);
    expect(q.index).toBe(1);
    expect(currentOf(q)?.id).toBe('local:2');
  });
  it('move garde le titre courant', () => {
    const base = createQueue(list(6), 2);
    for (const [from, to] of [[0, 4], [5, 0], [2, 5], [4, 1], [1, 2]] as const) {
      const q = move(base, from, to);
      expect(currentOf(q)?.id).toBe('local:2');
      expect(q.items).toHaveLength(6);
    }
  });
  it('setUpcoming remplace la suite sans toucher à l’historique', () => {
    const q = setUpcoming(createQueue(list(5), 1), [mk(4), mk(3), mk(0)]);
    expect(ids(q.items)).toBe('0,1,4,3');
  });
  it('clearUpcoming ne garde que le passé et le titre courant', () => {
    const q = clearUpcoming(createQueue(list(5), 2));
    expect(ids(q.items)).toBe('0,1,2');
    expect(upcomingOf(q)).toHaveLength(0);
  });
});

describe('advance / previousIndex', () => {
  const q = createQueue(list(3), 2);
  it('fin de file sans répétition', () => expect(advance(q, 'off', false)).toBeNull());
  it('répétition de la file', () => expect(advance(q, 'all', false)).toBe(0));
  it('répétition d’un titre : automatique oui, manuel non', () => {
    expect(advance(q, 'one', false)).toBe(2);
    expect(advance(createQueue(list(3), 0), 'one', true)).toBe(1);
  });
  it('précédent', () => {
    expect(previousIndex(createQueue(list(3), 2), 'off')).toBe(1);
    expect(previousIndex(createQueue(list(3), 0), 'off')).toBe(0);
    expect(previousIndex(createQueue(list(3), 0), 'all')).toBe(2);
  });
});
