import { readFile } from '@tauri-apps/plugin-fs';
import type { Track } from '../types';
import { Emitter, type BackendEvent, type PlaybackBackend } from './backend';
import { getAudioGraph } from './AudioGraph';
import { mimeOf } from '@/utils/audio';

/**
 * Lecture de fichiers locaux. Le fichier est lu en mémoire puis servi via une URL blob de même origine :
 * c'est ce qui autorise le branchement sur Web Audio (une URL cross-origin produirait du silence).
 * Limite connue : un très gros fichier (WAV de plusieurs centaines de Mo) occupe autant de mémoire.
 */
export class LocalBackend implements PlaybackBackend {
  readonly id = 'local';
  private readonly audio = new Audio();
  private readonly bus = new Emitter();
  private objectUrl?: string;
  private loading = false;
  private loadSeq = 0;
  private timer?: number;
  private readonly graph = getAudioGraph();

  constructor() {
    this.audio.preload = 'auto';
    this.graph.attach(this.audio);
    const a = this.audio;
    a.addEventListener('playing', () => { this.startClock(); this.bus.emit('playing'); });
    a.addEventListener('pause', () => { this.stopClock(); if (!this.loading) this.bus.emit('paused'); });
    a.addEventListener('ended', () => { this.stopClock(); this.bus.emit('ended'); });
    a.addEventListener('seeked', () => this.bus.emit('time', a.currentTime));
    a.addEventListener('error', () => { if (!this.loading) this.bus.emit('error', a.error?.message || 'Lecture impossible'); });
  }

  get currentTime() { return this.audio.currentTime; }
  get duration() { return Number.isFinite(this.audio.duration) ? this.audio.duration : 0; }

  async load(track: Track): Promise<void> {
    const seq = ++this.loadSeq;
    this.loading = true;
    this.audio.pause();
    try {
      const bytes = await readFile(track.ref);
      if (seq !== this.loadSeq) return; // une autre lecture a été demandée entre-temps
      if (this.objectUrl) URL.revokeObjectURL(this.objectUrl);
      this.objectUrl = URL.createObjectURL(new Blob([bytes as BlobPart], { type: mimeOf(track.ref) }));
      this.audio.src = this.objectUrl;
      await new Promise<void>((resolve, reject) => {
        const ok = () => { cleanup(); resolve(); };
        const ko = () => { cleanup(); reject(new Error('Format non pris en charge ou fichier illisible')); };
        const cleanup = () => { this.audio.removeEventListener('loadedmetadata', ok); this.audio.removeEventListener('error', ko); };
        this.audio.addEventListener('loadedmetadata', ok, { once: true });
        this.audio.addEventListener('error', ko, { once: true });
      });
      this.bus.emit('ready');
    } finally {
      if (seq === this.loadSeq) this.loading = false;
    }
  }

  async play() {
    await this.graph.resume();
    await this.audio.play();
  }
  pause() { this.audio.pause(); }
  stop() { this.audio.pause(); this.audio.currentTime = 0; }
  seek(sec: number) { this.audio.currentTime = Math.max(0, Math.min(sec, this.duration || sec)); }
  setVolume(v: number) { this.graph.setVolume(v); }
  on(ev: BackendEvent, cb: (arg?: unknown) => void) { return this.bus.on(ev, cb); }

  private startClock() {
    this.stopClock();
    this.timer = window.setInterval(() => this.bus.emit('time', this.audio.currentTime), 100);
  }
  private stopClock() {
    if (this.timer !== undefined) window.clearInterval(this.timer);
    this.timer = undefined;
  }

  dispose() {
    this.stopClock();
    this.audio.pause();
    if (this.objectUrl) URL.revokeObjectURL(this.objectUrl);
  }
}
