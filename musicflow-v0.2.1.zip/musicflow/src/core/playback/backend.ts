import type { Track } from '../types';

export type BackendEvent = 'time' | 'ended' | 'error' | 'playing' | 'paused' | 'ready';

/** Contrat d'un moteur de lecture. Un fournisseur en fournit un (audio natif, iframe, …). */
export interface PlaybackBackend {
  readonly id: string;
  load(track: Track): Promise<void>;
  play(): Promise<void>;
  pause(): void;
  stop(): void;
  seek(sec: number): void;
  setVolume(v: number): void;
  readonly currentTime: number;
  readonly duration: number;
  on(ev: BackendEvent, cb: (arg?: unknown) => void): () => void;
  dispose(): void;
}

export class Emitter {
  private map = new Map<BackendEvent, Set<(arg?: unknown) => void>>();
  on(ev: BackendEvent, cb: (arg?: unknown) => void): () => void {
    let set = this.map.get(ev);
    if (!set) this.map.set(ev, (set = new Set()));
    set.add(cb);
    return () => set!.delete(cb);
  }
  emit(ev: BackendEvent, arg?: unknown) {
    this.map.get(ev)?.forEach((cb) => cb(arg));
  }
}
