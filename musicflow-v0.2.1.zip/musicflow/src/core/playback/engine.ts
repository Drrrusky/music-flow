import type { ProviderId, Track } from '../types';
import { getProvider } from '../providers/registry';
import type { PlaybackBackend } from './backend';
import { getAudioGraph } from './AudioGraph';
import {
  advance, clearUpcoming, createQueue, currentOf, enqueue, playNext, previousIndex,
  removeAt, setUpcoming, toggleShuffle, upcomingOf, move, type QueueState,
} from './Queue';
import { usePlayer } from '@/stores/playerStore';
import { useSettings } from '@/stores/settingsStore';
import { useLibrary } from '@/stores/libraryStore';
import { useUi } from '@/stores/uiStore';
import { artistLine } from '@/utils/groups';

const SESSION_KEY = 'musicflow.session';
const COUNT_AFTER_SEC = 30;
const MAX_CONSECUTIVE_ERRORS = 3;

interface SavedSession { ids: string[]; index: number; position: number; shuffle: boolean; repeat: 'off' | 'all' | 'one' }

class PlaybackEngine {
  private backends = new Map<ProviderId, PlaybackBackend>();
  private active?: PlaybackBackend;
  private seq = 0;
  private errorStreak = 0;
  private counted = false;
  private saveTimer?: number;
  private started = false;

  // ───────── initialisation ─────────

  init() {
    if (this.started) return;
    this.started = true;
    const apply = () => {
      const s = useSettings.getState();
      const g = getAudioGraph();
      g.applyEq(s.eq);
      g.setVolume(s.muted ? 0 : s.volume);
    };
    apply();
    const s0 = useSettings.getState();
    if (s0.outputDeviceId) void getAudioGraph().setOutputDevice(s0.outputDeviceId);

    useSettings.subscribe((s, prev) => {
      if (s.eq !== prev.eq) getAudioGraph().applyEq(s.eq);
      if (s.normalize !== prev.normalize) this.applyTrackAudio(usePlayer.getState().current);
      if (s.outputDeviceId !== prev.outputDeviceId) {
        void getAudioGraph().setOutputDevice(s.outputDeviceId).then((ok) => {
          if (!ok) useUi.getState().toast('Impossible de changer de sortie audio : la sortie par défaut est conservée.', 'error');
        });
      }
    });

    usePlayer.subscribe((s, prev) => {
      if (s.queue !== prev.queue || s.shuffle !== prev.shuffle || s.repeat !== prev.repeat || Math.floor(s.position / 5) !== Math.floor(prev.position / 5)) {
        this.scheduleSave();
      }
    });
  }

  /** À appeler quand la bibliothèque est chargée. */
  restoreSession() {
    if (!useSettings.getState().resumeLastSession) return;
    try {
      const raw = localStorage.getItem(SESSION_KEY);
      if (!raw) return;
      const saved = JSON.parse(raw) as SavedSession;
      const byId = useLibrary.getState().byId;
      const items = saved.ids.map((id) => byId.get(id)).filter((t): t is Track => !!t);
      if (!items.length) return;
      const wanted = saved.ids[saved.index];
      const index = Math.max(0, items.findIndex((t) => t.id === wanted));
      const queue: QueueState = { items, index, original: saved.shuffle ? items.slice() : null };
      usePlayer.setState({ queue, shuffle: saved.shuffle, repeat: saved.repeat });
      void this.loadCurrent(false, saved.position);
    } catch {
      localStorage.removeItem(SESSION_KEY);
    }
  }

  private scheduleSave() {
    if (this.saveTimer !== undefined) return;
    this.saveTimer = window.setTimeout(() => {
      this.saveTimer = undefined;
      const s = usePlayer.getState();
      if (!s.queue.items.length) return localStorage.removeItem(SESSION_KEY);
      const data: SavedSession = {
        ids: s.queue.items.map((t) => t.id), index: s.queue.index, position: s.position, shuffle: s.shuffle, repeat: s.repeat,
      };
      try { localStorage.setItem(SESSION_KEY, JSON.stringify(data)); } catch { /* quota : on ignore */ }
    }, 1500);
  }

  // ───────── backends ─────────

  private backendFor(track: Track): PlaybackBackend {
    let b = this.backends.get(track.provider);
    if (!b) {
      b = getProvider(track.provider).createBackend();
      this.wire(b);
      this.backends.set(track.provider, b);
    }
    return b;
  }

  private wire(b: PlaybackBackend) {
    const mine = () => b === this.active;
    b.on('time', () => {
      if (!mine()) return;
      const position = b.currentTime;
      usePlayer.setState({ position });
      const cur = usePlayer.getState().current;
      const dur = b.duration || cur?.durationSec || 0;
      if (!this.counted && cur && (position >= COUNT_AFTER_SEC || (dur > 0 && position >= dur / 2))) {
        this.counted = true;
        useLibrary.getState().recordPlay(cur.id);
      }
    });
    b.on('playing', () => { if (mine()) usePlayer.setState({ status: 'playing', error: undefined }); });
    b.on('paused', () => { if (mine() && usePlayer.getState().status === 'playing') usePlayer.setState({ status: 'paused' }); });
    b.on('ended', () => { if (mine()) void this.next(false); });
    b.on('error', (msg) => { if (mine()) this.fail(String(msg)); });
    b.on('ready', () => {
      if (!mine()) return;
      const cur = usePlayer.getState().current;
      usePlayer.setState({ duration: b.duration || cur?.durationSec || 0 });
      // La durée lue par le décodeur fait foi : on corrige la valeur estimée à l'analyse.
      if (cur && b.duration) useLibrary.getState().updateDuration(cur.id, b.duration);
    });
  }

  private applyTrackAudio(track: Track | null) {
    if (!track) return;
    const caps = getProvider(track.provider).capabilities;
    if (caps.audioGraph) getAudioGraph().setReplayGain(track.replayGainDb, useSettings.getState().normalize);
  }

  private pushVolume() {
    const { volume, muted } = usePlayer.getState();
    const v = muted ? 0 : volume;
    this.backends.forEach((b) => b.setVolume(v));
    getAudioGraph().setVolume(v);
  }

  // ───────── lecture ─────────

  async loadCurrent(autoplay = true, startAt = 0) {
    const track = currentOf(usePlayer.getState().queue);
    if (!track) return;
    const seq = ++this.seq;

    let backend: PlaybackBackend;
    try {
      backend = this.backendFor(track);
    } catch (e) {
      this.fail(e instanceof Error ? e.message : String(e), track);
      return;
    }
    if (this.active && this.active !== backend) this.active.stop();
    this.active = backend;
    this.counted = false;
    usePlayer.setState({ current: track, status: 'loading', position: startAt, duration: track.durationSec, error: undefined });

    try {
      await backend.load(track);
      if (seq !== this.seq) return;
      this.applyTrackAudio(track);
      this.pushVolume();
      if (startAt > 0) backend.seek(startAt);
      if (autoplay) await backend.play();
      else usePlayer.setState({ status: 'paused' });
      if (seq === this.seq) this.errorStreak = 0;
    } catch (e) {
      if (seq !== this.seq) return;
      this.fail(e instanceof Error ? e.message : String(e), track);
    }
  }

  private fail(message: string, track?: Track | null) {
    const t = track ?? usePlayer.getState().current;
    useUi.getState().toast(`Lecture impossible${t ? ` : « ${t.title} »` : ''}. ${message}`, 'error');
    this.errorStreak++;
    const q = usePlayer.getState().queue;
    if (this.errorStreak < MAX_CONSECUTIVE_ERRORS && advance(q, 'off', true) !== null) {
      void this.next(true);
    } else {
      this.errorStreak = 0;
      usePlayer.setState({ status: 'error', error: message });
    }
  }

  async playTracks(tracks: Track[], startIndex = 0, shuffle?: boolean) {
    if (!tracks.length) return;
    const sh = shuffle ?? usePlayer.getState().shuffle;
    this.errorStreak = 0;
    usePlayer.setState({ queue: createQueue(tracks, startIndex, sh), shuffle: sh });
    await this.loadCurrent(true);
  }

  async toggle() {
    const s = usePlayer.getState();
    if (s.status === 'playing') return this.pause();
    if (s.status === 'loading') return;
    if (s.status === 'paused' && this.active) {
      try { await this.active.play(); } catch (e) { this.fail(e instanceof Error ? e.message : String(e)); }
      return;
    }
    if (currentOf(s.queue)) await this.loadCurrent(true, s.position);
  }

  pause() { this.active?.pause(); }

  async next(manual = true) {
    const s = usePlayer.getState();
    const idx = advance(s.queue, s.repeat, manual);
    if (idx === null) {
      if (!manual) {
        this.active?.stop();
        usePlayer.setState({ status: 'paused', position: 0 });
      }
      return;
    }
    if (idx === s.queue.index && s.repeat === 'one' && this.active) {
      this.counted = false;
      this.active.seek(0);
      await this.active.play().catch(() => undefined);
      return;
    }
    usePlayer.setState({ queue: { ...s.queue, index: idx } });
    await this.loadCurrent(true);
  }

  async prev() {
    const s = usePlayer.getState();
    if (s.position > 3 || (s.queue.index <= 0 && s.repeat !== 'all')) {
      this.seek(0);
      return;
    }
    usePlayer.setState({ queue: { ...s.queue, index: previousIndex(s.queue, s.repeat) } });
    await this.loadCurrent(true);
  }

  async jumpTo(index: number) {
    const s = usePlayer.getState();
    if (index < 0 || index >= s.queue.items.length) return;
    usePlayer.setState({ queue: { ...s.queue, index } });
    await this.loadCurrent(true);
  }

  seek(sec: number) {
    if (!this.active) return;
    this.active.seek(sec);
    usePlayer.setState({ position: sec });
  }

  // ───────── volume / modes ─────────

  setVolume(v: number) {
    const volume = Math.max(0, Math.min(1, v));
    usePlayer.setState({ volume, muted: false });
    useSettings.getState().update({ volume, muted: false });
    this.pushVolume();
  }

  toggleMute() {
    const muted = !usePlayer.getState().muted;
    usePlayer.setState({ muted });
    useSettings.getState().update({ muted });
    this.pushVolume();
  }

  toggleShuffle() {
    const s = usePlayer.getState();
    const shuffle = !s.shuffle;
    usePlayer.setState({ shuffle, queue: toggleShuffle(s.queue, shuffle) });
  }

  cycleRepeat() {
    const order = ['off', 'all', 'one'] as const;
    const cur = usePlayer.getState().repeat;
    usePlayer.setState({ repeat: order[(order.indexOf(cur) + 1) % order.length] });
  }

  // ───────── file d'attente ─────────

  private commitQueue(queue: QueueState, loadIfNew = false) {
    const hadCurrent = !!usePlayer.getState().current;
    usePlayer.setState({ queue });
    if (loadIfNew && !hadCurrent && currentOf(queue)) void this.loadCurrent(false);
  }

  playNextTracks(tracks: Track[]) {
    const before = usePlayer.getState().queue;
    const q = playNext(before, tracks);
    if (q === before) return useUi.getState().toast('Déjà en cours de lecture.');
    this.commitQueue(q, true);
    useUi.getState().toast(tracks.length > 1 ? `${tracks.length} titres lus ensuite.` : 'Sera lu ensuite.', 'success');
  }

  enqueueTracks(tracks: Track[]) {
    const before = usePlayer.getState().queue;
    const q = enqueue(before, tracks);
    if (q === before) return useUi.getState().toast('Déjà dans la file d’attente.');
    this.commitQueue(q, true);
    useUi.getState().toast('Ajouté à la file d’attente.', 'success');
  }

  removeFromQueue(index: number) { this.commitQueue(removeAt(usePlayer.getState().queue, index)); }
  moveInQueue(from: number, to: number) { this.commitQueue(move(usePlayer.getState().queue, from, to)); }
  reorderUpcoming(upcoming: Track[]) { this.commitQueue(setUpcoming(usePlayer.getState().queue, upcoming)); }
  clearUpcomingTracks() { this.commitQueue(clearUpcoming(usePlayer.getState().queue)); }
  upcoming() { return upcomingOf(usePlayer.getState().queue); }

  /** Texte court pour les notifications et la session média. */
  describe(t: Track) { return `${t.title} — ${artistLine(t)}`; }
}

export const engine = new PlaybackEngine();
