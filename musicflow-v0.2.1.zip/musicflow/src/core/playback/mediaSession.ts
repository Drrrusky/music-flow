import { usePlayer } from '@/stores/playerStore';
import { loadCover } from '@/services/covers';
import { artistLine } from '@/utils/groups';
import { engine } from './engine';

/**
 * Branche l'API Media Session : touches multimédias du clavier et panneau de contrôle Windows (SMTC).
 * Statut : partiel — dépend du support de WebView2 ; à vérifier sur Windows 10 et 11.
 */
let started = false;
export function initMediaSession() {
  if (started || !('mediaSession' in navigator)) return;
  started = true;
  const ms = navigator.mediaSession;

  const set = (action: MediaSessionAction, handler: MediaSessionActionHandler) => {
    try { ms.setActionHandler(action, handler); } catch { /* action non prise en charge */ }
  };
  set('play', () => { if (usePlayer.getState().status !== 'playing') void engine.toggle(); });
  set('pause', () => engine.pause());
  set('previoustrack', () => void engine.prev());
  set('nexttrack', () => void engine.next(true));
  set('seekto', (d) => { if (d.seekTime !== undefined) engine.seek(d.seekTime); });
  set('stop', () => engine.pause());

  let lastId: string | undefined;
  usePlayer.subscribe((s, prev) => {
    ms.playbackState = s.status === 'playing' ? 'playing' : s.status === 'paused' ? 'paused' : 'none';

    if (s.current?.id !== lastId) {
      lastId = s.current?.id;
      const t = s.current;
      if (!t) { ms.metadata = null; return; }
      ms.metadata = new MediaMetadata({ title: t.title, artist: artistLine(t), album: t.album ?? '' });
      const setArt = (src?: string) => {
        if (src && lastId === t.id) {
          ms.metadata = new MediaMetadata({ title: t.title, artist: artistLine(t), album: t.album ?? '', artwork: [{ src, sizes: '400x400', type: 'image/jpeg' }] });
        }
      };
      if (t.coverKey) void loadCover(t.coverKey).then(setArt);
      else setArt(t.coverUrl);
    }

    // La position n'est envoyée qu'aux changements d'état ou de durée (pas à chaque tick).
    if (s.status !== prev.status || s.duration !== prev.duration) {
      try {
        if (s.duration > 0) ms.setPositionState({ duration: s.duration, position: Math.min(s.position, s.duration), playbackRate: 1 });
      } catch { /* valeurs incohérentes : on ignore */ }
    }
  });
}
