/**
 * Graphe audio Web Audio — la seule partie de MusicFlow où l'égaliseur, la balance,
 * la normalisation et le visualiseur sont réels (le flux audio est accessible).
 *
 *  <audio> → replayGain → préampli → 10 filtres → balance → analyseur → volume → sortie
 */
export const EQ_FREQS = [31, 62, 125, 250, 500, 1000, 2000, 4000, 8000, 16000] as const;
export const EQ_LABELS = ['31', '62', '125', '250', '500', '1k', '2k', '4k', '8k', '16k'] as const;

export interface EqSettings {
  enabled: boolean;
  preamp: number; // dB
  bands: number[]; // 10 valeurs en dB, -12..+12
  preset: string;
  balance: number; // -1 (gauche) .. +1 (droite)
}

export const EQ_PRESETS: Record<string, number[]> = {
  Flat: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
  'Bass Boost': [6, 5, 4, 2, 0, 0, 0, 0, 0, 0],
  Rock: [4, 3, 2, -1, -2, -1, 2, 3, 4, 4],
  Pop: [-1, 1, 3, 4, 3, 0, -1, -1, -1, -1],
  Jazz: [3, 2, 1, 2, -2, -2, 0, 1, 2, 3],
  Classique: [4, 3, 3, 2, -1, -1, 0, 2, 3, 4],
  Électro: [5, 4, 1, 0, -2, 2, 1, 1, 4, 5],
  Vocal: [-2, -3, -3, 1, 4, 4, 3, 1, 0, -1],
  Acoustic: [4, 4, 3, 1, 1, 1, 3, 3, 3, 2],
};

export const defaultEq = (): EqSettings => ({
  enabled: true,
  preamp: 0,
  bands: EQ_PRESETS.Flat.slice(),
  preset: 'Flat',
  balance: 0,
});

const dbToGain = (db: number) => Math.pow(10, db / 20);

export class AudioGraph {
  readonly ctx: AudioContext;
  private source?: MediaElementAudioSourceNode;
  private readonly rg: GainNode;
  private readonly pre: GainNode;
  private readonly filters: BiquadFilterNode[];
  private readonly pan: StereoPannerNode;
  readonly analyser: AnalyserNode;
  private readonly master: GainNode;

  constructor() {
    this.ctx = new AudioContext({ latencyHint: 'playback' });
    this.rg = this.ctx.createGain();
    this.pre = this.ctx.createGain();
    this.pan = this.ctx.createStereoPanner();
    this.analyser = this.ctx.createAnalyser();
    this.analyser.fftSize = 2048;
    this.analyser.smoothingTimeConstant = 0.82;
    this.master = this.ctx.createGain();

    this.filters = EQ_FREQS.map((f, i) => {
      const b = this.ctx.createBiquadFilter();
      b.type = i === 0 ? 'lowshelf' : i === EQ_FREQS.length - 1 ? 'highshelf' : 'peaking';
      b.frequency.value = f;
      b.Q.value = 1.0;
      b.gain.value = 0;
      return b;
    });

    let node: AudioNode = this.rg;
    node.connect(this.pre);
    node = this.pre;
    for (const f of this.filters) {
      node.connect(f);
      node = f;
    }
    node.connect(this.pan);
    this.pan.connect(this.analyser);
    this.analyser.connect(this.master);
    this.master.connect(this.ctx.destination);
  }

  /** À appeler une seule fois par élément <audio>. */
  attach(el: HTMLMediaElement) {
    if (this.source) return;
    this.source = this.ctx.createMediaElementSource(el);
    this.source.connect(this.rg);
  }

  async resume() {
    if (this.ctx.state !== 'running') await this.ctx.resume();
  }

  private ramp(param: AudioParam, value: number, tc = 0.02) {
    param.setTargetAtTime(value, this.ctx.currentTime, tc);
  }

  /** Volume 0..1 avec courbe quadratique (plus proche de la perception). */
  setVolume(v: number) {
    this.ramp(this.master.gain, Math.max(0, Math.min(1, v)) ** 2, 0.015);
  }

  /** Normalisation ReplayGain, bornée à ±12 dB. `undefined` ou désactivé = neutre. */
  setReplayGain(db: number | undefined, enabled: boolean) {
    const g = enabled && db !== undefined && Number.isFinite(db) ? dbToGain(Math.max(-12, Math.min(12, db))) : 1;
    this.ramp(this.rg.gain, g, 0.03);
  }

  applyEq(eq: EqSettings) {
    this.ramp(this.pre.gain, eq.enabled ? dbToGain(eq.preamp) : 1);
    this.filters.forEach((f, i) => this.ramp(f.gain, eq.enabled ? eq.bands[i] ?? 0 : 0));
    this.ramp(this.pan.pan, Math.max(-1, Math.min(1, eq.balance)));
  }

  /** Sortie audio : Chromium/WebView2 expose `AudioContext.setSinkId`. */
  async setOutputDevice(deviceId: string): Promise<boolean> {
    const ctx = this.ctx as AudioContext & { setSinkId?: (id: string) => Promise<void> };
    if (typeof ctx.setSinkId !== 'function') return false;
    try {
      await ctx.setSinkId(deviceId || '');
      return true;
    } catch {
      return false;
    }
  }
}

let graph: AudioGraph | null = null;
export const getAudioGraph = () => (graph ??= new AudioGraph());
