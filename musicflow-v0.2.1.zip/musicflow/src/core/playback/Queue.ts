import type { Track } from '../types';

export type RepeatMode = 'off' | 'all' | 'one';
export type Rng = () => number;

/**
 * File d'attente immuable.
 * - `items` : ordre de lecture effectif (déjà lus, courant, à suivre).
 * - `original` : ordre d'origine, conservé uniquement quand le mode aléatoire est actif.
 * Règle de doublons : un même morceau n'apparaît qu'une fois dans la file.
 */
export interface QueueState {
  items: Track[];
  index: number;
  original: Track[] | null;
}

export const emptyQueue = (): QueueState => ({ items: [], index: -1, original: null });

export function shuffled<T>(arr: T[], rng: Rng = Math.random): T[] {
  const a = arr.slice();
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(rng() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

function unique(tracks: Track[]): Track[] {
  const seen = new Set<string>();
  return tracks.filter((t) => (seen.has(t.id) ? false : (seen.add(t.id), true)));
}

export function createQueue(tracks: Track[], start = 0, shuffle = false, rng: Rng = Math.random): QueueState {
  const initial = unique(tracks);
  if (!initial.length) return emptyQueue();
  const s = Math.min(Math.max(start, 0), initial.length - 1);
  if (!shuffle) return { items: initial, index: s, original: null };
  const first = initial[s];
  const rest = initial.filter((_, i) => i !== s);
  return { items: [first, ...shuffled(rest, rng)], index: 0, original: initial };
}

export const currentOf = (q: QueueState): Track | null => q.items[q.index] ?? null;
export const upcomingOf = (q: QueueState): Track[] => q.items.slice(q.index + 1);
export const playedOf = (q: QueueState): Track[] => q.items.slice(0, Math.max(q.index, 0));

export function toggleShuffle(q: QueueState, on: boolean, rng: Rng = Math.random): QueueState {
  if (on) {
    if (q.original) return q;
    const head = q.items.slice(0, q.index + 1);
    const rest = shuffled(q.items.slice(q.index + 1), rng);
    return { items: [...head, ...rest], index: q.index, original: q.items.slice() };
  }
  if (!q.original) return q;
  const cur = currentOf(q);
  const known = new Set(q.original.map((t) => t.id));
  const present = new Set(q.items.map((t) => t.id));
  // On retire de l'ordre d'origine ce qui a été supprimé, et on ajoute ce qui a été ajouté.
  const items = [...q.original.filter((t) => present.has(t.id)), ...q.items.filter((t) => !known.has(t.id))];
  const idx = cur ? items.findIndex((t) => t.id === cur.id) : -1;
  return { items, index: idx >= 0 ? idx : Math.min(q.index, items.length - 1), original: null };
}

/** « Lire ensuite » : insère juste après le morceau courant. Un morceau déjà présent est déplacé. */
export function playNext(q: QueueState, tracks: Track[]): QueueState {
  const cur = currentOf(q);
  const incoming = unique(tracks).filter((t) => t.id !== cur?.id);
  if (!incoming.length) return q;
  if (q.index < 0) return createQueue(incoming, 0);
  const ids = new Set(incoming.map((t) => t.id));
  const head = q.items.slice(0, q.index + 1).filter((t, i) => i === q.index || !ids.has(t.id));
  const tail = q.items.slice(q.index + 1).filter((t) => !ids.has(t.id));
  return {
    items: [...head, ...incoming, ...tail],
    index: head.length - 1,
    original: q.original ? insertAfter(q.original, cur, incoming) : null,
  };
}

/** « Ajouter à la suite » : à la fin de la file. Ignore les morceaux déjà présents. */
export function enqueue(q: QueueState, tracks: Track[]): QueueState {
  const present = new Set(q.items.map((t) => t.id));
  const incoming = unique(tracks).filter((t) => !present.has(t.id));
  if (!incoming.length) return q;
  if (q.index < 0) return { items: incoming, index: 0, original: null };
  return { items: [...q.items, ...incoming], index: q.index, original: q.original ? [...q.original, ...incoming] : null };
}

function insertAfter(list: Track[], after: Track | null, incoming: Track[]): Track[] {
  const ids = new Set(incoming.map((t) => t.id));
  const base = list.filter((t) => !ids.has(t.id));
  const at = after ? base.findIndex((t) => t.id === after.id) : -1;
  return [...base.slice(0, at + 1), ...incoming, ...base.slice(at + 1)];
}

/** Retire un morceau à venir. Le morceau courant ne peut pas être retiré ici. */
export function removeAt(q: QueueState, i: number): QueueState {
  if (i === q.index || i < 0 || i >= q.items.length) return q;
  const gone = q.items[i];
  const items = q.items.filter((_, k) => k !== i);
  return {
    items,
    index: i < q.index ? q.index - 1 : q.index,
    original: q.original ? q.original.filter((t) => t.id !== gone.id) : null,
  };
}

/** Déplace un élément et garde l'index du morceau courant cohérent. */
export function move(q: QueueState, from: number, to: number): QueueState {
  const n = q.items.length;
  if (from === to || from < 0 || to < 0 || from >= n || to >= n) return q;
  const items = q.items.slice();
  const [m] = items.splice(from, 1);
  items.splice(to, 0, m);
  let index = q.index;
  if (from === q.index) index = to;
  else if (from < q.index && to >= q.index) index = q.index - 1;
  else if (from > q.index && to <= q.index) index = q.index + 1;
  return { ...q, items, index };
}

/** Remplace la partie « à suivre » (utilisé par le glisser-déposer). */
export function setUpcoming(q: QueueState, upcoming: Track[]): QueueState {
  const head = q.items.slice(0, q.index + 1);
  const ids = new Set(head.map((t) => t.id));
  return { ...q, items: [...head, ...unique(upcoming).filter((t) => !ids.has(t.id))] };
}

export function clearUpcoming(q: QueueState): QueueState {
  const head = q.items.slice(0, q.index + 1);
  return { items: head, index: q.index, original: q.original ? head.slice() : null };
}

/** Prochain index. `manual` : l'utilisateur appuie sur « suivant » (la répétition d'un titre est ignorée). */
export function advance(q: QueueState, repeat: RepeatMode, manual: boolean): number | null {
  if (!q.items.length || q.index < 0) return null;
  if (repeat === 'one' && !manual) return q.index;
  if (q.index + 1 < q.items.length) return q.index + 1;
  if (repeat === 'all') return 0;
  return null;
}

export function previousIndex(q: QueueState, repeat: RepeatMode): number {
  if (q.index > 0) return q.index - 1;
  return repeat === 'all' && q.items.length ? q.items.length - 1 : 0;
}
