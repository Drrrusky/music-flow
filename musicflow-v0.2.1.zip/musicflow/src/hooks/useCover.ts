import { useEffect, useState } from 'react';
import { loadCover, peekCover } from '@/services/covers';
import { dominantColor } from '@/utils/color';

export function useCover(key?: string): string | undefined {
  const [src, setSrc] = useState<string | undefined>(() => peekCover(key));
  useEffect(() => {
    let alive = true;
    if (!key) { setSrc(undefined); return; }
    const hit = peekCover(key);
    if (hit) { setSrc(hit); return; }
    setSrc(undefined);
    void loadCover(key).then((d) => { if (alive) setSrc(d); });
    return () => { alive = false; };
  }, [key]);
  return src;
}

const colorCache = new Map<string, [number, number, number] | undefined>();

/** Couleur dominante de la pochette, pour l'arrière-plan dynamique. */
export function useDominantColor(key?: string, url?: string): [number, number, number] | undefined {
  const stored = useCover(key);
  const src = stored ?? url;
  const id = key ?? url;
  const [rgb, setRgb] = useState<[number, number, number] | undefined>(() => (id ? colorCache.get(id) : undefined));
  useEffect(() => {
    let alive = true;
    if (!id || !src) { setRgb(undefined); return; }
    if (colorCache.has(id)) { setRgb(colorCache.get(id)); return; }
    void dominantColor(src).then((c) => { colorCache.set(id, c); if (alive) setRgb(c); });
    return () => { alive = false; };
  }, [id, src]);
  return rgb;
}
