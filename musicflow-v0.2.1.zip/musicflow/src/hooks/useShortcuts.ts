import { useEffect } from 'react';
import { engine } from '@/core/playback/engine';
import { useLibrary } from '@/stores/libraryStore';
import { usePlayer } from '@/stores/playerStore';
import { useSettings, type ShortcutAction } from '@/stores/settingsStore';
import { useUi } from '@/stores/uiStore';
import { comboOf } from '@/utils/shortcuts';

const EDITING = ['INPUT', 'TEXTAREA', 'SELECT'];
/** Dans un champ de saisie, seules les actions qui n'entrent pas en conflit avec l'édition de texte restent actives. */
const SAFE_WHILE_TYPING: ShortcutAction[] = ['search', 'settings', 'queue'];

const actions: Record<ShortcutAction, () => void> = {
  playPause: () => void engine.toggle(),
  next: () => void engine.next(true),
  prev: () => void engine.prev(),
  search: () => useUi.getState().focusSearch(),
  like: () => { const c = usePlayer.getState().current; if (c) useLibrary.getState().toggleLike(c.id); },
  queue: () => useUi.getState().toggleQueue(),
  settings: () => useUi.getState().navigate({ name: 'settings' }),
  volumeUp: () => engine.setVolume(usePlayer.getState().volume + 0.05),
  volumeDown: () => engine.setVolume(usePlayer.getState().volume - 0.05),
  mute: () => engine.toggleMute(),
};

export function useShortcuts() {
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const combo = comboOf(e);
      if (!combo) return;

      // En version installée, on neutralise les raccourcis du navigateur qui n'ont pas de sens ici.
      if (import.meta.env.PROD && (e.key === 'F5' || (e.ctrlKey && ['r', 'p', 'f', 'g', 'u', 's'].includes(e.key.toLowerCase())))) {
        e.preventDefault();
      }

      const target = e.target as HTMLElement | null;
      const typing = !!target && (EDITING.includes(target.tagName) || target.isContentEditable);
      const onControl = !!target?.closest('button, a, [role="slider"], [role="switch"], [role="radio"], [role="tab"]');

      const shortcuts = useSettings.getState().shortcuts;
      const action = (Object.keys(shortcuts) as ShortcutAction[]).find((a) => shortcuts[a] === combo);
      if (!action) return;
      if (typing && !SAFE_WHILE_TYPING.includes(action)) return;
      // Espace sur un bouton doit activer ce bouton, pas lancer la lecture.
      if (combo === 'space' && onControl) return;

      e.preventDefault();
      actions[action]();
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, []);
}
