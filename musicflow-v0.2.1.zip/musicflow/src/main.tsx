import '@fontsource-variable/sora';
import '@fontsource-variable/instrument-sans';
import './styles/index.css';
import { createRoot } from 'react-dom/client';
import App from './App';

createRoot(document.getElementById('root')!).render(<App />);
