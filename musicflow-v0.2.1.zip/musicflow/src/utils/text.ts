/** Minuscules sans accents, pour comparer et rechercher. */
export function norm(s: string): string {
  return s.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().trim();
}

/** 0 = aucun résultat. Plus haut = meilleur. */
export function matchScore(query: string, text: string): number {
  const q = norm(query);
  if (!q) return 0;
  const t = norm(text);
  if (t === q) return 100;
  if (t.startsWith(q)) return 80;
  if (t.includes(' ' + q)) return 60;
  if (t.includes(q)) return 40;
  const words = q.split(/\s+/).filter(Boolean);
  if (words.length > 1 && words.every((w) => t.includes(w))) return 30;
  return 0;
}

/** Découpe `text` en segments marqués selon l'occurrence de `query` (insensible aux accents). */
export function highlight(text: string, query: string): { text: string; hit: boolean }[] {
  const q = norm(query);
  if (!q) return [{ text, hit: false }];
  // norm() peut changer la longueur : on garde une table de correspondance d'indices.
  let plain = '';
  const map: number[] = [];
  for (let i = 0; i < text.length; i++) {
    const n = norm(text[i]);
    for (let k = 0; k < n.length; k++) {
      plain += n[k];
      map.push(i);
    }
  }
  const at = plain.indexOf(q);
  if (at < 0) return [{ text, hit: false }];
  const start = map[at];
  const end = map[at + q.length - 1] + 1;
  return [
    { text: text.slice(0, start), hit: false },
    { text: text.slice(start, end), hit: true },
    { text: text.slice(end), hit: false },
  ].filter((s) => s.text.length > 0);
}
