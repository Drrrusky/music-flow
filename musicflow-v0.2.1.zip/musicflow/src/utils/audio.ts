export const AUDIO_EXT = new Set(['mp3', 'flac', 'ogg', 'oga', 'opus', 'm4a', 'aac', 'wav']);

const MIME: Record<string, string> = {
  mp3: 'audio/mpeg', flac: 'audio/flac', ogg: 'audio/ogg', oga: 'audio/ogg', opus: 'audio/ogg',
  m4a: 'audio/mp4', aac: 'audio/aac', wav: 'audio/wav',
};

export const extOf = (path: string) => path.split('.').pop()?.toLowerCase() ?? '';
export const mimeOf = (path: string) => MIME[extOf(path)] ?? 'audio/mpeg';
export const isAudioFile = (name: string) => AUDIO_EXT.has(extOf(name));

export const joinPath = (dir: string, name: string) =>
  dir.endsWith('\\') || dir.endsWith('/') ? dir + name : dir + (dir.includes('\\') ? '\\' : '/') + name;

export const baseName = (path: string) => path.split(/[\\/]/).pop() ?? path;
export const stripExt = (name: string) => name.replace(/\.[^.]+$/, '');

/** Le chemin `ref` est-il dans le dossier `root` ? (évite que « Music » corresponde à « Music2 ») */
export function isUnder(ref: string, root: string): boolean {
  const r = root.replace(/[\\/]+$/, '');
  return ref === r || ref.startsWith(r + '\\') || ref.startsWith(r + '/');
}
