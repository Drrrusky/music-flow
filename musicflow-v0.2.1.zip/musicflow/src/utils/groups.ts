import type { Album, Artist, Track } from '@/core/types';
import { UNKNOWN_ALBUM, UNKNOWN_ARTIST } from '@/core/types';
import { hash53 } from './hash';
import { norm } from './text';

export const primaryArtist = (t: Track) => t.albumArtist || t.artists[0] || UNKNOWN_ARTIST;
export const artistLine = (t: Track) => (t.artists.length ? t.artists.join(', ') : UNKNOWN_ARTIST);
export const albumKeyOf = (t: Track) => hash53(norm(primaryArtist(t)) + '|' + norm(t.album || UNKNOWN_ALBUM));
export const artistKeyOf = (name: string) => hash53('artist|' + norm(name));

const byTrackOrder = (a: Track, b: Track) =>
  (a.discNo ?? 1) - (b.discNo ?? 1) || (a.trackNo ?? 9999) - (b.trackNo ?? 9999) || a.title.localeCompare(b.title);

export function buildAlbums(tracks: Track[]): Album[] {
  const map = new Map<string, Album>();
  for (const t of tracks) {
    // Un titre distant sans album (YouTube) ne forme pas un « Album inconnu » par artiste.
    if (!t.album && t.provider !== 'local') continue;
    const key = albumKeyOf(t);
    let a = map.get(key);
    if (!a) {
      a = { key, title: t.album || UNKNOWN_ALBUM, artist: primaryArtist(t), year: t.year, genre: t.genre, coverKey: t.coverKey, tracks: [], durationSec: 0, addedAt: 0 };
      map.set(key, a);
    }
    a.tracks.push(t);
    a.durationSec += t.durationSec;
    a.addedAt = Math.max(a.addedAt, t.addedAt);
    a.coverKey ??= t.coverKey;
    a.year ??= t.year;
    a.genre ??= t.genre;
  }
  const out = [...map.values()];
  for (const a of out) a.tracks.sort(byTrackOrder);
  return out;
}

export function buildArtists(tracks: Track[]): Artist[] {
  const map = new Map<string, Artist>();
  for (const t of tracks) {
    const names = t.artists.length ? t.artists : [UNKNOWN_ARTIST];
    const albumKey = albumKeyOf(t);
    for (const name of new Set(names)) {
      const key = artistKeyOf(name);
      let a = map.get(key);
      if (!a) {
        a = { key, name, tracks: [], albumKeys: [], coverKey: t.coverKey };
        map.set(key, a);
      }
      a.tracks.push(t);
      if (!a.albumKeys.includes(albumKey)) a.albumKeys.push(albumKey);
      a.coverKey ??= t.coverKey;
    }
  }
  return [...map.values()];
}
