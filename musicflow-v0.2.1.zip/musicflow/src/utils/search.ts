import type { Album, Artist, Track } from '@/core/types';
import { artistLine } from './groups';
import { matchScore, norm } from './text';

export interface SearchResults { tracks: Track[]; albums: Album[]; artists: Artist[] }
export interface Searchable { tracks: Track[]; albums: Album[]; artists: Artist[] }

// Texte normalisé mis en cache par objet : chaque frappe devient une simple recherche de sous-chaîne.
const cache = new WeakMap<object, string>();
const hay = (o: object, build: () => string) => {
  let h = cache.get(o);
  if (h === undefined) { h = norm(build()); cache.set(o, h); }
  return h;
};

export function searchLibrary(query: string, lib: Searchable, limit = 8): SearchResults {
  const words = norm(query).split(/\s+/).filter(Boolean);
  if (!words.length) return { tracks: [], albums: [], artists: [] };
  const all = (h: string) => words.every((w) => h.includes(w));

  const tracks: { t: Track; s: number }[] = [];
  for (const t of lib.tracks) {
    if (!all(hay(t, () => [t.title, artistLine(t), t.album, t.genre].filter(Boolean).join(' ')))) continue;
    const s = Math.max(
      matchScore(query, t.title),
      matchScore(query, artistLine(t)) * 0.85,
      matchScore(query, t.album ?? '') * 0.7,
      matchScore(query, t.genre ?? '') * 0.6,
      10,
    );
    tracks.push({ t, s });
  }
  tracks.sort((a, b) => b.s - a.s || b.t.playCount - a.t.playCount || a.t.title.localeCompare(b.t.title));

  const albums = lib.albums
    .filter((a) => all(hay(a, () => `${a.title} ${a.artist} ${a.genre ?? ''}`)))
    .map((a) => ({ a, s: Math.max(matchScore(query, a.title), matchScore(query, a.artist) * 0.8, 10) }))
    .sort((x, y) => y.s - x.s || x.a.title.localeCompare(y.a.title));

  const artists = lib.artists
    .filter((a) => all(hay(a, () => a.name)))
    .map((a) => ({ a, s: matchScore(query, a.name) || 10 }))
    .sort((x, y) => y.s - x.s || y.a.tracks.length - x.a.tracks.length);

  return {
    tracks: tracks.slice(0, limit * 3).map((x) => x.t),
    albums: albums.slice(0, limit).map((x) => x.a),
    artists: artists.slice(0, limit).map((x) => x.a),
  };
}
