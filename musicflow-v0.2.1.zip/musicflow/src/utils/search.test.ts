import { describe, expect, it } from 'vitest';
import type { Track } from '@/core/types';
import { highlight, matchScore, norm } from './text';
import { buildAlbums, buildArtists } from './groups';
import { searchLibrary } from './search';
import { comboOf, prettyCombo } from './shortcuts';
import { formatLong, formatTime } from './format';
import { isUnder, joinPath } from './audio';

const mk = (id: number, title: string, artists: string[], album: string, genre: string, plays = 0): Track => ({
  id: `local:${id}`, provider: 'local', ref: `/${id}`, title, artists, album, genre,
  durationSec: 200, addedAt: 0, playCount: plays, liked: false,
});
const tracks = [
  mk(1, 'Midnight City', ['M83'], 'Hurry Up, We’re Dreaming', 'Electronic', 5),
  mk(2, 'Wait', ['M83'], 'Hurry Up, We’re Dreaming', 'Electronic'),
  mk(3, 'Été indien', ['Joe Dassin'], 'Les Champs-Élysées', 'Chanson'),
  mk(4, 'City of Stars', ['Ryan Gosling', 'Emma Stone'], 'La La Land', 'Soundtrack'),
];
const lib = { tracks, albums: buildAlbums(tracks), artists: buildArtists(tracks) };

describe('recherche', () => {
  it('titre exact en tête', () => expect(searchLibrary('midnight city', lib).tracks[0].title).toBe('Midnight City'));
  it('insensible aux accents', () => expect(searchLibrary('ete indien', lib).tracks[0].id).toBe('local:3'));
  it('artiste → titres, album et artiste', () => {
    const r = searchLibrary('m83', lib);
    expect(r.tracks).toHaveLength(2);
    expect(r.albums).toHaveLength(1);
    expect(r.artists[0].name).toBe('M83');
  });
  it('genre', () => expect(searchLibrary('chanson', lib).tracks).toHaveLength(1));
  it('plusieurs mots dans des champs différents', () => expect(searchLibrary('city gosling', lib).tracks).toHaveLength(1));
  it('début de titre avant simple inclusion', () => expect(searchLibrary('city', lib).tracks[0].title).toBe('City of Stars'));
  it('requête vide ou sans résultat', () => {
    expect(searchLibrary('  ', lib).tracks).toHaveLength(0);
    expect(searchLibrary('zzzz', lib).albums).toHaveLength(0);
  });
  it('artistes multiples', () => expect(searchLibrary('emma', lib).artists[0].name).toBe('Emma Stone'));
});

describe('texte', () => {
  it('norm', () => expect(norm('Été Ça')).toBe('ete ca'));
  it('score', () => {
    expect(matchScore('mid', 'Midnight City')).toBeGreaterThan(matchScore('city', 'Midnight City'));
    expect(matchScore('zzz', 'abc')).toBe(0);
  });
  it('surbrillance sans tenir compte des accents', () => {
    expect(highlight('Été indien', 'ete')).toEqual([{ text: 'Été', hit: true }, { text: ' indien', hit: false }]);
  });
});

describe('raccourcis', () => {
  const ev = (key: string, o: Partial<{ ctrlKey: boolean; shiftKey: boolean }> = {}) => ({ key, ctrlKey: false, altKey: false, shiftKey: false, ...o });
  it('combinaisons', () => {
    expect(comboOf(ev('k', { ctrlKey: true }))).toBe('ctrl+k');
    expect(comboOf(ev(' '))).toBe('space');
    expect(comboOf(ev(',', { ctrlKey: true }))).toBe('ctrl+,');
    expect(comboOf(ev('ArrowRight', { ctrlKey: true }))).toBe('ctrl+arrowright');
    expect(comboOf(ev('Control', { ctrlKey: true }))).toBe('');
  });
  it('affichage', () => expect(prettyCombo('ctrl+arrowright')).toBe('Ctrl + →'));
});

describe('format et chemins', () => {
  it('durées', () => {
    expect(formatTime(65)).toBe('1:05');
    expect(formatTime(3725)).toBe('1:02:05');
    expect(formatTime(Number.NaN)).toBe('0:00');
    expect(formatLong(4320)).toBe('1 h 12 min');
  });
  it('chemins', () => {
    expect(isUnder('C:\\Music\\a.mp3', 'C:\\Music')).toBe(true);
    expect(isUnder('C:\\Music2\\a.mp3', 'C:\\Music')).toBe(false);
    expect(joinPath('C:\\M', 'a.mp3')).toBe('C:\\M\\a.mp3');
  });
});
