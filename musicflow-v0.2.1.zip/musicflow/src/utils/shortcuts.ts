/** Transforme un évènement clavier en combinaison normalisée : « ctrl+k », « space », « ctrl+arrowright »… */
export function comboOf(e: { key: string; ctrlKey: boolean; metaKey?: boolean; altKey: boolean; shiftKey: boolean }): string {
  const parts: string[] = [];
  if (e.ctrlKey || e.metaKey) parts.push('ctrl');
  if (e.altKey) parts.push('alt');
  if (e.shiftKey && e.key.length > 1) parts.push('shift');
  let k = e.key.toLowerCase();
  if (k === ' ') k = 'space';
  if (k === 'control' || k === 'alt' || k === 'shift' || k === 'meta') return '';
  parts.push(k);
  return parts.join('+');
}

const NAMES: Record<string, string> = {
  space: 'Espace', arrowright: '→', arrowleft: '←', arrowup: '↑', arrowdown: '↓', ctrl: 'Ctrl', alt: 'Alt', shift: 'Maj',
};

export function prettyCombo(combo: string): string {
  return combo.split('+').map((p) => NAMES[p] ?? (p.length === 1 ? p.toUpperCase() : p)).join(' + ');
}
