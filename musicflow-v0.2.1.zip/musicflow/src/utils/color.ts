export function hexToRgb(hex: string): [number, number, number] {
  const m = /^#?([0-9a-f]{6})$/i.exec(hex.trim());
  if (!m) return [139, 124, 255];
  const n = parseInt(m[1], 16);
  return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
}

export const rgbTriplet = (hex: string) => hexToRgb(hex).join(' ');

/** Noir ou blanc selon le contraste (luminance relative WCAG). */
export function onColor(hex: string): string {
  const [r, g, b] = hexToRgb(hex).map((v) => {
    const c = v / 255;
    return c <= 0.03928 ? c / 12.92 : ((c + 0.055) / 1.055) ** 2.4;
  });
  const lum = 0.2126 * r + 0.7152 * g + 0.0722 * b;
  return lum > 0.4 ? '12 13 17' : '255 255 255';
}

/** Couleur dominante (pondérée par la saturation) d'une image, via un petit canvas. */
export async function dominantColor(src: string): Promise<[number, number, number] | undefined> {
  try {
    const img = new Image();
    // Les miniatures distantes exigent CORS pour que le canvas reste lisible ; sans lui on retombe sur l'accent.
    if (/^https?:/i.test(src)) img.crossOrigin = 'anonymous';
    img.src = src;
    await img.decode();
    const c = document.createElement('canvas');
    c.width = c.height = 24;
    const ctx = c.getContext('2d', { willReadFrequently: true });
    if (!ctx) return undefined;
    ctx.drawImage(img, 0, 0, 24, 24);
    const data = ctx.getImageData(0, 0, 24, 24).data;
    let r = 0, g = 0, b = 0, w = 0;
    for (let i = 0; i < data.length; i += 4) {
      const max = Math.max(data[i], data[i + 1], data[i + 2]);
      const min = Math.min(data[i], data[i + 1], data[i + 2]);
      const sat = max === 0 ? 0 : (max - min) / max;
      const weight = 0.15 + sat * sat * 2 + (max > 40 && max < 235 ? 0.3 : 0);
      r += data[i] * weight; g += data[i + 1] * weight; b += data[i + 2] * weight; w += weight;
    }
    return w ? [Math.round(r / w), Math.round(g / w), Math.round(b / w)] : undefined;
  } catch {
    return undefined;
  }
}
