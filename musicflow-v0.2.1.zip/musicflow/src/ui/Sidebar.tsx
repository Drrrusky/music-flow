import { motion } from 'framer-motion';
import { Disc3, Heart, Home, Library, Search, Settings, User } from 'lucide-react';
import type { ReactNode } from 'react';
import { useLibrary } from '@/stores/libraryStore';
import { useSettings } from '@/stores/settingsStore';
import { useUi, type Route } from '@/stores/uiStore';
import { Tip } from './Tip';

const COLLAPSED = 76;

function Logo({ compact }: { compact: boolean }) {
  return (
    <div className="flex items-center gap-2.5 px-1">
      <svg width="30" height="30" viewBox="0 0 32 32" aria-hidden>
        <defs>
          <linearGradient id="mf" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0" stopColor="rgb(var(--c-accent))" />
            <stop offset="1" stopColor="rgb(var(--c-accent))" stopOpacity=".55" />
          </linearGradient>
        </defs>
        <rect width="32" height="32" rx="9" fill="url(#mf)" />
        <path d="M5 19c3-8 5-8 7 0s4 8 7 0 4-8 8-2" fill="none" stroke="rgb(var(--c-on-accent))" strokeWidth="2.6" strokeLinecap="round" />
      </svg>
      {!compact && <span className="font-display text-[17px] font-semibold tracking-tight">musicflow</span>}
    </div>
  );
}

interface ItemProps { icon: ReactNode; label: string; active: boolean; compact: boolean; onClick: () => void; count?: number }

function NavItem({ icon, label, active, compact, onClick, count }: ItemProps) {
  return (
    <Tip label={compact ? label : undefined} side="right" className="w-full">
      <button
        onClick={onClick}
        aria-current={active ? 'page' : undefined}
        className={`relative flex w-full items-center gap-3 rounded-ui-sm px-3 py-2.5 text-[14px] font-medium transition-colors ${compact ? 'justify-center' : ''} ${active ? 'bg-fg/10 text-fg' : 'text-muted hover:bg-fg/[0.06] hover:text-fg'}`}
      >
        {active && <motion.span layoutId="nav-active" className="absolute left-0 top-2 bottom-2 w-[3px] rounded-full bg-accent" />}
        <span className={active ? 'text-accent' : ''}>{icon}</span>
        {!compact && <span className="flex-1 truncate text-left">{label}</span>}
        {!compact && count !== undefined && count > 0 && <span className="text-[12px] tabular-nums text-muted">{count.toLocaleString('fr-FR')}</span>}
      </button>
    </Tip>
  );
}

const same = (a: Route, b: Route) => JSON.stringify(a) === JSON.stringify(b);

export function Sidebar() {
  const width = useSettings((s) => s.sidebarWidth);
  const update = useSettings((s) => s.update);
  const route = useUi((s) => s.route);
  const navigate = useUi((s) => s.navigate);
  const { tracks, albums, artists, scanning, progress } = useLibrary();
  const compact = width < 150;

  const startResize = (e: React.PointerEvent) => {
    e.preventDefault();
    const x0 = e.clientX, w0 = width;
    const move = (ev: PointerEvent) => {
      const w = Math.min(360, Math.max(COLLAPSED, w0 + ev.clientX - x0));
      update({ sidebarWidth: w < 130 ? COLLAPSED : Math.max(w, 190) });
    };
    const up = () => { window.removeEventListener('pointermove', move); window.removeEventListener('pointerup', up); };
    window.addEventListener('pointermove', move);
    window.addEventListener('pointerup', up);
  };

  const item = (r: Route, icon: ReactNode, label: string, count?: number) => (
    <NavItem icon={icon} label={label} compact={compact} count={count} active={same(route, r)} onClick={() => navigate(r)} />
  );

  return (
    <nav aria-label="Navigation principale" className="glass hairline relative flex shrink-0 flex-col rounded-ui-lg p-3" style={{ width }}>
      <div className={`mb-5 mt-1 ${compact ? 'flex justify-center' : ''}`}><Logo compact={compact} /></div>

      <div className="flex flex-col gap-0.5">
        {item({ name: 'home' }, <Home size={19} />, 'Accueil')}
        {item({ name: 'search' }, <Search size={19} />, 'Recherche')}
        {item({ name: 'library' }, <Library size={19} />, 'Bibliothèque', tracks.length)}
      </div>

      <div className="my-4 h-px bg-line/10" />
      {!compact && <div className="mb-1.5 px-3 text-[12px] font-medium text-muted">Ta musique</div>}
      <div className="flex flex-col gap-0.5">
        {item({ name: 'library', liked: true }, <Heart size={19} />, 'Titres likés', tracks.filter((t) => t.liked).length)}
        {item({ name: 'library', tab: 'albums' }, <Disc3 size={19} />, 'Albums', albums.length)}
        {item({ name: 'library', tab: 'artists' }, <User size={19} />, 'Artistes', artists.length)}
      </div>

      <div className="mt-auto flex flex-col gap-2">
        {scanning && !compact && (
          <div className="rounded-ui-sm bg-fg/[0.06] p-3" role="status">
            <div className="mb-2 text-[12px] text-muted">
              Analyse… {progress && progress.total > 0 ? `${progress.done.toLocaleString('fr-FR')} / ${progress.total.toLocaleString('fr-FR')}` : ''}
            </div>
            <div className="h-1 overflow-hidden rounded-full bg-fg/15">
              <div className="h-full rounded-full bg-accent transition-[width]" style={{ width: progress && progress.total ? `${(progress.done / progress.total) * 100}%` : '15%' }} />
            </div>
          </div>
        )}
        {item({ name: 'settings' }, <Settings size={19} />, 'Paramètres')}
      </div>

      <div
        onPointerDown={startResize}
        onDoubleClick={() => update({ sidebarWidth: compact ? 248 : COLLAPSED })}
        role="separator"
        aria-orientation="vertical"
        aria-label="Redimensionner la barre latérale"
        className="absolute -right-1 top-0 z-10 h-full w-2 cursor-col-resize after:absolute after:left-1/2 after:top-1/2 after:h-12 after:w-[3px] after:-translate-y-1/2 after:rounded-full after:bg-accent after:opacity-0 after:transition-opacity hover:after:opacity-70"
      />
    </nav>
  );
}
