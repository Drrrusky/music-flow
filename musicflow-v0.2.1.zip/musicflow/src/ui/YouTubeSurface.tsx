import { ExternalLink } from 'lucide-react';
import { YT_HOST_ID } from '@/core/providers/youtube/YouTubeBackend';
import { usePlayer } from '@/stores/playerStore';
import { useUi } from '@/stores/uiStore';
import { openExternal, youtubeUrl } from '@/services/external';

/**
 * Lecteur vidéo YouTube. Les conditions d'utilisation de l'API imposent que le lecteur intégré
 * reste visible pendant la lecture : on ne le masque donc jamais tant qu'un titre YouTube est en cours.
 * (Il est seulement retiré de l'affichage lorsqu'un autre fournisseur prend le relais.)
 */
export function YouTubeSurface() {
  const track = usePlayer((s) => s.current);
  const panelOpen = useUi((s) => s.queueOpen || !!s.infoTrack);
  const isYt = track?.provider === 'youtube';
  return (
    <div
      className={`fixed bottom-[116px] z-40 w-[360px] transition-[right] duration-300 ${isYt ? '' : 'hidden'}`}
      style={{ right: panelOpen ? 392 : 20 }}
      aria-label="Lecteur vidéo YouTube"
    >
      <div className="relative aspect-video overflow-hidden rounded-ui-lg bg-black shadow-2xl shadow-black/50 ring-1 ring-line/15">
        <div id={YT_HOST_ID} className="absolute inset-0 [&>iframe]:size-full" />
      </div>
      {isYt && track && (
        <button onClick={() => void openExternal(youtubeUrl(track.ref))} className="ml-1 mt-2 flex items-center gap-1.5 text-[12px] text-muted hover:text-fg hover:underline">
          <ExternalLink size={12} /> Ouvrir sur YouTube
        </button>
      )}
    </div>
  );
}
