import { useRef, useState, type KeyboardEvent, type PointerEvent } from 'react';

interface SliderProps {
  value: number;
  min?: number;
  max?: number;
  step?: number;
  keyStep?: number;
  onChange?: (v: number) => void;
  onCommit?: (v: number) => void;
  label: string;
  vertical?: boolean;
  /** Remplissage à partir du centre (égaliseur, balance). */
  centered?: boolean;
  disabled?: boolean;
  valueText?: (v: number) => string;
  className?: string;
}

const snap = (v: number, step: number) => Math.round(v / step) * step;

export function Slider({
  value, min = 0, max = 1, step = 0.001, keyStep, onChange, onCommit, label,
  vertical = false, centered = false, disabled = false, valueText, className = '',
}: SliderProps) {
  const ref = useRef<HTMLDivElement>(null);
  const dragging = useRef(false);
  const [drag, setDrag] = useState<number | null>(null);

  const shown = drag ?? value;
  const ratio = max === min ? 0 : Math.min(1, Math.max(0, (shown - min) / (max - min)));
  const from = centered ? Math.min(0.5, ratio) : 0;
  const to = centered ? Math.max(0.5, ratio) : ratio;

  const valueAt = (e: PointerEvent): number => {
    const r = ref.current!.getBoundingClientRect();
    const t = vertical ? 1 - (e.clientY - r.top) / r.height : (e.clientX - r.left) / r.width;
    const raw = min + Math.min(1, Math.max(0, t)) * (max - min);
    return Math.min(max, Math.max(min, snap(raw, step)));
  };

  const down = (e: PointerEvent) => {
    if (disabled) return;
    e.currentTarget.setPointerCapture(e.pointerId);
    dragging.current = true;
    const v = valueAt(e);
    setDrag(v);
    onChange?.(v);
  };
  const move = (e: PointerEvent) => {
    if (!dragging.current) return;
    const v = valueAt(e);
    setDrag(v);
    onChange?.(v);
  };
  const up = (e: PointerEvent) => {
    if (!dragging.current) return;
    dragging.current = false;
    const v = valueAt(e);
    setDrag(null);
    onChange?.(v);
    onCommit?.(v);
  };
  const key = (e: KeyboardEvent) => {
    if (disabled) return;
    const k = keyStep ?? (max - min) / 20;
    let v: number | null = null;
    if (e.key === 'ArrowRight' || e.key === 'ArrowUp') v = value + k;
    else if (e.key === 'ArrowLeft' || e.key === 'ArrowDown') v = value - k;
    else if (e.key === 'Home') v = min;
    else if (e.key === 'End') v = max;
    if (v === null) return;
    e.preventDefault();
    e.stopPropagation();
    v = Math.min(max, Math.max(min, v));
    onChange?.(v);
    onCommit?.(v);
  };

  const fillStyle = vertical
    ? { bottom: `${from * 100}%`, height: `${(to - from) * 100}%` }
    : { left: `${from * 100}%`, width: `${(to - from) * 100}%` };
  const thumbStyle = vertical ? { bottom: `${ratio * 100}%` } : { left: `${ratio * 100}%` };

  return (
    <div
      ref={ref}
      role="slider"
      tabIndex={disabled ? -1 : 0}
      aria-label={label}
      aria-orientation={vertical ? 'vertical' : 'horizontal'}
      aria-valuemin={min}
      aria-valuemax={max}
      aria-valuenow={shown}
      aria-valuetext={valueText?.(shown)}
      aria-disabled={disabled}
      onPointerDown={down}
      onPointerMove={move}
      onPointerUp={up}
      onPointerCancel={up}
      onKeyDown={key}
      className={`group relative flex touch-none items-center justify-center ${vertical ? 'h-full w-6' : 'h-5 w-full'} ${disabled ? 'opacity-40' : ''} ${className}`}
    >
      <div className={`relative overflow-hidden rounded-full bg-fg/15 ${vertical ? 'h-full w-1' : 'h-1 w-full'}`}>
        <div
          className={`absolute rounded-full ${drag !== null ? 'bg-accent' : 'bg-fg group-hover:bg-accent group-focus-visible:bg-accent'} ${drag === null ? (vertical ? 'transition-[height] duration-100 ease-linear' : 'transition-[width] duration-100 ease-linear') : ''} ${vertical ? 'w-full' : 'h-full'}`}
          style={fillStyle}
        />
      </div>
      <div
        className={`pointer-events-none absolute size-3 rounded-full bg-fg shadow transition-opacity ${vertical ? 'translate-y-1/2' : '-translate-x-1/2'} ${drag !== null ? 'opacity-100' : 'opacity-0 group-hover:opacity-100 group-focus-visible:opacity-100'}`}
        style={thumbStyle}
      />
    </div>
  );
}
