import { AnimatePresence, motion } from 'framer-motion';
import {
  Heart, Info, ListMusic, Loader2, Maximize2, Mic2, Pause, Play, Repeat, Repeat1, Shuffle, SkipBack, SkipForward,
  Volume1, Volume2, VolumeX,
} from 'lucide-react';
import { useState } from 'react';
import { engine } from '@/core/playback/engine';
import { getProvider } from '@/core/providers/registry';
import { useLibrary } from '@/stores/libraryStore';
import { usePlayer } from '@/stores/playerStore';
import { useUi } from '@/stores/uiStore';
import { albumKeyOf, artistKeyOf, artistLine } from '@/utils/groups';
import { formatTime } from '@/utils/format';
import { CoverArt } from './CoverArt';
import { IconButton } from './IconButton';
import { Slider } from './Slider';
import { Tip } from './Tip';

function qualityText(t: NonNullable<ReturnType<typeof usePlayer.getState>['current']>): string | undefined {
  const x = t.tech;
  if (!x) return undefined;
  const parts = [
    x.codec?.replace(/^MPEG 1 Layer 3$/i, 'MP3') ?? x.container,
    x.sampleRateHz ? `${(x.sampleRateHz / 1000).toLocaleString('fr-FR', { maximumFractionDigits: 1 })} kHz` : undefined,
    x.bitsPerSample ? `${x.bitsPerSample} bit` : x.bitrateKbps ? `${x.bitrateKbps} kb/s` : undefined,
  ].filter(Boolean);
  return parts.length ? parts.join(' · ') : undefined;
}

export function PlayerBar() {
  const { current, status, position, duration, volume, muted, shuffle, repeat } = usePlayer();
  useLibrary((s) => s.rev);
  const queueOpen = useUi((s) => s.queueOpen);
  const { toggleQueue, openInfo, navigate } = useUi.getState();
  const [scrub, setScrub] = useState<number | null>(null);

  const playing = status === 'playing';
  const loading = status === 'loading';
  const dur = duration || current?.durationSec || 0;
  const shownPos = scrub ?? position;
  const VolIcon = muted || volume === 0 ? VolumeX : volume < 0.5 ? Volume1 : Volume2;
  const caps = current ? getProvider(current.provider).capabilities : undefined;
  const quality = current && caps?.technicalInfo ? qualityText(current) : undefined;

  return (
    <footer className="glass hairline grid h-[88px] shrink-0 grid-cols-[minmax(0,1fr)_minmax(0,1.5fr)_minmax(0,1fr)] items-center gap-4 rounded-ui-lg px-4 shadow-2xl shadow-black/30" aria-label="Lecteur">
      {/* Titre en cours */}
      <div className="flex min-w-0 items-center gap-3">
        <AnimatePresence mode="wait" initial={false}>
          <motion.div key={current?.id ?? 'none'} initial={{ opacity: 0, scale: 0.92 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0 }} transition={{ duration: 0.18 }}>
            <CoverArt coverKey={current?.coverKey} coverUrl={current?.coverUrl} seed={current?.album ?? current?.title} className="size-[60px] shadow-lg shadow-black/30" iconSize={22} />
          </motion.div>
        </AnimatePresence>
        {current ? (
          <>
            <div className="min-w-0">
              <button className="block max-w-full truncate text-[14px] font-medium hover:underline" onClick={() => current.album && navigate({ name: 'album', key: albumKeyOf(current) })}>
                {current.title}
              </button>
              <button className="block max-w-full truncate text-[12.5px] text-muted hover:text-fg hover:underline" onClick={() => navigate({ name: 'artist', key: artistKeyOf(current.artists[0] ?? 'Artiste inconnu') })}>
                {artistLine(current)}
              </button>
            </div>
            <IconButton label={current.liked ? 'Retirer des titres likés' : 'Ajouter aux titres likés'} active={current.liked} size={32} onClick={() => useLibrary.getState().toggleLike(current.id)}>
              <Heart size={17} fill={current.liked ? 'currentColor' : 'none'} />
            </IconButton>
            <IconButton label="Informations sur le titre" size={32} onClick={() => openInfo(current)} className="max-[1250px]:hidden">
              <Info size={17} />
            </IconButton>
          </>
        ) : (
          <div className="text-[13px] text-muted">Rien en lecture</div>
        )}
      </div>

      {/* Commandes + progression */}
      <div className="flex min-w-0 flex-col items-center gap-1">
        <div className="flex items-center gap-1.5">
          <IconButton label="Lecture aléatoire" active={shuffle} onClick={() => engine.toggleShuffle()}><Shuffle size={17} /></IconButton>
          <IconButton label="Précédent" onClick={() => void engine.prev()} disabled={!current}><SkipBack size={20} fill="currentColor" /></IconButton>
          <motion.button
            aria-label={playing ? 'Pause' : 'Lecture'}
            onClick={() => void engine.toggle()}
            disabled={!current}
            whileHover={{ scale: 1.06 }}
            whileTap={{ scale: 0.93 }}
            className="mx-1 flex size-11 items-center justify-center rounded-full bg-accent text-on-accent shadow-lg shadow-black/30 disabled:opacity-40"
          >
            {loading ? <Loader2 size={20} className="animate-spin" /> : playing ? <Pause size={20} fill="currentColor" /> : <Play size={20} fill="currentColor" className="ml-0.5" />}
          </motion.button>
          <IconButton label="Suivant" onClick={() => void engine.next(true)} disabled={!current}><SkipForward size={20} fill="currentColor" /></IconButton>
          <IconButton label={repeat === 'off' ? 'Répéter' : repeat === 'all' ? 'Répéter la file' : 'Répéter ce titre'} active={repeat !== 'off'} onClick={() => engine.cycleRepeat()}>
            {repeat === 'one' ? <Repeat1 size={17} /> : <Repeat size={17} />}
          </IconButton>
        </div>
        <div className="flex w-full max-w-[640px] items-center gap-2.5">
          <span className="w-10 text-right text-[11.5px] tabular-nums text-muted">{formatTime(shownPos)}</span>
          <Slider
            label="Progression"
            value={Math.min(shownPos, dur || 0)}
            max={dur || 1}
            step={0.1}
            keyStep={5}
            disabled={!current || !dur}
            onChange={setScrub}
            onCommit={(v) => { setScrub(null); engine.seek(v); }}
            valueText={formatTime}
          />
          <span className="w-10 text-[11.5px] tabular-nums text-muted">{formatTime(dur)}</span>
        </div>
      </div>

      {/* Outils */}
      <div className="flex min-w-0 items-center justify-end gap-0.5">
        {quality && (
          <Tip label="Qualité de la source (lecture locale). Le fichier est lu tel quel : il n’y a pas de choix de qualité.">
            <span className="mr-2 max-w-[150px] truncate rounded-full bg-fg/10 px-2.5 py-1 text-[11px] text-muted max-[1400px]:hidden">{quality}</span>
          </Tip>
        )}
        <IconButton label="Paroles" unavailable="prévues à l’étape 4" className="max-[1250px]:hidden"><Mic2 size={17} /></IconButton>
        <IconButton label="File d’attente" active={queueOpen} onClick={toggleQueue}><ListMusic size={18} /></IconButton>
        <IconButton label={muted ? 'Réactiver le son' : 'Couper le son'} onClick={() => engine.toggleMute()}><VolIcon size={18} /></IconButton>
        <div className="w-24 max-[1100px]:hidden">
          <Slider label="Volume" value={muted ? 0 : volume} step={0.01} keyStep={0.05} onChange={(v) => engine.setVolume(v)} valueText={(v) => `${Math.round(v * 100)} %`} />
        </div>
        <IconButton label="Plein écran" unavailable="prévu à l’étape 4" className="max-[1100px]:hidden"><Maximize2 size={16} /></IconButton>
      </div>
    </footer>
  );
}
