import type { FeatureStatus } from '@/core/types';

const LOOK: Record<FeatureStatus, { label: string; cls: string }> = {
  functional: { label: 'Fonctionnelle', cls: 'bg-emerald-500/15 text-emerald-500' },
  partial: { label: 'Partielle', cls: 'bg-amber-500/15 text-amber-500' },
  pending: { label: 'En attente', cls: 'bg-sky-500/15 text-sky-500' },
  unavailable: { label: 'Non disponible', cls: 'bg-fg/10 text-muted' },
};

export const statusLabel = (s: FeatureStatus) => LOOK[s].label;

export function StatusBadge({ status }: { status: FeatureStatus }) {
  return <span className={`inline-flex shrink-0 items-center rounded-full px-2 py-0.5 text-[11px] font-medium ${LOOK[status].cls}`}>{LOOK[status].label}</span>;
}
