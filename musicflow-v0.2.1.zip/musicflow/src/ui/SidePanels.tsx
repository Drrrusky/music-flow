import { AnimatePresence, motion, Reorder } from 'framer-motion';
import { ChevronDown, ListMusic, Trash2, X } from 'lucide-react';
import { useState, type ReactNode } from 'react';
import { engine } from '@/core/playback/engine';
import { playedOf, upcomingOf } from '@/core/playback/Queue';
import { getProvider } from '@/core/providers/registry';
import type { Track } from '@/core/types';
import { useLibrary } from '@/stores/libraryStore';
import { usePlayer } from '@/stores/playerStore';
import { useUi } from '@/stores/uiStore';
import { openExternal, youtubeUrl } from '@/services/external';
import { artistLine } from '@/utils/groups';
import { formatBytes, formatDate, formatLong, formatTime, plural } from '@/utils/format';
import { CoverArt } from './CoverArt';
import { IconButton } from './IconButton';
import { NowPlayingBars } from './NowPlayingBars';
import { StatusBadge } from './StatusBadge';
import { Tip } from './Tip';
import { showTrackMenu } from './trackActions';

function PanelShell({ title, onClose, children }: { title: string; onClose: () => void; children: ReactNode }) {
  return (
    <motion.aside
      initial={{ width: 0, opacity: 0 }}
      animate={{ width: 360, opacity: 1 }}
      exit={{ width: 0, opacity: 0 }}
      transition={{ type: 'spring', stiffness: 380, damping: 38 }}
      className="glass hairline shrink-0 overflow-hidden rounded-ui-lg"
      aria-label={title}
    >
      <div className="flex h-full w-[360px] flex-col">
        <header className="flex items-center justify-between px-5 pb-2 pt-4">
          <h2 className="font-display text-[16px] font-semibold">{title}</h2>
          <IconButton label="Fermer" size={32} onClick={onClose}><X size={18} /></IconButton>
        </header>
        {children}
      </div>
    </motion.aside>
  );
}

function QueueRow({ track, index, current, playing, onPlay, onRemove, reorderable }: { track: Track; index: number; current?: boolean; playing?: boolean; onPlay: () => void; onRemove?: () => void; reorderable?: boolean }) {
  return (
    <div
      onDoubleClick={onPlay}
      onContextMenu={(e) => showTrackMenu(e, track)}
      className={`group flex items-center gap-3 rounded-ui-sm px-2 py-1.5 transition-colors hover:bg-fg/[0.07] ${reorderable ? 'cursor-grab active:cursor-grabbing' : ''}`}
    >
      <div className="relative">
        <CoverArt coverKey={track.coverKey} coverUrl={track.coverUrl} seed={track.album ?? track.title} className="size-10" iconSize={16} />
        {current && <div className="absolute inset-0 flex items-center justify-center rounded-ui-sm bg-black/55"><NowPlayingBars playing={!!playing} /></div>}
      </div>
      <div className="min-w-0 flex-1">
        <div className={`truncate text-[13.5px] font-medium ${current ? 'text-accent' : ''}`}>{track.title}</div>
        <div className="truncate text-[12px] text-muted">{artistLine(track)}</div>
      </div>
      <span className="text-[12px] tabular-nums text-muted group-hover:hidden">{formatTime(track.durationSec)}</span>
      {onRemove && (
        <button aria-label={`Retirer ${track.title} de la file`} onClick={onRemove} className="hidden size-7 items-center justify-center rounded-full text-muted hover:text-fg group-hover:flex">
          <X size={15} />
        </button>
      )}
      <span className="sr-only">Position {index + 1}</span>
    </div>
  );
}

export function QueuePanel() {
  const queue = usePlayer((s) => s.queue);
  const status = usePlayer((s) => s.status);
  const current = queue.items[queue.index];
  const upcoming = upcomingOf(queue);
  const played = playedOf(queue);
  const [showPlayed, setShowPlayed] = useState(false);
  const close = useUi((s) => s.toggleQueue);
  const total = upcoming.reduce((n, t) => n + t.durationSec, 0);

  return (
    <PanelShell title="File d’attente" onClose={close}>
      {!current ? (
        <div className="flex flex-1 flex-col items-center justify-center gap-3 px-8 pb-16 text-center text-muted">
          <ListMusic size={30} strokeWidth={1.5} />
          <p className="text-[13.5px] leading-relaxed">La file est vide. Lance un titre, un album ou clique droit sur un morceau pour l’ajouter ici.</p>
        </div>
      ) : (
        <>
          <div className="flex-1 overflow-y-auto px-3 pb-3">
            {played.length > 0 && (
              <div className="mb-2">
                <button onClick={() => setShowPlayed((v) => !v)} className="flex w-full items-center gap-1.5 px-2 py-1.5 text-[12.5px] text-muted hover:text-fg" aria-expanded={showPlayed}>
                  <ChevronDown size={14} className={`transition-transform ${showPlayed ? '' : '-rotate-90'}`} />
                  Déjà lus ({played.length})
                </button>
                <AnimatePresence initial={false}>
                  {showPlayed && (
                    <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }} exit={{ height: 0, opacity: 0 }} className="overflow-hidden">
                      {played.map((t, i) => <QueueRow key={t.id} track={t} index={i} onPlay={() => void engine.jumpTo(i)} />)}
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            )}

            <div className="px-2 pb-1.5 pt-1 text-[12.5px] text-muted">En cours de lecture</div>
            <QueueRow track={current} index={queue.index} current playing={status === 'playing'} onPlay={() => void engine.toggle()} />

            <div className="px-2 pb-1.5 pt-4 text-[12.5px] text-muted">
              À suivre{upcoming.length ? ` · ${plural(upcoming.length, 'titre', 'titres')} · ${formatLong(total)}` : ''}
            </div>
            {upcoming.length === 0 ? (
              <p className="px-2 py-3 text-[13px] leading-relaxed text-muted">Plus rien après ce titre. La lecture s’arrêtera à la fin (la répétition de file se règle dans la barre de lecture).</p>
            ) : (
              <Reorder.Group axis="y" values={upcoming} onReorder={(next: Track[]) => engine.reorderUpcoming(next)} className="flex flex-col">
                {upcoming.map((t, i) => (
                  <Reorder.Item key={t.id} value={t} whileDrag={{ scale: 1.02, boxShadow: '0 10px 30px rgba(0,0,0,.35)', zIndex: 5 }} className="rounded-ui-sm bg-transparent">
                    <QueueRow track={t} index={queue.index + 1 + i} reorderable onPlay={() => void engine.jumpTo(queue.index + 1 + i)} onRemove={() => engine.removeFromQueue(queue.index + 1 + i)} />
                  </Reorder.Item>
                ))}
              </Reorder.Group>
            )}
          </div>

          <footer className="flex items-center justify-between gap-2 border-t border-line/10 px-4 py-3">
            <button onClick={() => engine.clearUpcomingTracks()} disabled={!upcoming.length} className="flex items-center gap-2 rounded-full px-3 py-2 text-[13px] text-muted transition-colors enabled:hover:bg-fg/10 enabled:hover:text-fg disabled:opacity-40">
              <Trash2 size={15} /> Vider la file
            </button>
            <Tip label="Disponible avec les playlists (étape 4)" side="top">
              <button disabled className="rounded-full px-3 py-2 text-[13px] text-muted opacity-40">Enregistrer en playlist</button>
            </Tip>
          </footer>
        </>
      )}
    </PanelShell>
  );
}

function Field({ label, value }: { label: string; value?: string | number | null }) {
  if (value === undefined || value === null || value === '') return null;
  return (
    <div className="flex items-baseline justify-between gap-4 py-1.5 text-[13px]">
      <dt className="shrink-0 text-muted">{label}</dt>
      <dd className="min-w-0 break-words text-right">{value}</dd>
    </div>
  );
}

function Group({ title, status, children }: { title: string; status?: 'functional' | 'pending'; children: ReactNode }) {
  return (
    <section className="mb-5">
      <div className="mb-1 flex items-center justify-between">
        <h3 className="font-display text-[13.5px] font-semibold">{title}</h3>
        {status && <StatusBadge status={status} />}
      </div>
      {children}
    </section>
  );
}

export function InfoPanel() {
  const track = useUi((s) => s.infoTrack);
  const close = useUi((s) => s.closeInfo);
  useLibrary((s) => s.rev);
  if (!track) return null;
  const x = track.tech;
  const caps = getProvider(track.provider).capabilities;
  const channels = x?.channels === 1 ? 'Mono' : x?.channels === 2 ? 'Stéréo' : x?.channels ? `${x.channels} canaux` : undefined;

  return (
    <PanelShell title="Informations" onClose={close}>
      <div className="flex-1 overflow-y-auto px-5 pb-6">
        <CoverArt coverKey={track.coverKey} coverUrl={track.coverUrl} seed={track.album ?? track.title} className="mx-auto mb-4 mt-1 aspect-square w-full max-w-[260px] shadow-2xl shadow-black/40" iconSize={48} />
        <div className="mb-5 text-center">
          <div className="font-display text-[17px] font-semibold leading-tight">{track.title}</div>
          <div className="mt-1 text-[13px] text-muted">{artistLine(track)}</div>
        </div>

        <Group title="Général" status="functional">
          <dl>
            <Field label="Artiste de l’album" value={track.albumArtist} />
            <Field label="Album" value={track.album} />
            <Field label="Année" value={track.year} />
            <Field label="Genre" value={track.genre} />
            <Field label="Piste" value={track.trackNo ? (track.discNo && track.discNo > 1 ? `${track.discNo}-${track.trackNo}` : track.trackNo) : undefined} />
            <Field label="Label" value={track.label} />
            <Field label="ISRC" value={track.isrc} />
            <Field label="Durée" value={formatTime(track.durationSec)} />
            <Field label="Ajouté le" value={formatDate(track.addedAt)} />
            <Field label="Écoutes" value={track.playCount} />
            <Field label="Dernière écoute" value={track.lastPlayedAt ? formatDate(track.lastPlayedAt) : undefined} />
          </dl>
        </Group>

        {caps.technicalInfo ? (
          <Group title="Technique" status="functional">
            <dl>
              <Field label="Format" value={x?.container} />
              <Field label="Codec" value={x?.codec} />
              <Field label="Débit" value={x?.bitrateKbps ? `${x.bitrateKbps} kb/s` : undefined} />
              <Field label="Fréquence" value={x?.sampleRateHz ? `${(x.sampleRateHz / 1000).toLocaleString('fr-FR', { maximumFractionDigits: 1 })} kHz` : undefined} />
              <Field label="Profondeur" value={x?.bitsPerSample ? `${x.bitsPerSample} bit` : undefined} />
              <Field label="Canaux" value={channels} />
              <Field label="Sans perte" value={x?.lossless === undefined ? undefined : x.lossless ? 'Oui' : 'Non'} />
              <Field label="ReplayGain" value={track.replayGainDb !== undefined ? `${track.replayGainDb.toFixed(2)} dB` : undefined} />
              <Field label="Taille" value={x?.sizeBytes ? formatBytes(x.sizeBytes) : undefined} />
              <Field label="Fichier" value={track.provider === 'local' ? track.ref : undefined} />
            </dl>
            <p className="mt-1 text-[12px] leading-relaxed text-muted">Seules les informations présentes dans le fichier sont affichées.</p>
          </Group>
        ) : (
          <Group title="Technique">
            <p className="text-[12.5px] leading-relaxed text-muted">Non disponible pour cette source : le flux audio n’expose ni codec ni débit.</p>
          </Group>
        )}

        {track.provider === 'youtube' && (
          <Group title="Source">
            <dl>
              <Field label="Fournisseur" value="YouTube" />
              <Field label="Chaîne" value={track.channel} />
            </dl>
            <button onClick={() => void openExternal(youtubeUrl(track.ref))} className="mt-2 text-[12.5px] text-accent hover:underline">Ouvrir sur YouTube</button>
            <p className="mt-2 text-[12px] leading-relaxed text-muted">Titre et artiste sont déduits du titre de la vidéo : ils peuvent être approximatifs.</p>
          </Group>
        )}

        <Group title="Crédits et contexte" status="pending">
          <p className="text-[12.5px] leading-relaxed text-muted">
            Producteurs, compositeurs, paroliers et contexte de création ne figurent pas dans les fichiers. Une source de métadonnées autorisée (MusicBrainz) sera ajoutée à l’étape 4.
          </p>
        </Group>
      </div>
    </PanelShell>
  );
}

export function SidePanels() {
  const queueOpen = useUi((s) => s.queueOpen);
  const info = useUi((s) => s.infoTrack);
  return (
    <AnimatePresence initial={false}>
      {queueOpen && <QueuePanel key="queue" />}
      {info && !queueOpen && <InfoPanel key="info" />}
    </AnimatePresence>
  );
}
