import type { ReactNode } from 'react';

const POS = {
  top: 'bottom-full left-1/2 mb-2 -translate-x-1/2',
  bottom: 'top-full left-1/2 mt-2 -translate-x-1/2',
  right: 'left-full top-1/2 ml-2 -translate-y-1/2',
  left: 'right-full top-1/2 mr-2 -translate-y-1/2',
} as const;

/** Infobulle CSS : fonctionne aussi autour d'un bouton désactivé. */
export function Tip({ label, children, side = 'top', className = '' }: { label?: string; children: ReactNode; side?: keyof typeof POS; className?: string }) {
  if (!label) return <>{children}</>;
  return (
    <span className={`group/tip relative inline-flex ${className}`}>
      {children}
      <span
        role="tooltip"
        className={`pointer-events-none absolute z-50 w-max max-w-[260px] rounded-ui-sm bg-raised px-2.5 py-1.5 text-left text-[11.5px] leading-snug text-fg opacity-0 shadow-xl ring-1 ring-line/10 transition-opacity delay-300 group-hover/tip:opacity-100 ${POS[side]}`}
      >
        {label}
      </span>
    </span>
  );
}
