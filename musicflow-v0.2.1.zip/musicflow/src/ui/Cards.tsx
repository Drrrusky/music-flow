import { motion } from 'framer-motion';
import { FolderPlus, Play } from 'lucide-react';
import type { ReactNode } from 'react';
import type { Album, Artist, Track } from '@/core/types';
import { engine } from '@/core/playback/engine';
import { usePlayer } from '@/stores/playerStore';
import { useUi } from '@/stores/uiStore';
import { artistLine } from '@/utils/groups';
import { plural } from '@/utils/format';
import { CoverArt } from './CoverArt';
import { NowPlayingBars } from './NowPlayingBars';
import { showTrackMenu } from './trackActions';

export function PlayFab({ onClick, label, size = 44 }: { onClick: () => void; label: string; size?: number }) {
  return (
    <motion.button
      aria-label={label}
      onClick={(e: { stopPropagation: () => void }) => { e.stopPropagation(); onClick(); }}
      whileHover={{ scale: 1.07 }}
      whileTap={{ scale: 0.94 }}
      className="flex items-center justify-center rounded-full bg-accent text-on-accent shadow-lg shadow-black/30"
      style={{ width: size, height: size }}
    >
      <Play size={size * 0.42} fill="currentColor" className="ml-0.5" />
    </motion.button>
  );
}

export function AlbumCard({ album }: { album: Album }) {
  const nav = useUi((s) => s.navigate);
  return (
    <div role="link" tabIndex={0} onClick={() => nav({ name: 'album', key: album.key })} onKeyDown={(e) => e.key === 'Enter' && nav({ name: 'album', key: album.key })} className="group w-full cursor-pointer rounded-ui p-2.5 transition-colors hover:bg-fg/[0.06]">
      <div className="relative">
        <CoverArt coverKey={album.coverKey} seed={album.title} className="aspect-square w-full shadow-lg shadow-black/25" iconSize={34} />
        <div className="absolute bottom-2 right-2 translate-y-1.5 opacity-0 transition duration-200 group-hover:translate-y-0 group-hover:opacity-100 group-focus-within:translate-y-0 group-focus-within:opacity-100">
          <PlayFab label={`Lire l’album ${album.title}`} onClick={() => void engine.playTracks(album.tracks, 0)} />
        </div>
      </div>
      <div className="mt-3 truncate text-[14px] font-medium">{album.title}</div>
      <div className="truncate text-[12.5px] text-muted">{[album.year, album.artist].filter(Boolean).join(' · ')}</div>
    </div>
  );
}

export function ArtistCard({ artist }: { artist: Artist }) {
  const nav = useUi((s) => s.navigate);
  return (
    <div role="link" tabIndex={0} onClick={() => nav({ name: 'artist', key: artist.key })} onKeyDown={(e) => e.key === 'Enter' && nav({ name: 'artist', key: artist.key })} className="group w-full cursor-pointer rounded-ui p-2.5 text-center transition-colors hover:bg-fg/[0.06]">
      <CoverArt coverKey={artist.coverKey} seed={artist.name} round className="mx-auto aspect-square w-full shadow-lg shadow-black/25" iconSize={34} />
      <div className="mt-3 truncate text-[14px] font-medium">{artist.name}</div>
      <div className="truncate text-[12.5px] text-muted">{plural(artist.tracks.length, 'titre', 'titres')}</div>
    </div>
  );
}

/** Tuile compacte : cover + titre, un clic lance la lecture dans le contexte de la liste. */
export function TrackTile({ track, list, index }: { track: Track; list: Track[]; index: number }) {
  const isCurrent = usePlayer((s) => s.current?.id === track.id);
  const playing = usePlayer((s) => s.status === 'playing');
  return (
    <button
      onClick={() => (isCurrent ? void engine.toggle() : void engine.playTracks(list, index))}
      onContextMenu={(e) => showTrackMenu(e, track, { list, index })}
      className="group flex items-center gap-3 overflow-hidden rounded-ui bg-fg/[0.06] pr-3 text-left transition-colors hover:bg-fg/[0.11]"
    >
      <CoverArt coverKey={track.coverKey} coverUrl={track.coverUrl} seed={track.album ?? track.title} className="size-14 !rounded-none" iconSize={20} />
      <div className="min-w-0 flex-1">
        <div className={`truncate text-[13.5px] font-medium ${isCurrent ? 'text-accent' : ''}`}>{track.title}</div>
        <div className="truncate text-[12px] text-muted">{artistLine(track)}</div>
      </div>
      {isCurrent ? <NowPlayingBars playing={playing} /> : <Play size={15} className="text-muted opacity-0 transition group-hover:opacity-100" fill="currentColor" />}
    </button>
  );
}

export function Section({ title, children, action }: { title: string; children: ReactNode; action?: ReactNode }) {
  return (
    <section className="mb-9">
      <div className="mb-3 flex items-end justify-between px-1">
        <h2 className="font-display text-[19px] font-semibold tracking-tight">{title}</h2>
        {action}
      </div>
      {children}
    </section>
  );
}

export function Shelf({ children }: { children: ReactNode }) {
  return <div className="-mx-2 flex gap-1 overflow-x-auto px-2 pb-2">{children}</div>;
}

export function EmptyState({ title, text, action }: { title: string; text: string; action?: { label: string; onClick: () => void } }) {
  return (
    <div className="flex flex-col items-center justify-center px-6 py-16 text-center">
      <div className="mb-5 flex size-16 items-center justify-center rounded-full bg-accent/15 text-accent">
        <FolderPlus size={28} strokeWidth={1.6} />
      </div>
      <h3 className="font-display text-[18px] font-semibold">{title}</h3>
      <p className="mt-2 max-w-sm text-[13.5px] leading-relaxed text-muted">{text}</p>
      {action && (
        <button onClick={action.onClick} className="mt-6 rounded-full bg-accent px-5 py-2.5 text-[13.5px] font-semibold text-on-accent transition hover:brightness-110 active:scale-95">
          {action.label}
        </button>
      )}
    </div>
  );
}
