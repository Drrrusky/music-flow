import type { Track } from '@/core/types';
import { engine } from '@/core/playback/engine';
import { useLibrary } from '@/stores/libraryStore';
import { useUi, type MenuItem } from '@/stores/uiStore';
import { albumKeyOf, artistKeyOf, primaryArtist } from '@/utils/groups';

export function trackMenu(t: Track, ctx?: { list: Track[]; index: number }): MenuItem[] {
  const ui = useUi.getState();
  // Un résultat YouTube pas encore enregistré n'a ni page album ni page artiste.
  const artistKey = artistKeyOf(t.artists[0] ?? primaryArtist(t));
  const hasArtistPage = useLibrary.getState().artistsByKey.has(artistKey);
  const items: MenuItem[] = [
    { label: 'Lire', onClick: () => void engine.playTracks(ctx?.list ?? [t], ctx?.index ?? 0) },
    { label: 'Lire ensuite', onClick: () => engine.playNextTracks([t]) },
    { label: 'Ajouter à la file d’attente', onClick: () => engine.enqueueTracks([t]) },
    { label: '', separator: true },
    { label: t.liked ? 'Retirer des titres likés' : 'Ajouter aux titres likés', onClick: () => useLibrary.getState().toggleLike(t.id) },
    { label: 'Informations sur le titre', onClick: () => ui.openInfo(t) },
    { label: '', separator: true },
    { label: 'Aller à l’album', disabled: !t.album || !useLibrary.getState().albumsByKey.has(albumKeyOf(t)), onClick: () => ui.navigate({ name: 'album', key: albumKeyOf(t) }) },
    { label: 'Aller à l’artiste', disabled: !hasArtistPage, onClick: () => ui.navigate({ name: 'artist', key: artistKey }) },
  ];
  return items;
}

export function showTrackMenu(e: { clientX: number; clientY: number; preventDefault: () => void }, t: Track, ctx?: { list: Track[]; index: number }) {
  e.preventDefault();
  useUi.getState().openMenu(e.clientX, e.clientY, trackMenu(t, ctx));
}
