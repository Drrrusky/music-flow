/** Trois barres animées : indique le titre en cours de lecture. */
export function NowPlayingBars({ playing }: { playing: boolean }) {
  return (
    <span className="flex h-3.5 items-end gap-[2px]" aria-hidden>
      {[0, 220, 440].map((d) => (
        <span
          key={d}
          className="w-[3px] origin-bottom rounded-sm bg-accent"
          style={{ height: '100%', transform: playing ? undefined : 'scaleY(.3)', animation: playing ? `eq 900ms ${d}ms ease-in-out infinite` : undefined }}
        />
      ))}
    </span>
  );
}
