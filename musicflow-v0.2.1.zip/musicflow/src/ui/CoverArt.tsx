import { motion } from 'framer-motion';
import { Music2 } from 'lucide-react';
import { useCover } from '@/hooks/useCover';

const hue = (s: string) => [...s].reduce((a, c) => (a * 31 + c.charCodeAt(0)) % 360, 7);

interface Props {
  coverKey?: string;
  /** Miniature distante (YouTube), utilisée quand il n'y a pas de pochette locale. */
  coverUrl?: string;
  /** Texte qui détermine la couleur du repli quand il n'y a pas de pochette. */
  seed?: string;
  className?: string;
  round?: boolean;
  iconSize?: number;
}

export function CoverArt({ coverKey, coverUrl, seed = '', className = '', round = false, iconSize = 22 }: Props) {
  const stored = useCover(coverKey);
  const src = stored ?? coverUrl;
  const h = hue(seed || coverKey || 'x');
  return (
    <div
      className={`relative shrink-0 overflow-hidden ${round ? 'rounded-full' : 'rounded-ui-sm'} ${className}`}
      style={{ background: `linear-gradient(140deg, hsl(${h} 38% 30%), hsl(${(h + 48) % 360} 42% 16%))` }}
    >
      <div className="absolute inset-0 flex items-center justify-center text-white/30">
        <Music2 size={iconSize} strokeWidth={1.6} />
      </div>
      {src && (
        <motion.img
          key={coverKey ?? src}
          src={src}
          alt=""
          draggable={false}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.25 }}
          className="absolute inset-0 h-full w-full object-cover"
        />
      )}
    </div>
  );
}
