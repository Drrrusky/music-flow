import { AnimatePresence, motion } from 'framer-motion';
import { useEffect, useLayoutEffect, useRef, useState } from 'react';
import { AlertCircle, CheckCircle2, Info } from 'lucide-react';
import { useUi } from '@/stores/uiStore';

export function ContextMenuHost() {
  const menu = useUi((s) => s.menu);
  const close = useUi((s) => s.closeMenu);
  const ref = useRef<HTMLDivElement>(null);
  const [pos, setPos] = useState({ x: 0, y: 0 });

  useLayoutEffect(() => {
    if (!menu || !ref.current) return;
    const r = ref.current.getBoundingClientRect();
    setPos({ x: Math.min(menu.x, window.innerWidth - r.width - 8), y: Math.min(menu.y, window.innerHeight - r.height - 8) });
  }, [menu]);

  useEffect(() => {
    if (!menu) return;
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && close();
    window.addEventListener('keydown', onKey);
    window.addEventListener('blur', close);
    window.addEventListener('resize', close);
    return () => {
      window.removeEventListener('keydown', onKey);
      window.removeEventListener('blur', close);
      window.removeEventListener('resize', close);
    };
  }, [menu, close]);

  return (
    <AnimatePresence>
      {menu && (
        <>
          <div className="fixed inset-0 z-[90]" onPointerDown={close} onContextMenu={(e) => { e.preventDefault(); close(); }} />
          <motion.div
            ref={ref}
            role="menu"
            initial={{ opacity: 0, scale: 0.96 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.97 }}
            transition={{ duration: 0.12 }}
            style={{ left: pos.x || menu.x, top: pos.y || menu.y, transformOrigin: 'top left' }}
            className="glass hairline fixed z-[91] min-w-[220px] rounded-ui p-1.5 shadow-2xl"
          >
            {menu.items.map((it, i) =>
              it.separator ? (
                <div key={i} className="my-1 h-px bg-line/10" />
              ) : (
                <button
                  key={i}
                  role="menuitem"
                  disabled={it.disabled}
                  onClick={() => { close(); it.onClick?.(); }}
                  className={`flex w-full items-center justify-between gap-6 rounded-ui-sm px-3 py-2 text-left text-[13px] transition-colors enabled:hover:bg-fg/10 disabled:opacity-40 ${it.danger ? 'text-rose-400' : ''}`}
                >
                  <span>{it.label}</span>
                  {it.hint && <span className="text-[11px] text-muted">{it.hint}</span>}
                </button>
              ),
            )}
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}

const ICON = { info: Info, error: AlertCircle, success: CheckCircle2 } as const;
const TINT = { info: 'text-muted', error: 'text-rose-400', success: 'text-emerald-400' } as const;

export function Toasts() {
  const toasts = useUi((s) => s.toasts);
  return (
    <div className="pointer-events-none fixed inset-x-0 bottom-28 z-[95] flex flex-col items-center gap-2" aria-live="polite">
      <AnimatePresence>
        {toasts.map((t) => {
          const Icon = ICON[t.kind];
          return (
            <motion.div
              key={t.id}
              layout
              initial={{ opacity: 0, y: 14, scale: 0.96 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 6, scale: 0.97 }}
              transition={{ type: 'spring', stiffness: 420, damping: 32 }}
              className="glass hairline pointer-events-auto flex max-w-[520px] items-start gap-2.5 rounded-ui px-4 py-3 text-[13px] shadow-2xl"
            >
              <Icon size={16} className={`mt-0.5 shrink-0 ${TINT[t.kind]}`} />
              <span>{t.message}</span>
            </motion.div>
          );
        })}
      </AnimatePresence>
    </div>
  );
}
