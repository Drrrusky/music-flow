import { motion } from 'framer-motion';
import type { ButtonHTMLAttributes, ReactNode } from 'react';
import { Tip } from './Tip';

interface Props extends Omit<ButtonHTMLAttributes<HTMLButtonElement>, 'onDrag' | 'onDragStart' | 'onDragEnd' | 'onAnimationStart'> {
  label: string;
  children: ReactNode;
  active?: boolean;
  /** Si défini, le bouton est désactivé et cette phrase explique pourquoi. */
  unavailable?: string;
  size?: number;
  tipSide?: 'top' | 'bottom' | 'left' | 'right';
}

export function IconButton({ label, children, active, unavailable, size = 36, tipSide = 'top', className = '', ...rest }: Props) {
  const disabled = !!unavailable || rest.disabled;
  return (
    <Tip label={unavailable ? `${label} — ${unavailable}` : label} side={tipSide}>
      <motion.button
        type="button"
        aria-label={label}
        aria-pressed={active}
        disabled={disabled}
        whileTap={disabled ? undefined : { scale: 0.9 }}
        className={`inline-flex shrink-0 items-center justify-center rounded-full transition-colors ${active ? 'text-accent' : 'text-muted hover:text-fg'} ${disabled ? 'opacity-35 hover:text-muted' : ''} ${className}`}
        style={{ width: size, height: size }}
        {...rest}
      >
        {children}
      </motion.button>
    </Tip>
  );
}
