import { Component, type ErrorInfo, type ReactNode } from 'react';

interface State { error: Error | null }

/** Évite l'écran blanc : une erreur d'affichage ne doit jamais faire tomber toute l'application. */
export class ErrorBoundary extends Component<{ children: ReactNode; label?: string }, State> {
  state: State = { error: null };
  static getDerivedStateFromError(error: Error): State { return { error }; }
  componentDidCatch(error: Error, info: ErrorInfo) { console.error('[MusicFlow]', error, info.componentStack); }
  render() {
    if (!this.state.error) return this.props.children;
    return (
      <div className="flex h-full flex-col items-center justify-center gap-4 p-10 text-center">
        <h2 className="font-display text-[20px] font-semibold">{this.props.label ?? 'Quelque chose s’est mal passé'}</h2>
        <p className="max-w-md text-[13.5px] leading-relaxed text-muted">{this.state.error.message}</p>
        <button onClick={() => this.setState({ error: null })} className="rounded-full bg-accent px-5 py-2.5 text-[13.5px] font-semibold text-on-accent transition hover:brightness-110">Réessayer</button>
      </div>
    );
  }
}
