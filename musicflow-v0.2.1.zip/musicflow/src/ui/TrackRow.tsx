import { Heart, MoreHorizontal, Play } from 'lucide-react';
import type { Track } from '@/core/types';
import { engine } from '@/core/playback/engine';
import { useMediaQuery } from '@/hooks/useMediaQuery';
import { useLibrary } from '@/stores/libraryStore';
import { usePlayer } from '@/stores/playerStore';
import { useUi } from '@/stores/uiStore';
import { artistLine, albumKeyOf, artistKeyOf } from '@/utils/groups';
import { formatDate, formatTime } from '@/utils/format';
import { CoverArt } from './CoverArt';
import { NowPlayingBars } from './NowPlayingBars';
import { showTrackMenu } from './trackActions';

export function useRowColumns(opts: { album?: boolean; added?: boolean } = {}) {
  const wide = useMediaQuery('(min-width: 1180px)');
  const wider = useMediaQuery('(min-width: 1420px)');
  const album = (opts.album ?? true) && wide;
  const added = (opts.added ?? true) && wider;
  const cols = ['44px', 'minmax(0,5fr)', ...(album ? ['minmax(0,3fr)'] : []), ...(added ? ['112px'] : []), '36px', '60px', '32px'];
  return { album, added, template: cols.join(' ') };
}

interface Props {
  track: Track;
  index: number;
  list: Track[];
  columns: ReturnType<typeof useRowColumns>;
  /** Numéro affiché à gauche (par défaut : position dans la liste). */
  number?: number;
  showCover?: boolean;
}

export function TrackRow({ track, index, list, columns, number, showCover = true }: Props) {
  useLibrary((s) => s.rev); // re-rendu quand un like ou un compteur change
  const isCurrent = usePlayer((s) => s.current?.id === track.id);
  const playing = usePlayer((s) => s.status === 'playing');
  const nav = useUi((s) => s.navigate);
  const ctx = { list, index };

  return (
    <div
      onDoubleClick={() => void engine.playTracks(list, index)}
      onContextMenu={(e) => showTrackMenu(e, track, ctx)}
      className="group grid h-full items-center gap-3 rounded-ui-sm px-3 transition-colors hover:bg-fg/[0.06]"
      style={{ gridTemplateColumns: columns.template }}
    >
      <div className="flex items-center justify-center text-[13px] tabular-nums text-muted">
        <span className={`${isCurrent ? 'hidden' : 'group-hover:hidden'}`}>{number ?? index + 1}</span>
        {isCurrent && <span className="group-hover:hidden"><NowPlayingBars playing={playing} /></span>}
        <button
          aria-label={`Lire ${track.title}`}
          onClick={() => (isCurrent ? void engine.toggle() : void engine.playTracks(list, index))}
          className="hidden size-7 items-center justify-center rounded-full text-fg group-hover:flex"
        >
          <Play size={15} fill="currentColor" />
        </button>
      </div>

      <div className="flex min-w-0 items-center gap-3">
        {showCover && <CoverArt coverKey={track.coverKey} coverUrl={track.coverUrl} seed={track.album ?? track.title} className="size-10" iconSize={16} />}
        <div className="min-w-0">
          <div className={`truncate text-[14px] font-medium ${isCurrent ? 'text-accent' : ''}`}>{track.title}</div>
          <div className="truncate text-[12.5px] text-muted">
            {track.artists.length ? (
              track.artists.map((a, i) => (
                <span key={a}>
                  {i > 0 && ', '}
                  <button className="hover:text-fg hover:underline" onClick={() => nav({ name: 'artist', key: artistKeyOf(a) })}>{a}</button>
                </span>
              ))
            ) : (
              artistLine(track)
            )}
          </div>
        </div>
      </div>

      {columns.album && (
        <button
          disabled={!track.album}
          onClick={() => nav({ name: 'album', key: albumKeyOf(track) })}
          className="truncate text-left text-[13px] text-muted hover:text-fg hover:underline disabled:no-underline"
        >
          {track.album ?? '—'}
        </button>
      )}
      {columns.added && <div className="text-[12.5px] text-muted">{formatDate(track.addedAt)}</div>}

      <button
        aria-label={track.liked ? 'Retirer des titres likés' : 'Ajouter aux titres likés'}
        aria-pressed={track.liked}
        onClick={() => useLibrary.getState().toggleLike(track.id)}
        className={`flex size-8 items-center justify-center rounded-full transition ${track.liked ? 'text-accent' : 'text-muted opacity-0 hover:text-fg group-hover:opacity-100'}`}
      >
        <Heart size={16} fill={track.liked ? 'currentColor' : 'none'} />
      </button>
      <div className="text-right text-[12.5px] tabular-nums text-muted">{formatTime(track.durationSec)}</div>
      <button
        aria-label="Plus d’actions"
        onClick={(e) => showTrackMenu({ clientX: e.clientX, clientY: e.clientY, preventDefault: () => e.preventDefault() }, track, ctx)}
        className="flex size-8 items-center justify-center rounded-full text-muted opacity-0 hover:text-fg group-hover:opacity-100"
      >
        <MoreHorizontal size={16} />
      </button>
    </div>
  );
}
