import { AnimatePresence, motion } from 'framer-motion';
import { useDominantColor } from '@/hooks/useCover';
import { usePlayer } from '@/stores/playerStore';
import { useSettings } from '@/stores/settingsStore';

/** Halo de couleur issu de la pochette en cours : l'élément d'ambiance de l'application. */
export function Ambient() {
  const enabled = useSettings((s) => s.ambient);
  const key = usePlayer((s) => s.current?.coverKey);
  const url = usePlayer((s) => s.current?.coverUrl);
  const rgb = useDominantColor(key, url);
  if (!enabled) return null;
  const tone = (alpha: number) => (rgb ? `rgb(${rgb.join(' ')} / ${alpha})` : `rgb(var(--c-accent) / ${alpha})`);
  return (
    <div className="pointer-events-none absolute inset-0 overflow-hidden" aria-hidden>
      <AnimatePresence>
        <motion.div
          key={rgb ? rgb.join('-') : 'none'}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 1.2, ease: 'easeInOut' }}
          className="absolute inset-0"
          style={{
            background: `radial-gradient(900px 520px at 78% -8%, ${tone(0.3)}, transparent 70%), radial-gradient(700px 480px at 8% 108%, ${tone(0.16)}, transparent 70%)`,
          }}
        />
      </AnimatePresence>
    </div>
  );
}
