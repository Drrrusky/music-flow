import { useEffect, useRef, useState, type ReactNode } from 'react';

interface Props<T> {
  items: T[];
  rowHeight: number;
  renderRow: (item: T, index: number) => ReactNode;
  overscan?: number;
  className?: string;
  empty?: ReactNode;
}

/** Liste virtualisée à hauteur de ligne fixe : reste fluide avec des dizaines de milliers de titres. */
export function VirtualList<T>({ items, rowHeight, renderRow, overscan = 8, className = '', empty }: Props<T>) {
  const ref = useRef<HTMLDivElement>(null);
  const [top, setTop] = useState(0);
  const [height, setHeight] = useState(600);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const ro = new ResizeObserver(() => setHeight(el.clientHeight));
    ro.observe(el);
    setHeight(el.clientHeight);
    return () => ro.disconnect();
  }, []);

  const start = Math.max(0, Math.floor(top / rowHeight) - overscan);
  const end = Math.min(items.length, Math.ceil((top + height) / rowHeight) + overscan);

  return (
    <div
      ref={ref}
      className={`relative overflow-y-auto ${className}`}
      onScroll={(e) => {
        const y = e.currentTarget.scrollTop;
        requestAnimationFrame(() => setTop(y));
      }}
    >
      {items.length === 0 ? (
        empty
      ) : (
        <div style={{ height: items.length * rowHeight, position: 'relative' }}>
          {items.slice(start, end).map((it, i) => (
            <div key={start + i} style={{ position: 'absolute', top: (start + i) * rowHeight, left: 0, right: 0, height: rowHeight }}>
              {renderRow(it, start + i)}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
