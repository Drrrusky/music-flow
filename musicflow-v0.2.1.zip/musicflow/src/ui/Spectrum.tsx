import { useEffect, useRef } from 'react';
import { getAudioGraph } from '@/core/playback/AudioGraph';
import { usePlayer } from '@/stores/playerStore';

/** Spectre réel (AnalyserNode). Ne dessine que lorsqu'un titre est en lecture. */
export function Spectrum({ className = '' }: { className?: string }) {
  const ref = useRef<HTMLCanvasElement>(null);
  const playing = usePlayer((s) => s.status === 'playing');

  useEffect(() => {
    const canvas = ref.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    const dpr = window.devicePixelRatio || 1;
    const resize = () => {
      canvas.width = canvas.clientWidth * dpr;
      canvas.height = canvas.clientHeight * dpr;
    };
    resize();
    const ro = new ResizeObserver(resize);
    ro.observe(canvas);

    const analyser = getAudioGraph().analyser;
    const data = new Uint8Array(analyser.frequencyBinCount);
    const BARS = 48;
    let raf = 0;
    const accent = () => `rgb(${getComputedStyle(document.documentElement).getPropertyValue('--c-accent').trim().split(/\s+/).join(',')})`;

    const draw = () => {
      raf = requestAnimationFrame(draw);
      analyser.getByteFrequencyData(data);
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      ctx.fillStyle = accent();
      const w = canvas.width / BARS;
      const nyquist = analyser.context.sampleRate / 2;
      for (let i = 0; i < BARS; i++) {
        // Échelle logarithmique de 40 Hz à 16 kHz.
        const f0 = 40 * Math.pow(400, i / BARS);
        const f1 = 40 * Math.pow(400, (i + 1) / BARS);
        const a = Math.floor((f0 / nyquist) * data.length);
        const b = Math.max(a + 1, Math.floor((f1 / nyquist) * data.length));
        let max = 0;
        for (let k = a; k < b; k++) max = Math.max(max, data[k]);
        const h = Math.max(2 * dpr, (max / 255) * canvas.height * 0.95);
        ctx.globalAlpha = 0.35 + (max / 255) * 0.65;
        ctx.beginPath();
        ctx.roundRect(i * w + w * 0.15, canvas.height - h, w * 0.7, h, Math.min(w * 0.35, 4 * dpr));
        ctx.fill();
      }
    };
    if (playing) draw();
    else ctx.clearRect(0, 0, canvas.width, canvas.height);
    return () => { cancelAnimationFrame(raf); ro.disconnect(); };
  }, [playing]);

  return <canvas ref={ref} className={`w-full ${className}`} aria-hidden />;
}
