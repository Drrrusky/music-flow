import { repo } from './repository';

const cache = new Map<string, string | undefined>();
const pending = new Map<string, Promise<string | undefined>>();

/** Pochette (data URL) pour une clé, avec cache mémoire et requêtes dédupliquées. */
export function loadCover(key: string): Promise<string | undefined> {
  if (cache.has(key)) return Promise.resolve(cache.get(key));
  let p = pending.get(key);
  if (!p) {
    p = repo.getCover(key).then((data) => {
      cache.set(key, data);
      pending.delete(key);
      return data;
    }, () => {
      pending.delete(key);
      return undefined;
    });
    pending.set(key, p);
  }
  return p;
}

export const peekCover = (key?: string) => (key ? cache.get(key) : undefined);
export function primeCover(key: string, data: string) { cache.set(key, data); }
