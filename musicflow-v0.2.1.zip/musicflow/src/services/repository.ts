import type { TechInfo, Track } from '@/core/types';
import { getDb, inTauri } from './db';

interface TrackRow {
  id: string; provider: string; ref: string; title: string; artists: string;
  album_artist: string | null; album: string | null; year: number | null; genre: string | null;
  track_no: number | null; disc_no: number | null; duration: number; cover_key: string | null;
  isrc: string | null; label: string | null; replay_gain: number | null; tech: string | null;
  added_at: number; play_count: number; last_played_at: number | null; liked: number;
  cover_url: string | null; channel: string | null;
}

const u = <T,>(v: T | null | undefined): T | undefined => v ?? undefined;
const parse = <T,>(s: string | null, fallback: T): T => {
  if (!s) return fallback;
  try { return JSON.parse(s) as T; } catch { return fallback; }
};

function fromRow(r: TrackRow): Track {
  return {
    id: r.id, provider: r.provider as Track['provider'], ref: r.ref, title: r.title,
    artists: parse<string[]>(r.artists, []), albumArtist: u(r.album_artist), album: u(r.album),
    year: u(r.year), genre: u(r.genre), trackNo: u(r.track_no), discNo: u(r.disc_no),
    durationSec: r.duration, coverKey: u(r.cover_key), coverUrl: u(r.cover_url), channel: u(r.channel), isrc: u(r.isrc), label: u(r.label),
    replayGainDb: u(r.replay_gain), tech: parse<TechInfo | undefined>(r.tech, undefined),
    addedAt: r.added_at, playCount: r.play_count, lastPlayedAt: u(r.last_played_at), liked: r.liked === 1,
  };
}

const COLS = 23;
const chunk = <T,>(a: T[], n: number): T[][] => {
  const out: T[][] = [];
  for (let i = 0; i < a.length; i += n) out.push(a.slice(i, i + n));
  return out;
};

export const repo = {
  async loadTracks(): Promise<Track[]> {
    if (!inTauri()) return [];
    const db = await getDb();
    const rows = await db.select<TrackRow[]>('SELECT * FROM tracks');
    return rows.map(fromRow);
  },

  /** Insère ou met à jour les métadonnées sans écraser likes, compteurs ni date d'ajout. */
  async upsertTracks(tracks: Track[]): Promise<void> {
    if (!inTauri() || !tracks.length) return;
    const db = await getDb();
    for (const part of chunk(tracks, 100)) {
      const values: unknown[] = [];
      const rows = part.map((t, i) => {
        values.push(
          t.id, t.provider, t.ref, t.title, JSON.stringify(t.artists), t.albumArtist ?? null, t.album ?? null,
          t.year ?? null, t.genre ?? null, t.trackNo ?? null, t.discNo ?? null, t.durationSec, t.coverKey ?? null,
          t.isrc ?? null, t.label ?? null, t.replayGainDb ?? null, t.tech ? JSON.stringify(t.tech) : null,
          t.addedAt, t.playCount, t.lastPlayedAt ?? null, t.liked ? 1 : 0, t.coverUrl ?? null, t.channel ?? null,
        );
        const base = i * COLS;
        return `(${Array.from({ length: COLS }, (_, k) => `$${base + k + 1}`).join(',')})`;
      });
      await db.execute(
        `INSERT INTO tracks (id,provider,ref,title,artists,album_artist,album,year,genre,track_no,disc_no,duration,cover_key,isrc,label,replay_gain,tech,added_at,play_count,last_played_at,liked,cover_url,channel)
         VALUES ${rows.join(',')}
         ON CONFLICT(id) DO UPDATE SET title=excluded.title, artists=excluded.artists, album_artist=excluded.album_artist,
           album=excluded.album, year=excluded.year, genre=excluded.genre, track_no=excluded.track_no, disc_no=excluded.disc_no,
           duration=excluded.duration, cover_key=excluded.cover_key, isrc=excluded.isrc, label=excluded.label,
           replay_gain=excluded.replay_gain, tech=excluded.tech, cover_url=excluded.cover_url, channel=excluded.channel`,
        values,
      );
    }
  },

  async deleteTracks(ids: string[]): Promise<void> {
    if (!inTauri() || !ids.length) return;
    const db = await getDb();
    for (const part of chunk(ids, 500)) {
      await db.execute(`DELETE FROM tracks WHERE id IN (${part.map((_, i) => `$${i + 1}`).join(',')})`, part);
    }
  },

  async setLiked(id: string, liked: boolean) {
    if (!inTauri()) return;
    await (await getDb()).execute('UPDATE tracks SET liked = $1 WHERE id = $2', [liked ? 1 : 0, id]);
  },

  async recordPlay(id: string, at: number) {
    if (!inTauri()) return;
    const db = await getDb();
    await db.execute('UPDATE tracks SET play_count = play_count + 1, last_played_at = $1 WHERE id = $2', [at, id]);
    await db.execute('INSERT INTO plays (track_id, played_at) VALUES ($1, $2)', [id, at]);
  },

  async setDuration(id: string, sec: number) {
    if (!inTauri()) return;
    await (await getDb()).execute('UPDATE tracks SET duration = $1 WHERE id = $2', [sec, id]);
  },

  async getCover(key: string): Promise<string | undefined> {
    if (!inTauri()) return undefined;
    const rows = await (await getDb()).select<{ data: string }[]>('SELECT data FROM covers WHERE key = $1', [key]);
    return rows[0]?.data;
  },

  async putCover(key: string, data: string) {
    if (!inTauri()) return;
    await (await getDb()).execute('INSERT OR REPLACE INTO covers (key, data) VALUES ($1, $2)', [key, data]);
  },

  async coverKeys(): Promise<Set<string>> {
    if (!inTauri()) return new Set();
    const rows = await (await getDb()).select<{ key: string }[]>('SELECT key FROM covers');
    return new Set(rows.map((r) => r.key));
  },
};
