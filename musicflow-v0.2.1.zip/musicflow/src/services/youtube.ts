import { create } from 'zustand';
import { searchVideos, testApiKey } from '@/core/providers/youtube/api';
import { QuotaTracker } from '@/core/providers/youtube/quota';
import { useSettings } from '@/stores/settingsStore';
import type { Track } from '@/core/types';

export const ytQuota = new QuotaTracker(localStorage);

/** Signale à l'interface que le compteur a changé (il vit dans localStorage, hors de React). */
export const useYtQuotaRev = create<{ rev: number }>(() => ({ rev: 0 }));
const bump = () => useYtQuotaRev.setState((s) => ({ rev: s.rev + 1 }));

export async function ytSearch(query: string, signal?: AbortSignal): Promise<Track[]> {
  try {
    return await searchVideos(useSettings.getState().youtubeApiKey, query, { quota: ytQuota, signal });
  } finally {
    bump();
  }
}

export async function ytTestKey(key: string): Promise<void> {
  try {
    await testApiKey(key, { quota: ytQuota });
  } finally {
    bump();
  }
}
