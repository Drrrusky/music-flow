import { openUrl } from '@tauri-apps/plugin-opener';
import { inTauri } from './db';

/** Ouvre une adresse dans le navigateur par défaut. */
export async function openExternal(url: string): Promise<void> {
  try {
    if (inTauri()) await openUrl(url);
    else window.open(url, '_blank', 'noopener,noreferrer');
  } catch {
    window.open(url, '_blank', 'noopener,noreferrer');
  }
}

export const youtubeUrl = (videoId: string) => `https://www.youtube.com/watch?v=${encodeURIComponent(videoId)}`;
