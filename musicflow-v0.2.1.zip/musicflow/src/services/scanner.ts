import { open, readDir, readFile, stat } from '@tauri-apps/plugin-fs';
import { parseBlob, type IAudioMetadata } from 'music-metadata';
import type { Track } from '@/core/types';
import { hash53 } from '@/utils/hash';
import { albumKeyOf } from '@/utils/groups';
import { baseName, extOf, isAudioFile, joinPath, mimeOf, stripExt } from '@/utils/audio';

const COVER_FILE = /^(cover|folder|front|album|artwork)\.(jpe?g|png|webp)$/i;

export interface FileListing {
  files: string[];
  /** dossier → chemin d'une image de pochette (cover.jpg, folder.png…) */
  dirCovers: Map<string, string>;
  /** Racines réellement lisibles (un disque externe débranché ne doit pas vider la bibliothèque). */
  readableRoots: string[];
}

async function walk(dir: string, out: FileListing): Promise<boolean> {
  let entries;
  try {
    entries = await readDir(dir);
  } catch {
    return false;
  }
  for (const e of entries) {
    const full = joinPath(dir, e.name);
    if (e.isDirectory) await walk(full, out);
    else if (e.isFile) {
      if (isAudioFile(e.name)) out.files.push(full);
      else if (COVER_FILE.test(e.name) && !out.dirCovers.has(dir)) out.dirCovers.set(dir, full);
    }
  }
  return true;
}

export async function listAudioFiles(roots: string[]): Promise<FileListing> {
  const out: FileListing = { files: [], dirCovers: new Map(), readableRoots: [] };
  for (const root of roots) if (await walk(root, out)) out.readableRoots.push(root);
  return out;
}

/** Lit le début du fichier : suffisant pour les tags ID3v2 / Vorbis / MP4 sans charger tout l'audio. */
async function readHead(path: string, size: number, n: number): Promise<Blob> {
  const h = await open(path, { read: true });
  try {
    const buf = new Uint8Array(Math.min(n, size));
    const read = (await h.read(buf)) ?? 0;
    return new Blob([buf.subarray(0, read)], { type: mimeOf(path) });
  } finally {
    await h.close();
  }
}

async function readTags(path: string, size: number): Promise<{ meta: IAudioMetadata; truncated: boolean }> {
  let lastErr: unknown;
  for (const n of [1 << 20, 8 << 20, size]) {
    try {
      const blob = await readHead(path, size, n);
      const meta = await parseBlob(blob, { skipPostHeaders: true });
      return { meta, truncated: blob.size < size };
    } catch (e) {
      lastErr = e;
      if (n >= size) break;
    }
  }
  throw lastErr;
}

async function thumbnail(blob: Blob): Promise<string | undefined> {
  try {
    const bmp = await createImageBitmap(blob);
    const side = Math.min(bmp.width, bmp.height);
    const out = Math.min(400, side);
    const c = document.createElement('canvas');
    c.width = c.height = out;
    const ctx = c.getContext('2d');
    if (!ctx) return undefined;
    ctx.drawImage(bmp, (bmp.width - side) / 2, (bmp.height - side) / 2, side, side, 0, 0, out, out);
    bmp.close();
    return c.toDataURL('image/jpeg', 0.82);
  } catch {
    return undefined;
  }
}

export interface ScanContext {
  knownCovers: Set<string>;
  dirCovers: Map<string, string>;
  onCover: (key: string, data: string) => void;
}

export async function extractTrack(path: string, ctx: ScanContext): Promise<Track> {
  const { size } = await stat(path);
  const { meta, truncated } = await readTags(path, size);
  const { common, format } = meta;

  let durationSec = format.duration ?? 0;
  // Fichier MP3 à débit constant lu partiellement : on déduit la durée de la taille réelle.
  if (truncated && format.container === 'MPEG' && format.bitrate && format.codecProfile !== 'VBR' && !String(format.codecProfile).startsWith('V')) {
    durationSec = (size * 8) / format.bitrate;
  }

  const artists = common.artists?.length ? common.artists : common.artist ? [common.artist] : [];
  const id = `local:${hash53(path)}`;
  const track: Track = {
    id, provider: 'local', ref: path,
    title: common.title?.trim() || stripExt(baseName(path)),
    artists, albumArtist: common.albumartist || undefined, album: common.album || undefined,
    year: common.year, genre: common.genre?.[0], trackNo: common.track.no ?? undefined, discNo: common.disk.no ?? undefined,
    durationSec, isrc: common.isrc?.[0], label: common.label?.[0],
    replayGainDb: common.replaygain_track_gain?.dB,
    tech: {
      container: format.container, codec: format.codec,
      bitrateKbps: format.bitrate ? Math.round(format.bitrate / 1000) : undefined,
      sampleRateHz: format.sampleRate, bitsPerSample: format.bitsPerSample,
      channels: format.numberOfChannels, lossless: format.lossless, sizeBytes: size,
    },
    addedAt: Date.now(), playCount: 0, liked: false,
  };

  // Pochette : partagée par album quand il y a un album, sinon propre au morceau.
  const key = track.album ? albumKeyOf(track) : `t:${id}`;
  if (ctx.knownCovers.has(key)) {
    track.coverKey = key;
  } else {
    let data: string | undefined;
    const pic = common.picture?.[0];
    if (pic) data = await thumbnail(new Blob([pic.data as BlobPart], { type: pic.format }));
    if (!data) {
      const dir = path.slice(0, Math.max(path.lastIndexOf('\\'), path.lastIndexOf('/')));
      const file = ctx.dirCovers.get(dir);
      if (file) {
        try { data = await thumbnail(new Blob([await readFile(file) as BlobPart], { type: `image/${extOf(file) === 'jpg' ? 'jpeg' : extOf(file)}` })); } catch { /* pochette illisible : on continue */ }
      }
    }
    if (data) {
      ctx.knownCovers.add(key);
      ctx.onCover(key, data);
      track.coverKey = key;
    }
  }
  return track;
}

/** Exécute `fn` sur chaque élément avec au plus `limit` tâches simultanées. */
export async function mapPool<T, R>(items: T[], limit: number, fn: (item: T, i: number) => Promise<R>, onDone?: (done: number) => void): Promise<PromiseSettledResult<R>[]> {
  const results: PromiseSettledResult<R>[] = new Array(items.length);
  let next = 0, done = 0;
  const worker = async () => {
    while (next < items.length) {
      const i = next++;
      try { results[i] = { status: 'fulfilled', value: await fn(items[i], i) }; }
      catch (reason) { results[i] = { status: 'rejected', reason }; }
      onDone?.(++done);
    }
  };
  await Promise.all(Array.from({ length: Math.min(limit, items.length) }, worker));
  return results;
}
