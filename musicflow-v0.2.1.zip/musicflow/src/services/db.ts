import Database from '@tauri-apps/plugin-sql';

/** Vrai dans la fenêtre Tauri, faux dans un navigateur (ex. `npm run dev` seul). */
export const inTauri = () => typeof window !== 'undefined' && '__TAURI_INTERNALS__' in window;

let dbp: Promise<Database> | null = null;
export const getDb = (): Promise<Database> => (dbp ??= Database.load('sqlite:musicflow.db'));
