import type { ReactNode } from 'react';

export function Card({ title, description, children }: { title: string; description?: string; children: ReactNode }) {
  return (
    <section className="mb-5 rounded-ui-lg bg-fg/[0.045] p-6 hairline">
      <h2 className="font-display text-[17px] font-semibold">{title}</h2>
      {description && <p className="mt-1 max-w-xl text-[13px] leading-relaxed text-muted">{description}</p>}
      <div className="mt-3 divide-y divide-line/[0.07]">{children}</div>
    </section>
  );
}

export function Row({ label, hint, children }: { label: string; hint?: string; children: ReactNode }) {
  return (
    <div className="flex flex-wrap items-center justify-between gap-x-8 gap-y-2 py-3.5">
      <div className="min-w-0 max-w-md">
        <div className="text-[14px] font-medium">{label}</div>
        {hint && <div className="mt-0.5 text-[12.5px] leading-relaxed text-muted">{hint}</div>}
      </div>
      <div className="flex shrink-0 items-center gap-3">{children}</div>
    </div>
  );
}

export function Toggle({ checked, onChange, label }: { checked: boolean; onChange: (v: boolean) => void; label: string }) {
  return (
    <button
      role="switch"
      aria-checked={checked}
      aria-label={label}
      onClick={() => onChange(!checked)}
      className={`relative h-6 w-11 rounded-full transition-colors ${checked ? 'bg-accent' : 'bg-fg/20'}`}
    >
      <span className={`absolute left-0.5 top-0.5 size-5 rounded-full bg-white shadow transition-transform ${checked ? 'translate-x-5' : ''}`} />
    </button>
  );
}

export function Segmented<T extends string>({ value, options, onChange, label }: { value: T; options: { value: T; label: string }[]; onChange: (v: T) => void; label: string }) {
  return (
    <div role="radiogroup" aria-label={label} className="flex rounded-full bg-fg/[0.08] p-1">
      {options.map((o) => (
        <button key={o.value} role="radio" aria-checked={value === o.value} onClick={() => onChange(o.value)} className={`rounded-full px-3.5 py-1.5 text-[13px] font-medium transition-colors ${value === o.value ? 'bg-fg text-bg shadow' : 'text-muted hover:text-fg'}`}>
          {o.label}
        </button>
      ))}
    </div>
  );
}

export const selectCls = 'rounded-full bg-fg/[0.08] px-4 py-2 text-[13px] outline-none focus-visible:ring-2 focus-visible:ring-accent/60';
