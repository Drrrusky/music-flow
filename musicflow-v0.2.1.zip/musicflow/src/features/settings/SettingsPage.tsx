import { Eye, EyeOff, FolderPlus, RefreshCw, Trash2 } from 'lucide-react';
import { useEffect, useState } from 'react';
import { EQ_LABELS, EQ_PRESETS } from '@/core/playback/AudioGraph';
import { FEATURES } from '@/core/features';
import { useLibrary } from '@/stores/libraryStore';
import { DEFAULT_SHORTCUTS, useSettings, type ShortcutAction } from '@/stores/settingsStore';
import { prettyCombo } from '@/utils/shortcuts';
import { SEARCH_DAILY_LIMIT, UNITS_DAILY_LIMIT } from '@/core/providers/youtube/quota';
import { openExternal } from '@/services/external';
import { useYtQuotaRev, ytQuota, ytTestKey } from '@/services/youtube';
import { plural } from '@/utils/format';
import { Slider } from '@/ui/Slider';
import { Spectrum } from '@/ui/Spectrum';
import { StatusBadge } from '@/ui/StatusBadge';
import { Card, Row, Segmented, Toggle, selectCls } from './controls';

const ACCENTS = ['#8b7cff', '#5b9dff', '#2dd4bf', '#4ade80', '#facc15', '#fb923c', '#f472b6', '#ef4444'];

const SHORTCUT_LABELS: Record<ShortcutAction, string> = {
  playPause: 'Lecture / pause', next: 'Titre suivant', prev: 'Titre précédent', search: 'Rechercher', like: 'Ajouter aux titres likés',
  queue: 'Afficher la file d’attente', settings: 'Ouvrir les paramètres', volumeUp: 'Volume +', volumeDown: 'Volume −', mute: 'Couper le son',
};

const SECTIONS = [
  { id: 'appearance', label: 'Apparence' },
  { id: 'audio', label: 'Lecture et audio' },
  { id: 'library', label: 'Bibliothèque' },
  { id: 'sources', label: 'Sources en ligne' },
  { id: 'shortcuts', label: 'Raccourcis' },
  { id: 'status', label: 'État des fonctionnalités' },
] as const;
type SectionId = (typeof SECTIONS)[number]['id'];

function Appearance() {
  const s = useSettings();
  return (
    <>
      <Card title="Thème et couleurs">
        <Row label="Prénom affiché" hint="Utilisé pour te saluer sur l’accueil.">
          <input value={s.displayName} onChange={(e) => s.update({ displayName: e.target.value })} placeholder="Ton prénom" aria-label="Prénom affiché" className="w-44 rounded-full bg-fg/[0.08] px-4 py-2 text-[13px] outline-none placeholder:text-muted focus-visible:ring-2 focus-visible:ring-accent/60" />
        </Row>
        <Row label="Thème">
          <Segmented label="Thème" value={s.theme} onChange={(theme) => s.update({ theme })} options={[{ value: 'dark', label: 'Sombre' }, { value: 'light', label: 'Clair' }, { value: 'auto', label: 'Automatique' }]} />
        </Row>
        <Row label="Couleur d’accent">
          <div className="flex items-center gap-2" role="radiogroup" aria-label="Couleur d’accent">
            {ACCENTS.map((c) => (
              <button key={c} role="radio" aria-checked={s.accent === c} aria-label={c} onClick={() => s.update({ accent: c })} className={`size-6 rounded-full transition-transform hover:scale-110 ${s.accent === c ? 'ring-2 ring-fg ring-offset-2 ring-offset-surface' : ''}`} style={{ background: c }} />
            ))}
            <label className="relative ml-1 flex size-6 cursor-pointer items-center justify-center overflow-hidden rounded-full bg-[conic-gradient(red,yellow,lime,aqua,blue,magenta,red)]" title="Couleur personnalisée">
              <input type="color" value={s.accent} onChange={(e) => s.update({ accent: e.target.value })} aria-label="Couleur personnalisée" className="absolute inset-0 cursor-pointer opacity-0" />
            </label>
          </div>
        </Row>
        <Row label="Arrière-plan dynamique" hint="Un halo de couleur tiré de la pochette en cours.">
          <Toggle label="Arrière-plan dynamique" checked={s.ambient} onChange={(ambient) => s.update({ ambient })} />
        </Row>
      </Card>
      <Card title="Forme et densité">
        <Row label="Intensité du flou" hint={`${s.blur} px`}><div className="w-48"><Slider label="Intensité du flou" min={0} max={40} step={1} value={s.blur} onChange={(blur) => s.update({ blur })} /></div></Row>
        <Row label="Arrondis" hint={`${s.radius} px`}><div className="w-48"><Slider label="Arrondis" min={4} max={28} step={1} value={s.radius} onChange={(radius) => s.update({ radius })} /></div></Row>
        <Row label="Densité des listes">
          <Segmented label="Densité" value={s.density} onChange={(density) => s.update({ density })} options={[{ value: 'compact', label: 'Compacte' }, { value: 'comfortable', label: 'Confortable' }, { value: 'spacious', label: 'Aérée' }]} />
        </Row>
        <Row label="Animations" hint="Désactive transitions et micro-interactions (utile sur un PC modeste).">
          <Toggle label="Animations" checked={s.animations} onChange={(animations) => s.update({ animations })} />
        </Row>
        <Row label="Page de démarrage">
          <Segmented label="Page de démarrage" value={s.startPage} onChange={(startPage) => s.update({ startPage })} options={[{ value: 'home', label: 'Accueil' }, { value: 'search', label: 'Recherche' }, { value: 'library', label: 'Bibliothèque' }]} />
        </Row>
      </Card>
    </>
  );
}

function AudioSection() {
  const s = useSettings();
  const eq = s.eq;
  const [devices, setDevices] = useState<MediaDeviceInfo[]>([]);

  const loadDevices = async () => {
    try {
      const all = await navigator.mediaDevices.enumerateDevices();
      setDevices(all.filter((d) => d.kind === 'audiooutput'));
    } catch { setDevices([]); }
  };
  useEffect(() => { void loadDevices(); }, []);

  const setBand = (i: number, v: number) => {
    const bands = eq.bands.slice();
    bands[i] = v;
    s.updateEq({ bands, preset: 'Personnalisé' });
  };

  return (
    <>
      <Card title="Lecture">
        <Row label="Reprendre la dernière session" hint="Au lancement, la file et la position sont restaurées (en pause).">
          <Toggle label="Reprendre la dernière session" checked={s.resumeLastSession} onChange={(resumeLastSession) => s.update({ resumeLastSession })} />
        </Row>
        <Row label="Normaliser le volume" hint="Applique le tag ReplayGain des fichiers pour égaliser les niveaux. Sans tag, aucun effet.">
          <Toggle label="Normaliser le volume" checked={s.normalize} onChange={(normalize) => s.update({ normalize })} />
        </Row>
        <Row label="Sortie audio" hint="Selon la version de WebView2, le changement peut ne pas être pris en charge.">
          <select aria-label="Sortie audio" className={selectCls} value={s.outputDeviceId} onChange={(e) => s.update({ outputDeviceId: e.target.value })}>
            <option value="" className="bg-raised">Sortie par défaut de Windows</option>
            {devices.filter((d) => d.deviceId && d.deviceId !== 'default').map((d, i) => <option key={d.deviceId} value={d.deviceId} className="bg-raised">{d.label || `Sortie ${i + 1}`}</option>)}
          </select>
        </Row>
      </Card>

      <Card title="Égaliseur" description="Réellement appliqué au signal des fichiers locaux. Indisponible avec YouTube, dont le flux audio n’est pas accessible.">
        <Row label="Activer l’égaliseur">
          <Toggle label="Activer l’égaliseur" checked={eq.enabled} onChange={(enabled) => s.updateEq({ enabled })} />
        </Row>
        <Row label="Préréglage">
          <select aria-label="Préréglage" className={selectCls} value={eq.preset} onChange={(e) => { const p = e.target.value; if (EQ_PRESETS[p]) s.updateEq({ preset: p, bands: EQ_PRESETS[p].slice() }); }}>
            {Object.keys(EQ_PRESETS).map((p) => <option key={p} value={p} className="bg-raised">{p}</option>)}
            {!EQ_PRESETS[eq.preset] && <option value={eq.preset} className="bg-raised">{eq.preset}</option>}
          </select>
        </Row>
        <div className={`py-5 transition-opacity ${eq.enabled ? '' : 'opacity-40'}`}>
          <Spectrum className="mb-4 h-16" />
          <div className="flex items-stretch justify-between gap-1">
            {EQ_LABELS.map((label, i) => (
              <div key={label} className="flex flex-1 flex-col items-center gap-2">
                <span className="text-[11px] tabular-nums text-muted">{eq.bands[i] > 0 ? '+' : ''}{eq.bands[i].toFixed(1)}</span>
                <div className="h-36"><Slider vertical centered label={`Bande ${label} Hz`} min={-12} max={12} step={0.5} keyStep={1} value={eq.bands[i]} onChange={(v) => setBand(i, v)} disabled={!eq.enabled} valueText={(v) => `${v} dB`} /></div>
                <span className="text-[11px] text-muted">{label}</span>
              </div>
            ))}
          </div>
        </div>
        <Row label="Préampli" hint={`${eq.preamp > 0 ? '+' : ''}${eq.preamp.toFixed(1)} dB — baisse-le si le son sature quand tu montes des bandes.`}>
          <div className="w-48"><Slider label="Préampli" min={-12} max={12} step={0.5} keyStep={1} centered value={eq.preamp} onChange={(preamp) => s.updateEq({ preamp })} disabled={!eq.enabled} /></div>
        </Row>
        <Row label="Balance gauche / droite" hint={eq.balance === 0 ? 'Centrée' : eq.balance < 0 ? `${Math.round(-eq.balance * 100)} % à gauche` : `${Math.round(eq.balance * 100)} % à droite`}>
          <div className="w-48"><Slider label="Balance" min={-1} max={1} step={0.05} keyStep={0.1} centered value={eq.balance} onChange={(balance) => s.updateEq({ balance })} /></div>
          <button onClick={() => s.updateEq({ balance: 0 })} className="text-[12.5px] text-muted hover:text-fg hover:underline">Centrer</button>
        </Row>
      </Card>
    </>
  );
}

function LibrarySection() {
  const folders = useSettings((s) => s.libraryFolders);
  const { addFolder, removeFolder, rescan, scanning, progress, tracks, albums, artists } = useLibrary();
  return (
    <Card title="Dossiers de musique" description="MusicFlow analyse ces dossiers (sous-dossiers compris) et garde l’index sur cet ordinateur. Tes fichiers ne sont jamais modifiés ni copiés.">
      <div className="py-3 text-[13px] text-muted">{plural(tracks.length, 'titre', 'titres')} · {plural(albums.length, 'album', 'albums')} · {plural(artists.length, 'artiste', 'artistes')}</div>
      {folders.length === 0 ? (
        <div className="py-4 text-[13.5px] text-muted">Aucun dossier pour l’instant.</div>
      ) : (
        folders.map((f) => (
          <div key={f} className="flex items-center justify-between gap-4 py-3">
            <span className="truncate text-[13.5px]" title={f}>{f}</span>
            <button onClick={() => void removeFolder(f)} aria-label={`Retirer ${f}`} className="flex shrink-0 items-center gap-1.5 rounded-full px-3 py-1.5 text-[12.5px] text-muted transition-colors hover:bg-rose-500/15 hover:text-rose-400"><Trash2 size={14} /> Retirer</button>
          </div>
        ))
      )}
      <div className="flex flex-wrap items-center gap-3 pt-4">
        <button onClick={() => void addFolder()} disabled={scanning} className="flex items-center gap-2 rounded-full bg-accent px-5 py-2.5 text-[13.5px] font-semibold text-on-accent transition hover:brightness-110 active:scale-95 disabled:opacity-50"><FolderPlus size={16} /> Ajouter un dossier</button>
        <button onClick={() => void rescan()} disabled={scanning || !folders.length} className="flex items-center gap-2 rounded-full bg-fg/10 px-5 py-2.5 text-[13.5px] font-medium transition hover:bg-fg/15 active:scale-95 disabled:opacity-40"><RefreshCw size={15} className={scanning ? 'animate-spin' : ''} /> Actualiser</button>
        {scanning && progress && <span className="text-[13px] text-muted" role="status">{progress.done.toLocaleString('fr-FR')} / {progress.total.toLocaleString('fr-FR')}</span>}
      </div>
    </Card>
  );
}

function Sources() {
  const key = useSettings((s) => s.youtubeApiKey);
  const update = useSettings((s) => s.update);
  useYtQuotaRev((s) => s.rev);
  const [show, setShow] = useState(false);
  const [test, setTest] = useState<{ state: 'idle' | 'busy' | 'ok' | 'error'; message?: string }>({ state: 'idle' });
  const q = ytQuota.state();

  const run = async () => {
    setTest({ state: 'busy' });
    try { await ytTestKey(key.trim()); setTest({ state: 'ok' }); }
    catch (e) { setTest({ state: 'error', message: e instanceof Error ? e.message : String(e) }); }
  };

  return (
    <Card title="YouTube" description="Recherche via l’API officielle YouTube Data v3, lecture via le lecteur intégré officiel. Sans accès au flux audio : pas d’égaliseur ni de visualiseur sur ces titres.">
      <Row label="Clé API YouTube Data v3" hint="Gratuite. Console Google Cloud › activer « YouTube Data API v3 » › Identifiants › Créer une clé API. Ne restreins pas la clé à des sites (référents) : l’application n’a pas d’adresse web.">
        <div className="flex items-center gap-2">
          <input type={show ? 'text' : 'password'} value={key} onChange={(e) => { update({ youtubeApiKey: e.target.value }); setTest({ state: 'idle' }); }} placeholder="AIza…" aria-label="Clé API YouTube" autoComplete="off" spellCheck={false} className="w-60 rounded-full bg-fg/[0.08] px-4 py-2 text-[13px] outline-none placeholder:text-muted focus-visible:ring-2 focus-visible:ring-accent/60" />
          <button onClick={() => setShow((v) => !v)} aria-label={show ? 'Masquer la clé' : 'Afficher la clé'} className="flex size-9 items-center justify-center rounded-full bg-fg/[0.08] text-muted hover:text-fg">{show ? <EyeOff size={16} /> : <Eye size={16} />}</button>
        </div>
      </Row>
      <Row label="Tester la clé" hint={test.state === 'ok' ? 'Clé valide.' : test.state === 'error' ? test.message : 'Un appel à 1 unité, sans entamer les 100 recherches du jour.'}>
        <button onClick={() => void run()} disabled={!key.trim() || test.state === 'busy'} className="rounded-full bg-fg/10 px-5 py-2 text-[13px] font-medium transition hover:bg-fg/15 active:scale-95 disabled:opacity-40">{test.state === 'busy' ? 'Test…' : 'Tester'}</button>
      </Row>
      <Row label="Quota du jour (estimation)" hint={`Recherches : ${q.searches} / ${SEARCH_DAILY_LIMIT} · autres appels : ${q.units} / ${UNITS_DAILY_LIMIT.toLocaleString('fr-FR')}. Remise à zéro à minuit, heure du Pacifique (9 h en France). Seule la console Google Cloud fait foi.`}>
        <button onClick={() => void openExternal('https://console.cloud.google.com/iam-admin/quotas')} className="text-[12.5px] text-muted hover:text-fg hover:underline">Ouvrir la console</button>
      </Row>
      <div className="py-3.5 text-[12.5px] leading-relaxed text-muted">
        La clé est enregistrée en clair dans les réglages de l’application sur cet ordinateur (un stockage sécurisé est prévu à l’étape 7). Ne la partage pas.
      </div>
    </Card>
  );
}

function Shortcuts() {
  const shortcuts = useSettings((s) => s.shortcuts);
  return (
    <Card title="Raccourcis clavier" description="Actifs dès maintenant. Les combinaisons évitent les raccourcis système de Windows. La personnalisation arrive à l’étape 6.">
      {(Object.keys(DEFAULT_SHORTCUTS) as ShortcutAction[]).map((a) => (
        <Row key={a} label={SHORTCUT_LABELS[a]}><kbd className="rounded-md bg-fg/10 px-2.5 py-1 text-[12.5px]">{prettyCombo(shortcuts[a])}</kbd></Row>
      ))}
    </Card>
  );
}

function Status() {
  const areas = [...new Set(FEATURES.map((f) => f.area))];
  const count = (st: string) => FEATURES.filter((f) => f.status === st).length;
  return (
    <>
      <p className="mb-5 max-w-2xl text-[13.5px] leading-relaxed text-muted">
        Rien n’est simulé : chaque fonction est classée selon ce qu’elle fait réellement aujourd’hui. {count('functional')} fonctionnelles, {count('partial')} partielles, {count('pending')} en attente, {count('unavailable')} non disponibles.
      </p>
      {areas.map((area) => (
        <Card key={area} title={area}>
          {FEATURES.filter((f) => f.area === area).map((f) => (
            <div key={f.name} className="flex items-start justify-between gap-6 py-3">
              <div className="min-w-0">
                <div className="text-[13.5px] font-medium">{f.name}</div>
                {f.note && <div className="mt-0.5 text-[12.5px] leading-relaxed text-muted">{f.note}</div>}
              </div>
              <StatusBadge status={f.status} />
            </div>
          ))}
        </Card>
      ))}
    </>
  );
}

export function SettingsPage({ initial }: { initial?: string }) {
  const [section, setSection] = useState<SectionId>((SECTIONS.find((s) => s.id === initial)?.id ?? 'appearance') as SectionId);
  const reset = useSettings((s) => s.reset);
  const [confirmReset, setConfirmReset] = useState(false);
  return (
    <div className="flex h-full flex-col px-8">
      <h1 className="pb-4 font-display text-[30px] font-semibold tracking-tight">Paramètres</h1>
      <div className="flex min-h-0 flex-1 gap-8">
        <nav className="w-52 shrink-0" aria-label="Sections des paramètres">
          {SECTIONS.map((s) => (
            <button key={s.id} onClick={() => setSection(s.id)} aria-current={section === s.id} className={`mb-0.5 block w-full rounded-ui-sm px-4 py-2.5 text-left text-[14px] font-medium transition-colors ${section === s.id ? 'bg-fg/10 text-fg' : 'text-muted hover:bg-fg/[0.06] hover:text-fg'}`}>{s.label}</button>
          ))}
          {confirmReset ? (
            <div className="mt-6 px-4 text-[12.5px]">
              <div className="mb-2 text-muted">Remettre tous les réglages par défaut ? Ta bibliothèque n’est pas touchée.</div>
              <button onClick={() => { reset(); setConfirmReset(false); }} className="mr-3 font-medium text-rose-400 hover:underline">Réinitialiser</button>
              <button onClick={() => setConfirmReset(false)} className="text-muted hover:text-fg hover:underline">Annuler</button>
            </div>
          ) : (
            <button onClick={() => setConfirmReset(true)} className="mt-6 px-4 text-[12.5px] text-muted hover:text-rose-400 hover:underline">Réinitialiser les réglages</button>
          )}
        </nav>
        <div className="min-w-0 max-w-3xl flex-1 overflow-y-auto pb-10 pr-2">
          {section === 'appearance' && <Appearance />}
          {section === 'audio' && <AudioSection />}
          {section === 'library' && <LibrarySection />}
          {section === 'sources' && <Sources />}
          {section === 'shortcuts' && <Shortcuts />}
          {section === 'status' && <Status />}
        </div>
      </div>
    </div>
  );
}
