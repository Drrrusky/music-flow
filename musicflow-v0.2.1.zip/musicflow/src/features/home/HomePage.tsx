import { Play } from 'lucide-react';
import { useMemo } from 'react';
import { engine } from '@/core/playback/engine';
import { useLibrary } from '@/stores/libraryStore';
import { usePlayer } from '@/stores/playerStore';
import { useSettings } from '@/stores/settingsStore';
import { useUi } from '@/stores/uiStore';
import { artistLine } from '@/utils/groups';
import { plural } from '@/utils/format';
import { AlbumCard, EmptyState, Section, Shelf, TrackTile } from '@/ui/Cards';
import { CoverArt } from '@/ui/CoverArt';
import { StatusBadge } from '@/ui/StatusBadge';

function greeting(name: string) {
  const h = new Date().getHours();
  const base = h >= 5 && h < 18 ? 'Bonjour' : 'Bonsoir';
  return name.trim() ? `${base}, ${name.trim()}` : base;
}

function Resume() {
  const current = usePlayer((s) => s.current);
  const status = usePlayer((s) => s.status);
  const position = usePlayer((s) => s.position);
  const duration = usePlayer((s) => s.duration);
  if (!current || status === 'playing') return null;
  const pct = duration ? Math.min(100, (position / duration) * 100) : 0;
  return (
    <Section title="Reprendre">
      <button onClick={() => void engine.toggle()} className="group flex w-full max-w-2xl items-center gap-5 rounded-ui-lg bg-fg/[0.06] p-4 text-left transition-colors hover:bg-fg/[0.1]">
        <CoverArt coverKey={current.coverKey} coverUrl={current.coverUrl} seed={current.album ?? current.title} className="size-24 shadow-xl shadow-black/30" iconSize={30} />
        <div className="min-w-0 flex-1">
          <div className="truncate font-display text-[20px] font-semibold">{current.title}</div>
          <div className="truncate text-[13.5px] text-muted">{artistLine(current)}</div>
          <div className="mt-3 h-1 overflow-hidden rounded-full bg-fg/15"><div className="h-full rounded-full bg-accent" style={{ width: `${pct}%` }} /></div>
        </div>
        <span className="flex size-12 shrink-0 items-center justify-center rounded-full bg-accent text-on-accent shadow-lg transition group-hover:scale-105"><Play size={20} fill="currentColor" className="ml-0.5" /></span>
      </button>
    </Section>
  );
}

export function HomePage() {
  const { tracks, albums, ready, rev, addFolder, scanning } = useLibrary();
  const name = useSettings((s) => s.displayName);
  const navigate = useUi((s) => s.navigate);

  const { recent, newest, top } = useMemo(() => {
    const recent = tracks.filter((t) => t.lastPlayedAt).sort((a, b) => (b.lastPlayedAt ?? 0) - (a.lastPlayedAt ?? 0)).slice(0, 8);
    const newest = [...albums].sort((a, b) => b.addedAt - a.addedAt).slice(0, 14);
    const top = tracks.filter((t) => t.playCount > 0).sort((a, b) => b.playCount - a.playCount).slice(0, 8);
    return { recent, newest, top };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [tracks, albums, rev]);

  return (
    <div className="h-full overflow-y-auto px-8 pb-8">
      <h1 className="font-display text-[34px] font-semibold leading-tight tracking-tight">{greeting(name)}</h1>
      {ready && tracks.length > 0 && (
        <p className="mb-8 mt-1 text-[14px] text-muted">{plural(tracks.length, 'titre', 'titres')} · {plural(albums.length, 'album', 'albums')}</p>
      )}

      {!ready ? (
        <div className="mt-8 grid grid-cols-4 gap-3">{Array.from({ length: 8 }, (_, i) => <div key={i} className="skeleton h-14 rounded-ui" />)}</div>
      ) : tracks.length === 0 ? (
        <EmptyState
          title={scanning ? 'Analyse de ta musique…' : 'Ajoute ta musique'}
          text="Choisis un dossier contenant tes fichiers (MP3, FLAC, OGG, Opus, M4A, AAC, WAV). MusicFlow lit les tags et les pochettes, et garde tout sur cet ordinateur."
          action={scanning ? undefined : { label: 'Choisir un dossier', onClick: () => void addFolder() }}
        />
      ) : (
        <>
          <Resume />
          {recent.length > 0 && (
            <Section title="Écoutés récemment">
              <div className="grid gap-3" style={{ gridTemplateColumns: 'repeat(auto-fill, minmax(260px, 1fr))' }}>
                {recent.map((t, i) => <TrackTile key={t.id} track={t} list={recent} index={i} />)}
              </div>
            </Section>
          )}
          <Section title="Ajoutés récemment" action={<button onClick={() => navigate({ name: 'library', tab: 'albums' })} className="text-[13px] text-muted hover:text-fg hover:underline">Tout voir</button>}>
            <Shelf>{newest.map((a) => <div key={a.key} className="w-[188px] shrink-0"><AlbumCard album={a} /></div>)}</Shelf>
          </Section>
          {top.length > 0 && (
            <Section title="Les plus écoutés">
              <div className="grid gap-3" style={{ gridTemplateColumns: 'repeat(auto-fill, minmax(260px, 1fr))' }}>
                {top.map((t, i) => <TrackTile key={t.id} track={t} list={top} index={i} />)}
              </div>
            </Section>
          )}
          <Section title="Découverte">
            <div className="flex max-w-2xl items-start gap-3 rounded-ui bg-fg/[0.05] p-4 text-[13px] leading-relaxed text-muted">
              <StatusBadge status="pending" />
              <p>Recommandations, nouveautés et mix personnalisés demandent un catalogue en ligne. Ils arriveront avec l’intégration YouTube (étape 3) ; rien n’est simulé en attendant.</p>
            </div>
          </Section>
        </>
      )}
    </div>
  );
}
