import { Play, Shuffle } from 'lucide-react';
import { useMemo } from 'react';
import { engine } from '@/core/playback/engine';
import { useLibrary } from '@/stores/libraryStore';
import { DENSITY_ROW, useSettings } from '@/stores/settingsStore';
import { plural } from '@/utils/format';
import { AlbumCard, EmptyState, Section } from '@/ui/Cards';
import { CoverArt } from '@/ui/CoverArt';
import { StatusBadge } from '@/ui/StatusBadge';
import { TrackRow, useRowColumns } from '@/ui/TrackRow';

export function ArtistPage({ artistKey }: { artistKey: string }) {
  const artist = useLibrary((s) => s.artistsByKey.get(artistKey));
  const albumsByKey = useLibrary((s) => s.albumsByKey);
  const rev = useLibrary((s) => s.rev);
  const rowH = DENSITY_ROW[useSettings((s) => s.density)];
  const columns = useRowColumns({ added: false });

  const data = useMemo(() => {
    if (!artist) return null;
    const albums = artist.albumKeys.map((k) => albumsByKey.get(k)).filter((a) => !!a);
    const own = albums.filter((a) => a!.artist === artist.name);
    const featuring = albums.filter((a) => a!.artist !== artist.name);
    const played = [...artist.tracks].filter((t) => t.playCount > 0).sort((a, b) => b.playCount - a.playCount);
    const top = (played.length >= 3 ? played : [...artist.tracks].sort((a, b) => a.title.localeCompare(b.title, 'fr'))).slice(0, 5);
    return { own: own as NonNullable<typeof own[number]>[], featuring: featuring as NonNullable<typeof featuring[number]>[], top, hasPlays: played.length >= 3 };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [artist, albumsByKey, rev]);

  if (!artist || !data) return <EmptyState title="Artiste introuvable" text="Il a peut-être été retiré de la bibliothèque." />;

  return (
    <div className="h-full overflow-y-auto px-8 pb-10">
      <header className="flex flex-wrap items-end gap-7 pb-7 pt-2">
        <CoverArt coverKey={artist.coverKey} seed={artist.name} round className="size-[200px] shadow-2xl shadow-black/40" iconSize={56} />
        <div className="min-w-0">
          <h1 className="font-display text-[46px] font-semibold leading-[1.05] tracking-tight">{artist.name}</h1>
          <p className="mt-3 text-[14px] text-muted">{plural(artist.tracks.length, 'titre', 'titres')} · {plural(artist.albumKeys.length, 'album', 'albums')}</p>
          <div className="mt-5 flex items-center gap-3">
            <button onClick={() => void engine.playTracks(artist.tracks, 0, false)} className="flex items-center gap-2 rounded-full bg-accent px-6 py-3 text-[14px] font-semibold text-on-accent transition hover:brightness-110 active:scale-95"><Play size={17} fill="currentColor" /> Lire</button>
            <button onClick={() => void engine.playTracks(artist.tracks, 0, true)} className="flex items-center gap-2 rounded-full bg-fg/10 px-5 py-3 text-[14px] font-medium transition hover:bg-fg/15 active:scale-95"><Shuffle size={16} /> Aléatoire</button>
          </div>
        </div>
      </header>

      <Section title={data.hasPlays ? 'Les plus écoutés' : 'Titres'}>
        {data.top.map((t, i) => (
          <div key={t.id} style={{ height: rowH }}><TrackRow track={t} index={i} list={data.top} columns={columns} /></div>
        ))}
      </Section>

      {data.own.length > 0 && (
        <Section title="Albums">
          <div className="-mx-2 grid gap-1" style={{ gridTemplateColumns: 'repeat(auto-fill, minmax(176px, 1fr))' }}>
            {[...data.own].sort((a, b) => (b.year ?? 0) - (a.year ?? 0)).map((a) => <AlbumCard key={a.key} album={a} />)}
          </div>
        </Section>
      )}
      {data.featuring.length > 0 && (
        <Section title="Collaborations et featurings">
          <div className="-mx-2 grid gap-1" style={{ gridTemplateColumns: 'repeat(auto-fill, minmax(176px, 1fr))' }}>
            {data.featuring.map((a) => <AlbumCard key={a.key} album={a} />)}
          </div>
        </Section>
      )}

      <div className="flex max-w-2xl items-start gap-3 rounded-ui bg-fg/[0.05] p-4 text-[13px] leading-relaxed text-muted">
        <StatusBadge status="pending" />
        <p>Photo, biographie, popularité et artistes similaires ne sont pas dans les fichiers. Ils viendront d’une source autorisée (étape 4). La pochette affichée est celle d’un de ses albums.</p>
      </div>
    </div>
  );
}
