import { ArrowDown, ArrowUp, FolderPlus, RefreshCw, Search as SearchIcon } from 'lucide-react';
import { useMemo, useState } from 'react';
import type { Track } from '@/core/types';
import { useLibrary } from '@/stores/libraryStore';
import { DENSITY_ROW, useSettings } from '@/stores/settingsStore';
import { useUi } from '@/stores/uiStore';
import { artistLine } from '@/utils/groups';
import { norm } from '@/utils/text';
import { plural } from '@/utils/format';
import { AlbumCard, ArtistCard, EmptyState } from '@/ui/Cards';
import { TrackRow, useRowColumns } from '@/ui/TrackRow';
import { VirtualList } from '@/ui/VirtualList';

type SortKey = 'added' | 'title' | 'artist' | 'album' | 'duration' | 'year' | 'plays';
const SORTS: { key: SortKey; label: string }[] = [
  { key: 'added', label: 'Date d’ajout' }, { key: 'title', label: 'Titre' }, { key: 'artist', label: 'Artiste' },
  { key: 'album', label: 'Album' }, { key: 'duration', label: 'Durée' }, { key: 'year', label: 'Date de sortie' }, { key: 'plays', label: 'Écoutes' },
];

const cmp: Record<SortKey, (a: Track, b: Track) => number> = {
  added: (a, b) => a.addedAt - b.addedAt,
  title: (a, b) => a.title.localeCompare(b.title, 'fr'),
  artist: (a, b) => artistLine(a).localeCompare(artistLine(b), 'fr') || (a.album ?? '').localeCompare(b.album ?? '', 'fr') || (a.trackNo ?? 0) - (b.trackNo ?? 0),
  album: (a, b) => (a.album ?? '').localeCompare(b.album ?? '', 'fr') || (a.discNo ?? 1) - (b.discNo ?? 1) || (a.trackNo ?? 0) - (b.trackNo ?? 0),
  duration: (a, b) => a.durationSec - b.durationSec,
  year: (a, b) => (a.year ?? 0) - (b.year ?? 0),
  plays: (a, b) => a.playCount - b.playCount,
};

const TABS = [{ id: 'tracks', label: 'Titres' }, { id: 'albums', label: 'Albums' }, { id: 'artists', label: 'Artistes' }] as const;

export function LibraryPage({ tab = 'tracks', liked = false }: { tab?: 'tracks' | 'albums' | 'artists'; liked?: boolean }) {
  const { tracks, albums, artists, rev, ready, addFolder, rescan, scanning } = useLibrary();
  const folders = useSettings((s) => s.libraryFolders);
  const density = useSettings((s) => s.density);
  const navigate = useUi((s) => s.navigate);
  const [query, setQuery] = useState('');
  const [sort, setSort] = useState<{ key: SortKey; dir: 1 | -1 }>({ key: 'added', dir: -1 });
  const columns = useRowColumns();
  const rowH = DENSITY_ROW[density];
  const q = norm(query);
  const activeTab = liked ? 'tracks' : tab;

  const visibleTracks = useMemo(() => {
    let list = liked ? tracks.filter((t) => t.liked) : tracks;
    if (q) list = list.filter((t) => norm(`${t.title} ${artistLine(t)} ${t.album ?? ''}`).includes(q));
    return [...list].sort((a, b) => sort.dir * cmp[sort.key](a, b));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [tracks, liked, q, sort, rev]);

  const visibleAlbums = useMemo(
    () => albums.filter((a) => !q || norm(`${a.title} ${a.artist}`).includes(q)).sort((a, b) => (sort.key === 'title' ? a.title.localeCompare(b.title, 'fr') * sort.dir : sort.key === 'artist' ? a.artist.localeCompare(b.artist, 'fr') * sort.dir : sort.key === 'year' ? ((a.year ?? 0) - (b.year ?? 0)) * sort.dir : (a.addedAt - b.addedAt) * sort.dir)),
    [albums, q, sort],
  );
  const visibleArtists = useMemo(() => artists.filter((a) => !q || norm(a.name).includes(q)).sort((a, b) => a.name.localeCompare(b.name, 'fr')), [artists, q]);

  const header = (key: SortKey, label: string, className = '') => (
    <button onClick={() => setSort((s) => (s.key === key ? { key, dir: (-s.dir) as 1 | -1 } : { key, dir: key === 'added' || key === 'plays' ? -1 : 1 }))} className={`flex items-center gap-1 text-left hover:text-fg ${className}`}>
      {label}
      {sort.key === key && (sort.dir === 1 ? <ArrowUp size={12} /> : <ArrowDown size={12} />)}
    </button>
  );

  const count = activeTab === 'tracks' ? visibleTracks.length : activeTab === 'albums' ? visibleAlbums.length : visibleArtists.length;
  const unit = activeTab === 'tracks' ? ['titre', 'titres'] : activeTab === 'albums' ? ['album', 'albums'] : ['artiste', 'artistes'];

  return (
    <div className="flex h-full flex-col px-8">
      <div className="flex flex-wrap items-end justify-between gap-4 pb-4">
        <div>
          <h1 className="font-display text-[30px] font-semibold tracking-tight">{liked ? 'Titres likés' : 'Bibliothèque'}</h1>
          <p className="mt-0.5 text-[13.5px] text-muted">{plural(count, unit[0], unit[1])}{q ? ' correspondant' + (count > 1 ? 's' : '') : ''}</p>
        </div>
        <div className="flex items-center gap-2">
          <label className="flex items-center gap-2 rounded-full bg-fg/[0.08] px-3.5 py-2 text-[13px] focus-within:ring-2 focus-within:ring-accent/60">
            <SearchIcon size={15} className="text-muted" />
            <input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Filtrer la bibliothèque" aria-label="Filtrer la bibliothèque" className="w-44 bg-transparent outline-none placeholder:text-muted" />
          </label>
          <select aria-label="Trier par" value={sort.key} onChange={(e) => setSort({ key: e.target.value as SortKey, dir: e.target.value === 'added' || e.target.value === 'plays' ? -1 : 1 })} className="rounded-full bg-fg/[0.08] px-3.5 py-2 text-[13px] outline-none focus-visible:ring-2 focus-visible:ring-accent/60">
            {SORTS.map((s) => <option key={s.key} value={s.key} className="bg-raised">{s.label}</option>)}
          </select>
          <button onClick={() => void addFolder()} disabled={scanning} aria-label="Ajouter un dossier" title="Ajouter un dossier" className="flex size-9 items-center justify-center rounded-full bg-fg/[0.08] text-muted transition hover:text-fg disabled:opacity-40"><FolderPlus size={17} /></button>
          <button onClick={() => void rescan()} disabled={scanning || !folders.length} aria-label="Actualiser la bibliothèque" title="Actualiser la bibliothèque" className="flex size-9 items-center justify-center rounded-full bg-fg/[0.08] text-muted transition hover:text-fg disabled:opacity-40"><RefreshCw size={16} className={scanning ? 'animate-spin' : ''} /></button>
        </div>
      </div>

      {!liked && (
        <div className="mb-3 flex gap-1.5" role="tablist">
          {TABS.map((t) => (
            <button key={t.id} role="tab" aria-selected={activeTab === t.id} onClick={() => navigate({ name: 'library', tab: t.id })} className={`rounded-full px-4 py-1.5 text-[13px] font-medium transition-colors ${activeTab === t.id ? 'bg-fg text-bg' : 'bg-fg/[0.08] text-muted hover:text-fg'}`}>
              {t.label}
            </button>
          ))}
        </div>
      )}

      {!ready ? null : tracks.length === 0 ? (
        <EmptyState title="Ta bibliothèque est vide" text="Ajoute un dossier de musique pour retrouver ici tes titres, albums et artistes." action={{ label: 'Choisir un dossier', onClick: () => void addFolder() }} />
      ) : activeTab === 'tracks' ? (
        <>
          <div className="grid items-center gap-3 border-b border-line/10 px-3 pb-2 text-[12px] text-muted" style={{ gridTemplateColumns: columns.template }}>
            <span className="text-center">#</span>
            {header('title', 'Titre')}
            {columns.album && header('album', 'Album')}
            {columns.added && header('added', 'Ajouté le')}
            <span />
            {header('duration', 'Durée', 'justify-end')}
            <span />
          </div>
          <VirtualList
            items={visibleTracks}
            rowHeight={rowH}
            className="-mx-2 min-h-0 flex-1 px-2 pb-4"
            empty={<EmptyState title={liked ? 'Aucun titre liké' : 'Aucun résultat'} text={liked ? 'Appuie sur le cœur d’un titre (ou Ctrl + L pendant la lecture) pour le retrouver ici.' : 'Aucun titre ne correspond à ce filtre.'} />}
            renderRow={(t, i) => <TrackRow track={t} index={i} list={visibleTracks} columns={columns} />}
          />
        </>
      ) : (
        <div className="-mx-2 min-h-0 flex-1 overflow-y-auto px-2 pb-6">
          {count === 0 ? (
            <EmptyState title="Aucun résultat" text="Aucun élément ne correspond à ce filtre." />
          ) : (
            <div className="grid gap-1" style={{ gridTemplateColumns: 'repeat(auto-fill, minmax(176px, 1fr))' }}>
              {activeTab === 'albums'
                ? visibleAlbums.map((a) => <div key={a.key} style={{ contentVisibility: 'auto', containIntrinsicSize: '176px 250px' }}><AlbumCard album={a} /></div>)
                : visibleArtists.map((a) => <div key={a.key} style={{ contentVisibility: 'auto', containIntrinsicSize: '176px 230px' }}><ArtistCard artist={a} /></div>)}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
