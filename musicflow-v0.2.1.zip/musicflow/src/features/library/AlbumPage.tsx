import { Play, Shuffle } from 'lucide-react';
import { engine } from '@/core/playback/engine';
import { useLibrary } from '@/stores/libraryStore';
import { DENSITY_ROW, useSettings } from '@/stores/settingsStore';
import { useUi } from '@/stores/uiStore';
import { artistKeyOf } from '@/utils/groups';
import { formatLong, plural } from '@/utils/format';
import { EmptyState } from '@/ui/Cards';
import { CoverArt } from '@/ui/CoverArt';
import { StatusBadge } from '@/ui/StatusBadge';
import { TrackRow, useRowColumns } from '@/ui/TrackRow';

export function AlbumPage({ albumKey }: { albumKey: string }) {
  const album = useLibrary((s) => s.albumsByKey.get(albumKey));
  useLibrary((s) => s.rev);
  const rowH = DENSITY_ROW[useSettings((s) => s.density)];
  const navigate = useUi((s) => s.navigate);
  const columns = useRowColumns({ album: false, added: false });

  if (!album) return <EmptyState title="Album introuvable" text="Il a peut-être été retiré de la bibliothèque." />;
  const discs = new Set(album.tracks.map((t) => t.discNo ?? 1));
  const meta = [album.year, plural(album.tracks.length, 'titre', 'titres'), formatLong(album.durationSec), album.genre].filter(Boolean).join(' · ');

  return (
    <div className="h-full overflow-y-auto px-8 pb-10">
      <header className="flex flex-wrap items-end gap-7 pb-7 pt-2">
        <CoverArt coverKey={album.coverKey} seed={album.title} className="size-[220px] shadow-2xl shadow-black/40" iconSize={60} />
        <div className="min-w-0">
          <h1 className="font-display text-[42px] font-semibold leading-[1.05] tracking-tight">{album.title}</h1>
          <div className="mt-3 text-[14px]">
            <button className="font-medium hover:underline" onClick={() => navigate({ name: 'artist', key: artistKeyOf(album.artist) })}>{album.artist}</button>
            <span className="text-muted"> · {meta}</span>
          </div>
          <div className="mt-5 flex items-center gap-3">
            <button onClick={() => void engine.playTracks(album.tracks, 0, false)} className="flex items-center gap-2 rounded-full bg-accent px-6 py-3 text-[14px] font-semibold text-on-accent transition hover:brightness-110 active:scale-95">
              <Play size={17} fill="currentColor" /> Lire
            </button>
            <button onClick={() => void engine.playTracks(album.tracks, 0, true)} className="flex items-center gap-2 rounded-full bg-fg/10 px-5 py-3 text-[14px] font-medium transition hover:bg-fg/15 active:scale-95">
              <Shuffle size={16} /> Aléatoire
            </button>
          </div>
        </div>
      </header>

      <div>
        {album.tracks.map((t, i) => {
          const newDisc = discs.size > 1 && (i === 0 || (album.tracks[i - 1].discNo ?? 1) !== (t.discNo ?? 1));
          return (
            <div key={t.id}>
              {newDisc && <div className="px-3 pb-1 pt-4 text-[12.5px] font-medium text-muted">Disque {t.discNo ?? 1}</div>}
              <div style={{ height: rowH }}>
                <TrackRow track={t} index={i} list={album.tracks} columns={columns} number={t.trackNo ?? i + 1} showCover={false} />
              </div>
            </div>
          );
        })}
      </div>

      <div className="mt-8 flex max-w-2xl items-start gap-3 rounded-ui bg-fg/[0.05] p-4 text-[13px] leading-relaxed text-muted">
        <StatusBadge status="pending" />
        <p>Description, crédits, versions alternatives et albums similaires demandent une source de métadonnées en ligne (étape 4). Les informations ci-dessus viennent des tags de tes fichiers.</p>
      </div>
    </div>
  );
}
