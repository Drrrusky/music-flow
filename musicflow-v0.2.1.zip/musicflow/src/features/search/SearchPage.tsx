import { Clock, Search as SearchIcon, X } from 'lucide-react';
import { useDeferredValue, useEffect, useMemo, useRef, useState, type ReactNode } from 'react';
import { engine } from '@/core/playback/engine';
import type { Album, Artist, Track } from '@/core/types';
import { useLibrary } from '@/stores/libraryStore';
import { useSettings } from '@/stores/settingsStore';
import { useUi } from '@/stores/uiStore';
import { artistLine } from '@/utils/groups';
import { searchLibrary } from '@/utils/search';
import { highlight } from '@/utils/text';
import { formatTime, plural } from '@/utils/format';
import { CoverArt } from '@/ui/CoverArt';
import { showTrackMenu } from '@/ui/trackActions';
import { EmptyState } from '@/ui/Cards';
import { ytSearch } from '@/services/youtube';
import { YT_IDLE, YouTubeResults, type YtState } from './YouTubeResults';

type Filter = 'all' | 'tracks' | 'albums' | 'artists';
type Item =
  | { kind: 'track'; track: Track; index: number }
  | { kind: 'album'; album: Album }
  | { kind: 'artist'; artist: Artist };

function Hl({ text, q }: { text: string; q: string }) {
  return <>{highlight(text, q).map((s, i) => (s.hit ? <mark key={i} className="rounded-sm bg-accent/25 text-fg">{s.text}</mark> : <span key={i}>{s.text}</span>))}</>;
}

function Row({ active, index, onClick, onContextMenu, cover, title, subtitle, right }: { active: boolean; index: number; onClick: () => void; onContextMenu?: (e: React.MouseEvent) => void; cover: ReactNode; title: ReactNode; subtitle: ReactNode; right?: ReactNode }) {
  return (
    <button data-index={index} onClick={onClick} onContextMenu={onContextMenu} className={`flex w-full items-center gap-3 rounded-ui-sm px-3 py-2 text-left transition-colors ${active ? 'bg-fg/[0.12]' : 'hover:bg-fg/[0.06]'}`}>
      {cover}
      <div className="min-w-0 flex-1">
        <div className="truncate text-[14px] font-medium">{title}</div>
        <div className="truncate text-[12.5px] text-muted">{subtitle}</div>
      </div>
      {right && <span className="text-[12.5px] tabular-nums text-muted">{right}</span>}
    </button>
  );
}

const FILTERS: { id: Filter; label: string }[] = [
  { id: 'all', label: 'Tout' }, { id: 'tracks', label: 'Titres' }, { id: 'albums', label: 'Albums' }, { id: 'artists', label: 'Artistes' },
];

export function SearchPage() {
  const { tracks, albums, artists, rev } = useLibrary();
  const nonce = useUi((s) => s.searchNonce);
  const navigate = useUi((s) => s.navigate);
  const history = useSettings((s) => s.searchHistory);
  const update = useSettings((s) => s.update);
  const [query, setQuery] = useState('');
  const [filter, setFilter] = useState<Filter>('all');
  const [active, setActive] = useState(0);
  const input = useRef<HTMLInputElement>(null);
  const listRef = useRef<HTMLDivElement>(null);
  const deferred = useDeferredValue(query);
  const [yt, setYt] = useState<YtState>(YT_IDLE);

  useEffect(() => { input.current?.focus(); input.current?.select(); }, [nonce]);

  const results = useMemo(
    () => searchLibrary(deferred, { tracks, albums, artists }, 8),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [deferred, tracks, albums, artists, rev],
  );

  const { items, trackList } = useMemo(() => {
    const trackList = results.tracks.slice(0, filter === 'tracks' ? 30 : 6);
    const list: Item[] = [];
    if (filter === 'all' || filter === 'tracks') trackList.forEach((track, index) => list.push({ kind: 'track', track, index }));
    if (filter === 'all' || filter === 'albums') results.albums.slice(0, filter === 'albums' ? 24 : 5).forEach((album) => list.push({ kind: 'album', album }));
    if (filter === 'all' || filter === 'artists') results.artists.slice(0, filter === 'artists' ? 24 : 5).forEach((artist) => list.push({ kind: 'artist', artist }));
    return { items: list, trackList };
  }, [results, filter]);

  useEffect(() => setActive(0), [deferred, filter]);
  useEffect(() => { listRef.current?.querySelector(`[data-index="${active}"]`)?.scrollIntoView({ block: 'nearest' }); }, [active]);

  const remember = () => {
    const q = query.trim();
    if (q.length < 2) return;
    update({ searchHistory: [q, ...history.filter((h) => h.toLowerCase() !== q.toLowerCase())].slice(0, 8) });
  };

  const runYoutube = async () => {
    const q = query.trim();
    if (!q) return;
    setYt({ status: 'loading', query: q, tracks: [] });
    try {
      const tracks = await ytSearch(q);
      setYt({ status: 'done', query: q, tracks });
      remember();
    } catch (e) {
      setYt({ status: 'error', query: q, tracks: [], error: e instanceof Error ? e.message : String(e) });
    }
  };

  const open = (it: Item) => {
    remember();
    if (it.kind === 'track') void engine.playTracks(trackList, it.index);
    else if (it.kind === 'album') navigate({ name: 'album', key: it.album.key });
    else navigate({ name: 'artist', key: it.artist.key });
  };

  const onKey = (e: React.KeyboardEvent) => {
    if (e.key === 'ArrowDown') { e.preventDefault(); setActive((a) => Math.min(items.length - 1, a + 1)); }
    else if (e.key === 'ArrowUp') { e.preventDefault(); setActive((a) => Math.max(0, a - 1)); }
    else if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) void runYoutube();
    else if (e.key === 'Enter' && items[active]) open(items[active]);
    else if (e.key === 'Escape') { setQuery(''); }
  };

  const genres = useMemo(() => {
    const m = new Map<string, number>();
    for (const t of tracks) if (t.genre) m.set(t.genre, (m.get(t.genre) ?? 0) + 1);
    return [...m.entries()].sort((a, b) => b[1] - a[1]).slice(0, 14);
  }, [tracks]);

  const hasQuery = deferred.trim().length > 0;
  const section = (title: string, kind: Item['kind'], body: ReactNode) =>
    items.some((i) => i.kind === kind) && (
      <section className="mb-6">
        <h2 className="mb-1.5 px-3 font-display text-[16px] font-semibold">{title}</h2>
        {body}
      </section>
    );
  const indexOf = (it: Item) => items.indexOf(it);

  return (
    <div className="flex h-full flex-col px-8">
      <div className="pb-4">
        <label className="flex items-center gap-3 rounded-full bg-fg/[0.09] px-5 py-3.5 transition-shadow focus-within:ring-2 focus-within:ring-accent/70">
          <SearchIcon size={19} className="text-muted" />
          <input
            ref={input}
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onKeyDown={onKey}
            placeholder="Titres, albums, artistes, genres…"
            aria-label="Rechercher dans la bibliothèque"
            className="flex-1 bg-transparent text-[16px] outline-none placeholder:text-muted"
          />
          {query && <button aria-label="Effacer" onClick={() => { setQuery(''); input.current?.focus(); }} className="text-muted hover:text-fg"><X size={18} /></button>}
          <kbd className="rounded-md bg-fg/10 px-1.5 py-0.5 text-[11px] text-muted">Ctrl K</kbd>
        </label>
        {hasQuery && (
          <div className="mt-3 flex gap-1.5" role="tablist">
            {FILTERS.map((f) => (
              <button key={f.id} role="tab" aria-selected={filter === f.id} onClick={() => setFilter(f.id)} className={`rounded-full px-4 py-1.5 text-[13px] font-medium transition-colors ${filter === f.id ? 'bg-fg text-bg' : 'bg-fg/[0.08] text-muted hover:text-fg'}`}>{f.label}</button>
            ))}
          </div>
        )}
      </div>

      <div ref={listRef} className="-mx-2 min-h-0 flex-1 overflow-y-auto px-2 pb-6">
        {!hasQuery ? (
          tracks.length === 0 ? (
            <EmptyState title="Rien à rechercher pour l’instant" text="Ajoute d’abord un dossier de musique depuis l’accueil ou la bibliothèque." />
          ) : (
            <>
              {history.length > 0 && (
                <section className="mb-7">
                  <div className="mb-2 flex items-center justify-between px-3">
                    <h2 className="font-display text-[16px] font-semibold">Recherches récentes</h2>
                    <button onClick={() => update({ searchHistory: [] })} className="text-[12.5px] text-muted hover:text-fg hover:underline">Effacer</button>
                  </div>
                  <div className="flex flex-wrap gap-2 px-3">
                    {history.map((h) => (
                      <button key={h} onClick={() => { setQuery(h); input.current?.focus(); }} className="flex items-center gap-1.5 rounded-full bg-fg/[0.08] px-3.5 py-1.5 text-[13px] hover:bg-fg/[0.14]"><Clock size={13} className="text-muted" />{h}</button>
                    ))}
                  </div>
                </section>
              )}
              {genres.length > 0 && (
                <section>
                  <h2 className="mb-2 px-3 font-display text-[16px] font-semibold">Parcourir par genre</h2>
                  <div className="flex flex-wrap gap-2 px-3">
                    {genres.map(([g, n]) => (
                      <button key={g} onClick={() => { setQuery(g); input.current?.focus(); }} className="rounded-full bg-fg/[0.08] px-4 py-2 text-[13px] hover:bg-fg/[0.14]">{g} <span className="ml-1 text-muted">{n}</span></button>
                    ))}
                  </div>
                </section>
              )}
            </>
          )
        ) : items.length === 0 ? (
          <EmptyState title={`Aucun résultat pour « ${deferred.trim()} »`} text="Vérifie l’orthographe ou essaie un autre mot : la recherche ignore les accents et la casse." />
        ) : (
          <>
            {section('Titres', 'track', items.filter((i): i is Extract<Item, { kind: 'track' }> => i.kind === 'track').map((it) => (
              <Row key={it.track.id} index={indexOf(it)} active={indexOf(it) === active} onClick={() => open(it)} onContextMenu={(e) => showTrackMenu(e, it.track, { list: trackList, index: it.index })}
                cover={<CoverArt coverKey={it.track.coverKey} coverUrl={it.track.coverUrl} seed={it.track.album ?? it.track.title} className="size-11" iconSize={16} />}
                title={<Hl text={it.track.title} q={deferred} />} subtitle={<Hl text={[artistLine(it.track), it.track.album].filter(Boolean).join(' · ')} q={deferred} />} right={formatTime(it.track.durationSec)} />
            )))}
            {section('Albums', 'album', items.filter((i): i is Extract<Item, { kind: 'album' }> => i.kind === 'album').map((it) => (
              <Row key={it.album.key} index={indexOf(it)} active={indexOf(it) === active} onClick={() => open(it)}
                cover={<CoverArt coverKey={it.album.coverKey} seed={it.album.title} className="size-11" iconSize={16} />}
                title={<Hl text={it.album.title} q={deferred} />} subtitle={<Hl text={[it.album.year, it.album.artist].filter(Boolean).join(' · ')} q={deferred} />} right={plural(it.album.tracks.length, 'titre', 'titres')} />
            )))}
            {section('Artistes', 'artist', items.filter((i): i is Extract<Item, { kind: 'artist' }> => i.kind === 'artist').map((it) => (
              <Row key={it.artist.key} index={indexOf(it)} active={indexOf(it) === active} onClick={() => open(it)}
                cover={<CoverArt coverKey={it.artist.coverKey} seed={it.artist.name} round className="size-11" iconSize={16} />}
                title={<Hl text={it.artist.name} q={deferred} />} subtitle="Artiste" right={plural(it.artist.tracks.length, 'titre', 'titres')} />
            )))}
          </>
        )}
        {hasQuery && <div className="mt-4"><YouTubeResults query={query} state={yt} onSearch={() => void runYoutube()} /></div>}
      </div>
    </div>
  );
}
