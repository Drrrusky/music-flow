import { Search as SearchIcon } from 'lucide-react';
import { engine } from '@/core/playback/engine';
import { SEARCH_DAILY_LIMIT } from '@/core/providers/youtube/quota';
import type { Track } from '@/core/types';
import { useSettings } from '@/stores/settingsStore';
import { useUi } from '@/stores/uiStore';
import { ytQuota, useYtQuotaRev } from '@/services/youtube';
import { artistLine } from '@/utils/groups';
import { formatTime } from '@/utils/format';
import { CoverArt } from '@/ui/CoverArt';
import { showTrackMenu } from '@/ui/trackActions';

export interface YtState { status: 'idle' | 'loading' | 'done' | 'error'; query: string; tracks: Track[]; error?: string }
export const YT_IDLE: YtState = { status: 'idle', query: '', tracks: [] };

export function YouTubeResults({ query, state, onSearch }: { query: string; state: YtState; onSearch: () => void }) {
  const apiKey = useSettings((s) => s.youtubeApiKey);
  const navigate = useUi((s) => s.navigate);
  useYtQuotaRev((s) => s.rev);
  const left = ytQuota.searchesLeft();
  const stale = state.status !== 'idle' && state.query !== query.trim();

  if (!apiKey.trim()) {
    return (
      <section className="mb-6 rounded-ui bg-fg/[0.05] p-5">
        <h2 className="font-display text-[16px] font-semibold">Sur YouTube</h2>
        <p className="mt-1.5 max-w-xl text-[13px] leading-relaxed text-muted">Ajoute une clé API gratuite pour chercher et lire des morceaux depuis YouTube. La lecture se fait dans le lecteur officiel : pas d’égaliseur sur ces titres.</p>
        <button onClick={() => navigate({ name: 'settings', section: 'sources' })} className="mt-3 rounded-full bg-fg/10 px-4 py-2 text-[13px] font-medium transition hover:bg-fg/15">Configurer YouTube</button>
      </section>
    );
  }

  return (
    <section className="mb-6">
      <div className="mb-2 flex flex-wrap items-center justify-between gap-3 px-3">
        <h2 className="font-display text-[16px] font-semibold">Sur YouTube</h2>
        <span className="text-[12px] text-muted">{left} / {SEARCH_DAILY_LIMIT} recherches restantes aujourd’hui (estimation)</span>
      </div>

      <div className="px-3">
        <button
          onClick={onSearch}
          disabled={!query.trim() || state.status === 'loading' || left <= 0}
          className="flex items-center gap-2 rounded-full bg-accent px-5 py-2.5 text-[13.5px] font-semibold text-on-accent transition hover:brightness-110 active:scale-95 disabled:opacity-40"
        >
          <SearchIcon size={15} /> Chercher « {query.trim().slice(0, 40)} » sur YouTube
        </button>
        <span className="ml-3 text-[12px] text-muted">ou Ctrl + Entrée</span>
      </div>

      {state.status === 'loading' && (
        <div className="mt-3 space-y-2 px-3" aria-busy>{Array.from({ length: 4 }, (_, i) => <div key={i} className="skeleton h-14 rounded-ui-sm" />)}</div>
      )}
      {state.status === 'error' && <p className="mx-3 mt-3 rounded-ui-sm bg-rose-500/10 px-4 py-3 text-[13px] text-rose-400" role="alert">{state.error}</p>}
      {state.status === 'done' && (
        <div className={`mt-2 ${stale ? 'opacity-50' : ''}`}>
          {state.tracks.length === 0 ? (
            <p className="px-3 py-3 text-[13px] text-muted">Aucun morceau lisible trouvé sur YouTube pour « {state.query} ».</p>
          ) : (
            <>
              {state.tracks.map((t, i) => (
                <button key={t.id} onClick={() => void engine.playTracks(state.tracks, i)} onContextMenu={(e) => showTrackMenu(e, t, { list: state.tracks, index: i })} className="flex w-full items-center gap-3 rounded-ui-sm px-3 py-2 text-left transition-colors hover:bg-fg/[0.06]">
                  <CoverArt coverUrl={t.coverUrl} seed={t.title} className="size-11" iconSize={16} />
                  <div className="min-w-0 flex-1">
                    <div className="truncate text-[14px] font-medium">{t.title}</div>
                    <div className="truncate text-[12.5px] text-muted">{artistLine(t)}{t.channel && t.channel !== artistLine(t) ? ` · ${t.channel}` : ''}</div>
                  </div>
                  <span className="text-[12.5px] tabular-nums text-muted">{formatTime(t.durationSec)}</span>
                </button>
              ))}
              <p className="px-3 pt-2 text-[12px] leading-relaxed text-muted">Classement par YouTube. Titre et artiste sont déduits du titre de la vidéo et peuvent être approximatifs.</p>
            </>
          )}
        </div>
      )}
    </section>
  );
}
