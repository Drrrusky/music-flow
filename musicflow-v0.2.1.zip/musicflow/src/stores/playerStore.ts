import { create } from 'zustand';
import { emptyQueue, type QueueState, type RepeatMode } from '@/core/playback/Queue';
import type { Track } from '@/core/types';
import { useSettings } from './settingsStore';

export type PlayerStatus = 'idle' | 'loading' | 'playing' | 'paused' | 'error';

export interface PlayerState {
  queue: QueueState;
  current: Track | null;
  status: PlayerStatus;
  position: number;
  duration: number;
  volume: number;
  muted: boolean;
  shuffle: boolean;
  repeat: RepeatMode;
  error?: string;
}

/** État pur du lecteur. La logique est dans `core/playback/engine.ts`. */
export const usePlayer = create<PlayerState>(() => ({
  queue: emptyQueue(),
  current: null,
  status: 'idle',
  position: 0,
  duration: 0,
  volume: useSettings.getState().volume,
  muted: useSettings.getState().muted,
  shuffle: false,
  repeat: 'off',
}));
