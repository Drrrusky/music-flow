import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { defaultEq, type EqSettings } from '@/core/playback/AudioGraph';

export type ThemeMode = 'dark' | 'light' | 'auto';
export type Density = 'compact' | 'comfortable' | 'spacious';
export type StartPage = 'home' | 'search' | 'library';

export type ShortcutAction =
  | 'playPause' | 'next' | 'prev' | 'search' | 'like' | 'queue' | 'settings' | 'volumeUp' | 'volumeDown' | 'mute';

export const DEFAULT_SHORTCUTS: Record<ShortcutAction, string> = {
  playPause: 'space',
  next: 'ctrl+arrowright',
  prev: 'ctrl+arrowleft',
  search: 'ctrl+k',
  like: 'ctrl+l',
  queue: 'ctrl+q',
  settings: 'ctrl+,',
  volumeUp: 'ctrl+arrowup',
  volumeDown: 'ctrl+arrowdown',
  mute: 'ctrl+m',
};

export interface Settings {
  displayName: string;
  theme: ThemeMode;
  accent: string;
  blur: number;
  radius: number;
  density: Density;
  animations: boolean;
  ambient: boolean;
  sidebarWidth: number;
  startPage: StartPage;

  volume: number;
  muted: boolean;
  resumeLastSession: boolean;
  normalize: boolean;
  outputDeviceId: string;
  eq: EqSettings;

  youtubeApiKey: string;
  libraryFolders: string[];
  searchHistory: string[];
  shortcuts: Record<ShortcutAction, string>;
}

const defaults: Settings = {
  displayName: '',
  theme: 'dark',
  accent: '#8b7cff',
  blur: 24,
  radius: 14,
  density: 'comfortable',
  animations: true,
  ambient: true,
  sidebarWidth: 248,
  startPage: 'home',
  volume: 0.8,
  muted: false,
  resumeLastSession: true,
  normalize: true,
  outputDeviceId: '',
  eq: defaultEq(),
  youtubeApiKey: '',
  libraryFolders: [],
  searchHistory: [],
  shortcuts: { ...DEFAULT_SHORTCUTS },
};

interface SettingsState extends Settings {
  update: (patch: Partial<Settings>) => void;
  updateEq: (patch: Partial<EqSettings>) => void;
  reset: () => void;
}

export const useSettings = create<SettingsState>()(
  persist(
    (set) => ({
      ...defaults,
      update: (patch) => set(patch),
      updateEq: (patch) => set((s) => ({ eq: { ...s.eq, ...patch } })),
      reset: () => set({ ...defaults }),
    }),
    {
      name: 'musicflow.settings',
      version: 1,
      // Fusionne avec les valeurs par défaut : une nouvelle option n'est jamais `undefined` après une mise à jour.
      merge: (persisted, current) => {
        const p = (persisted ?? {}) as Partial<Settings>;
        return { ...current, ...p, eq: { ...current.eq, ...p.eq }, shortcuts: { ...current.shortcuts, ...p.shortcuts } };
      },
    },
  ),
);

export const DENSITY_ROW: Record<Density, number> = { compact: 44, comfortable: 56, spacious: 68 };
