import { create } from 'zustand';
import type { Track } from '@/core/types';

export type Route =
  | { name: 'home' }
  | { name: 'search' }
  | { name: 'library'; tab?: 'tracks' | 'albums' | 'artists'; liked?: boolean }
  | { name: 'album'; key: string }
  | { name: 'artist'; key: string }
  | { name: 'settings'; section?: string };

export interface MenuItem {
  label: string;
  onClick?: () => void;
  danger?: boolean;
  disabled?: boolean;
  hint?: string;
  separator?: boolean;
}

export interface Toast { id: number; message: string; kind: 'info' | 'error' | 'success' }

interface UiState {
  route: Route;
  past: Route[];
  future: Route[];
  queueOpen: boolean;
  infoTrack: Track | null;
  menu: { x: number; y: number; items: MenuItem[] } | null;
  toasts: Toast[];
  searchNonce: number;
  navigate: (r: Route) => void;
  back: () => void;
  forward: () => void;
  toggleQueue: () => void;
  openInfo: (t: Track) => void;
  closeInfo: () => void;
  openMenu: (x: number, y: number, items: MenuItem[]) => void;
  closeMenu: () => void;
  toast: (message: string, kind?: Toast['kind']) => void;
  focusSearch: () => void;
}

let toastId = 0;

export const useUi = create<UiState>((set, get) => ({
  route: { name: 'home' },
  past: [],
  future: [],
  queueOpen: false,
  infoTrack: null,
  menu: null,
  toasts: [],
  searchNonce: 0,
  navigate: (r) => {
    const cur = get().route;
    if (JSON.stringify(cur) === JSON.stringify(r)) return;
    set((s) => ({ route: r, past: [...s.past.slice(-49), s.route], future: [] }));
  },
  back: () => set((s) => (s.past.length ? { route: s.past[s.past.length - 1], past: s.past.slice(0, -1), future: [s.route, ...s.future] } : s)),
  forward: () => set((s) => (s.future.length ? { route: s.future[0], future: s.future.slice(1), past: [...s.past, s.route] } : s)),
  toggleQueue: () => set((s) => ({ queueOpen: !s.queueOpen, infoTrack: s.queueOpen ? s.infoTrack : null })),
  openInfo: (t) => set({ infoTrack: t, queueOpen: false }),
  closeInfo: () => set({ infoTrack: null }),
  openMenu: (x, y, items) => set({ menu: { x, y, items } }),
  closeMenu: () => set({ menu: null }),
  toast: (message, kind = 'info') => {
    const id = ++toastId;
    set((s) => ({ toasts: [...s.toasts.slice(-3), { id, message, kind }] }));
    setTimeout(() => set((s) => ({ toasts: s.toasts.filter((t) => t.id !== id) })), kind === 'error' ? 6000 : 3500);
  },
  focusSearch: () => {
    get().navigate({ name: 'search' });
    set((s) => ({ searchNonce: s.searchNonce + 1 }));
  },
}));
