import { create } from 'zustand';
import { open as openDialog } from '@tauri-apps/plugin-dialog';
import type { Album, Artist, Track } from '@/core/types';
import { buildAlbums, buildArtists } from '@/utils/groups';
import { isUnder } from '@/utils/audio';
import { repo } from '@/services/repository';
import { primeCover } from '@/services/covers';
import { extractTrack, listAudioFiles, mapPool } from '@/services/scanner';
import { inTauri } from '@/services/db';
import { usePlayer } from './playerStore';
import { useSettings } from './settingsStore';
import { useUi } from './uiStore';

interface LibraryState {
  tracks: Track[];
  byId: Map<string, Track>;
  albums: Album[];
  albumsByKey: Map<string, Album>;
  artists: Artist[];
  artistsByKey: Map<string, Artist>;
  /**
   * Les objets Track sont modifiés sur place (like, compteur, durée) pour rester partagés avec la file
   * de lecture sans recalculer albums et artistes à chaque clic. `rev` signale le changement aux composants.
   */
  rev: number;
  ready: boolean;
  scanning: boolean;
  progress: { done: number; total: number } | null;
  init: () => Promise<void>;
  addFolder: () => Promise<void>;
  removeFolder: (path: string) => Promise<void>;
  rescan: () => Promise<void>;
  toggleLike: (id: string) => void;
  recordPlay: (id: string) => void;
  updateDuration: (id: string, sec: number) => void;
}

function derive(tracks: Track[]) {
  const albums = buildAlbums(tracks);
  const artists = buildArtists(tracks);
  return {
    tracks,
    byId: new Map(tracks.map((t) => [t.id, t])),
    albums,
    albumsByKey: new Map(albums.map((a) => [a.key, a])),
    artists,
    artistsByKey: new Map(artists.map((a) => [a.key, a])),
  };
}

export const useLibrary = create<LibraryState>((set, get) => {
  async function sync(folders: string[]) {
    if (!inTauri() || get().scanning) return;
    set({ scanning: true, progress: { done: 0, total: 0 } });
    try {
      const listing = await listAudioFiles(folders);
      const existing = get().tracks.filter((t) => t.provider === 'local');
      const known = new Set(existing.map((t) => t.ref));
      const present = new Set(listing.files);
      const fresh = listing.files.filter((f) => !known.has(f));
      const removed = existing.filter((t) => listing.readableRoots.some((r) => isUnder(t.ref, r)) && !present.has(t.ref));

      const ctx = {
        knownCovers: await repo.coverKeys(),
        dirCovers: listing.dirCovers,
        onCover: (key: string, data: string) => { primeCover(key, data); void repo.putCover(key, data); },
      };

      let tracks = get().tracks;
      if (removed.length) {
        const gone = new Set(removed.map((t) => t.id));
        await repo.deleteTracks([...gone]);
        tracks = tracks.filter((t) => !gone.has(t.id));
        set({ ...derive(tracks), rev: get().rev + 1 });
      }

      let done = 0, failed = 0;
      set({ progress: { done: 0, total: fresh.length } });
      // Par lots : chaque lot est enregistré et affiché avant de passer au suivant.
      for (let i = 0; i < fresh.length; i += 200) {
        const batch = fresh.slice(i, i + 200);
        const results = await mapPool(batch, 4, (f) => extractTrack(f, ctx), () => {
          done++;
          if (done % 10 === 0) set({ progress: { done, total: fresh.length } });
        });
        const ok: Track[] = [];
        for (const r of results) r.status === 'fulfilled' ? ok.push(r.value) : failed++;
        await repo.upsertTracks(ok);
        tracks = [...tracks, ...ok];
        set({ ...derive(tracks), rev: get().rev + 1, progress: { done, total: fresh.length } });
      }

      const ui = useUi.getState();
      if (fresh.length || removed.length) {
        const parts = [`${fresh.length - failed} ajouté${fresh.length - failed > 1 ? 's' : ''}`];
        if (removed.length) parts.push(`${removed.length} retiré${removed.length > 1 ? 's' : ''}`);
        if (failed) parts.push(`${failed} illisible${failed > 1 ? 's' : ''}`);
        ui.toast(`Bibliothèque mise à jour : ${parts.join(', ')}.`, failed ? 'info' : 'success');
      } else {
        ui.toast('Bibliothèque à jour.', 'info');
      }
    } catch (e) {
      useUi.getState().toast(`Analyse interrompue : ${e instanceof Error ? e.message : String(e)}`, 'error');
    } finally {
      set({ scanning: false, progress: null });
    }
  }

  return {
    ...derive([]),
    rev: 0,
    ready: false,
    scanning: false,
    progress: null,

    async init() {
      try {
        const tracks = await repo.loadTracks();
        set({ ...derive(tracks), ready: true, rev: get().rev + 1 });
      } catch (e) {
        set({ ready: true });
        useUi.getState().toast(`Base de données inaccessible : ${e instanceof Error ? e.message : String(e)}`, 'error');
      }
    },

    async addFolder() {
      if (!inTauri()) {
        useUi.getState().toast('L’accès aux dossiers nécessite l’application MusicFlow (pas le navigateur).', 'error');
        return;
      }
      const picked = await openDialog({ directory: true, recursive: true, multiple: false, title: 'Choisir un dossier de musique' });
      if (typeof picked !== 'string') return;
      const s = useSettings.getState();
      if (!s.libraryFolders.includes(picked)) s.update({ libraryFolders: [...s.libraryFolders, picked] });
      await sync(useSettings.getState().libraryFolders);
    },

    async removeFolder(path) {
      const s = useSettings.getState();
      s.update({ libraryFolders: s.libraryFolders.filter((f) => f !== path) });
      const gone = get().tracks.filter((t) => isUnder(t.ref, path));
      await repo.deleteTracks(gone.map((t) => t.id));
      const ids = new Set(gone.map((t) => t.id));
      set({ ...derive(get().tracks.filter((t) => !ids.has(t.id))), rev: get().rev + 1 });
    },

    rescan: () => sync(useSettings.getState().libraryFolders),

    toggleLike(id) {
      const t = get().byId.get(id);
      if (!t) {
        // Titre distant (résultat YouTube) pas encore dans la bibliothèque : « liker » l'y enregistre.
        const p = usePlayer.getState();
        const known = p.queue.items.find((x) => x.id === id) ?? (p.current?.id === id ? p.current : undefined);
        if (!known || known.provider === 'local') return;
        known.liked = true;
        // L'état « liké » part dans la même insertion : pas d'UPDATE qui pourrait arriver avant la ligne.
        void repo.upsertTracks([known]);
        set({ ...derive([...get().tracks, known]), rev: get().rev + 1 });
        return;
      }
      t.liked = !t.liked;
      set({ rev: get().rev + 1 });
      void repo.setLiked(id, t.liked);
    },

    recordPlay(id) {
      const t = get().byId.get(id);
      if (!t) return;
      t.playCount += 1;
      t.lastPlayedAt = Date.now();
      set({ rev: get().rev + 1 });
      void repo.recordPlay(id, t.lastPlayedAt);
    },

    updateDuration(id, sec) {
      const t = get().byId.get(id);
      if (!t || Math.abs(t.durationSec - sec) < 1.5) return;
      t.durationSec = sec;
      set({ rev: get().rev + 1 });
      void repo.setDuration(id, sec);
    },
  };
});
