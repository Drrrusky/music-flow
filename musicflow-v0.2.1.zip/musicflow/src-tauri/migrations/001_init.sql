CREATE TABLE IF NOT EXISTS tracks (
  id             TEXT PRIMARY KEY,
  provider       TEXT NOT NULL,
  ref            TEXT NOT NULL,
  title          TEXT NOT NULL,
  artists        TEXT NOT NULL DEFAULT '[]',
  album_artist   TEXT,
  album          TEXT,
  year           INTEGER,
  genre          TEXT,
  track_no       INTEGER,
  disc_no        INTEGER,
  duration       REAL NOT NULL DEFAULT 0,
  cover_key      TEXT,
  isrc           TEXT,
  label          TEXT,
  replay_gain    REAL,
  tech           TEXT,
  added_at       INTEGER NOT NULL,
  play_count     INTEGER NOT NULL DEFAULT 0,
  last_played_at INTEGER,
  liked          INTEGER NOT NULL DEFAULT 0
);
CREATE UNIQUE INDEX IF NOT EXISTS idx_tracks_ref ON tracks(provider, ref);
CREATE INDEX IF NOT EXISTS idx_tracks_added ON tracks(added_at);

CREATE TABLE IF NOT EXISTS covers (
  key  TEXT PRIMARY KEY,
  data TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS plays (
  id        INTEGER PRIMARY KEY AUTOINCREMENT,
  track_id  TEXT NOT NULL,
  played_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_plays_time ON plays(played_at);

CREATE TABLE IF NOT EXISTS playlists (
  id          TEXT PRIMARY KEY,
  name        TEXT NOT NULL,
  description TEXT,
  folder_id   TEXT,
  cover_key   TEXT,
  smart_rule  TEXT,
  created_at  INTEGER NOT NULL,
  updated_at  INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS playlist_tracks (
  playlist_id TEXT NOT NULL,
  track_id    TEXT NOT NULL,
  position    INTEGER NOT NULL,
  added_at    INTEGER NOT NULL,
  PRIMARY KEY (playlist_id, position)
);
