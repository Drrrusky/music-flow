# Liste des tâches

## Étape 1 — Architecture et conception ✅
- [x] Stack : Tauri 2, React, TypeScript, Tailwind, Framer Motion, Zustand, SQLite
- [x] Contrat `MusicProvider` + capacités ; décision YouTube documentée (`docs/PROVIDERS.md`)
- [x] Système de design (tokens, accent personnalisable, flou, arrondis, densité)

## Étape 2 — Interface principale et lecteur local ✅ (écrite, non compilée)
- [x] Barre latérale redimensionnable et repliable
- [x] Accueil, Bibliothèque (titres virtualisés, albums, artistes), pages Album et Artiste, Recherche
- [x] Barre de lecture, panneau de file d'attente (glisser-déposer), fiche détaillée d'un titre
- [x] Moteur : file d'attente testée, aléatoire, répétition, reprise de session
- [x] Égaliseur 10 bandes, préampli, balance, ReplayGain, spectre
- [x] SQLite : schéma, scan par lots, pochettes, durées corrigées à la lecture
- [x] Paramètres : apparence, audio, bibliothèque, raccourcis, état des fonctionnalités
- [ ] **Premier build sur Windows et correction des erreurs** ← prochaine action (étapes 2 et 3 ensemble)
- [ ] Vérifier au premier lancement : scan réel, lecture, EQ audible, touches multimédias

## Étape 3 — Fournisseur YouTube ✅ (écrite, non testée)
- [x] Client Data API v3 : recherche + durées, filtrage des vidéos non intégrables, erreurs traduites (19 tests)
- [x] Compteur de quota (100 recherches/jour, remise à zéro à minuit Pacifique)
- [x] Lecteur IFrame, zone vidéo toujours visible pendant la lecture
- [x] Clé API et test dans Paramètres › Sources en ligne
- [x] Résultats YouTube dans la recherche (Ctrl + Entrée), lecture mixte local/YouTube dans la même file
- [x] « Liker » un titre YouTube l'enregistre (migration SQLite 002)
- [ ] **Tester avec une vraie clé** : recherche, lecture, erreurs 101/150/153
- [ ] Si erreur 153 : serveur local `127.0.0.1` hébergeant la page du lecteur
- [ ] Actualisation des métadonnées YouTube conservées (règle de conservation à vérifier)
- [ ] Stockage sécurisé de la clé API
- [ ] (Optionnel) fournisseur Companion Server ytmdesktop

## Étape 4 — Fonctionnalités avancées
- [ ] Playlists, dossiers, playlists intelligentes, import/export, sélection multiple
- [ ] Historique d'écoute (page), recommandations locales
- [ ] Paroles (.lrc puis LRCLIB), mode karaoké, plein écran, visualiseur
- [ ] Fondu enchaîné (deux lecteurs), lecture sans coupure
- [ ] MusicBrainz pour crédits et ISRC

## Étape 5 — Discord
- [ ] Rich Presence officielle, options de confidentialité, reconnexion automatique

## Étape 6 — Personnalisation et intégration Windows
- [ ] Raccourcis personnalisables, réorganisation de la barre latérale
- [ ] Zone de notification, démarrage automatique, notifications de changement de titre

## Étape 7 — Finalisation
- [ ] Tests d'intégration et de performance (grande bibliothèque), CSP renforcée
- [ ] Installateur signé, mises à jour automatiques, documentation utilisateur
